# PCV TourOnline Connector 0.2.0

Catalogue TourOnline pour WordPress, importé en arrière-plan, avec demandes locales de réservation sans paiement. Interface française; contenu fournisseur français ou anglais selon le réglage.

**WordPress 6.2+ · PHP 7.4+ · aucune dépendance Composer, WooCommerce ou JavaScript externe.** Validation effectuée sur WordPress 6.8.3, PHP 8.4 et l’intégration SQLite officielle de WordPress. Les autres versions de PHP et MySQL/MariaDB ne font pas partie de cette validation.

## Périmètre

- Lecture du catalogue, des départs et des images TourOnline; prix indicatifs.
- Catalogue paginé, recherche, filtre de groupe et fiches avec galerie.
- Demandes privées dans WordPress, suivi administratif, avis par courriel, export/effacement des coordonnées.
- Aucun paiement, aucune facture, aucune réservation ni création de client chez TourOnline/PCVWeb. Le formulaire ne bloque aucune place.

La présence d’une offre dans PCVWeb classique ne garantit pas sa présence dans TourOnline. Une licence et un catalogue compatibles sont nécessaires. Le bilan 0.1.0 fourni est conservé comme document historique, pas comme preuve d’accès au fournisseur.

## Installation ou mise à jour

1. Sauvegarder le site et sa base, puis utiliser une préproduction.
2. Extensions → Ajouter → Téléverser `pcv-touronline-connector-v0.2.0.zip`. Lors d’une mise à jour, remplacer l’extension existante : son dossier reste `pcv-touronline-connector`.
3. Activer puis ouvrir **PCV TourOnline**. Les types de contenus et métadonnées 0.1.0 sont conservés; aucun service fournisseur n’est activé automatiquement.
4. Renseigner la licence dans les réglages. De préférence, utiliser dans `wp-config.php`, hors dépôt public :

   ```php
   define('PCVT_LICENSE', 'VOTRE_LICENCE');
   // Seulement si le fournisseur exige et fournit ce jeton :
   define('PCVT_BEARER_TOKEN', 'VOTRE_JETON');
   ```

   Les constantes ont priorité. Le champ de licence reste masqué. Une licence saisie dans l’interface est stockée en clair dans la base, dans une option non autoloadée; ce n’est pas un coffre-fort.
5. **Tester la connexion** vérifie la réponse de `/Setting/v1.0/setting`. Cette vérification ne confirme pas les droits sur tous les produits.
6. **Démarrer / reprendre l’import**, puis actualiser la progression. Les lots sont exécutés par WP-Cron. Les fiches se trouvent dans **Offres PC Voyages**.
7. Créer une page avec `[pcvt_offres limit="12"]`.
8. Vérifier quelques fiches, prix, devises, dates, photos et groupes avec le fournisseur. Tester une demande et les avis sur votre propre hébergement.
9. Activer l’import automatique si souhaité. Choisir la durée de conservation et, séparément, la politique de dépublication.

**Conservation :** une nouvelle installation utilise 180 jours. Une mise à jour de 0.1.0, qui n’avait pas de réglage de conservation, conserve le mode manuel (`0`) pour éviter de supprimer des demandes sans décision du responsable. Une durée de 30 à 3 650 jours active une suppression définitive quotidienne de toutes les demandes plus anciennes, quel que soit leur statut. Les sauvegardes de l’hébergeur sont gérées séparément.

## Shortcodes

```text
[pcvt_offres]
[pcvt_offres limit="12"]
[pcvt_offres group="Nom exact du groupe" limit="12"]
[pcvt_offres filters="0"]
[pcvt_reservation post_id="123"]
```

`limit` signifie **nombre d’offres par page** (1–100). Recherche et filtre conservent la pagination. Un produit peut appartenir à plusieurs groupes. Préférer un catalogue par page pour éviter plusieurs contrôles partageant les mêmes paramètres d’URL.

Les formulaires utilisent des champs signés rendus côté serveur. JavaScript renouvelle ces champs via une route WordPress du même site pour les pages mises en cache. Sans JavaScript, ils restent utilisables sur une page récente; un formulaire expiré nécessite de recharger la page. Exclure la route `/wp-json/pcvt/v1/form/*` et son équivalent `?rest_route=/pcvt/v1/form/*` de tout cache forcé; le serveur renvoie `Cache-Control: no-store`. Les pages des utilisateurs connectés doivent suivre les exclusions de cache habituelles de WordPress.

## Import et performance

- Découverte des groupes en une requête, dédoublonnage par code, conservation des appartenances multiples.
- File persistante et non autoloadée, indépendante de l’état de progression. Un checkpoint n’écrit pas de nouveau tout le catalogue.
- 3 produits par lot par défaut, réglables de 1 à 10. Un budget de 20 secondes est vérifié entre les produits. Un produit peut demander trois appels de 10 secondes; ce budget n’est donc pas une garantie d’exécution sous 20 secondes. Régler à 1 sur un hébergement contraint.
- Reprise au dernier produit, verrou atomique à propriétaire unique, surveillance d’une interruption et annulation administrative.
- Deux reprises différées au maximum par produit pour les erreurs réseau, HTTP 429 et 5xx; respect de `Retry-After`, plafonné à une heure. Les erreurs 401/403 ne sont pas retentées pour le même produit.
- Photos réutilisées pendant 24 h; une erreur photo ne bloque pas l’import des dates et du texte. Repli vers les images présentes dans le détail, si possible. Au maximum 12 URL par produit, dont 6 affichées en galerie.
- Comparaison d’empreintes : une fiche inchangée n’est pas réécrite. Sa date de vérification du catalogue est néanmoins actualisée.
- À froid : environ `1 + 3N` appels pour N produits. Dans les 24 h suivantes : environ `1 + 2N`, hors reprises et erreurs photo. Ce sont des comptes d’appels, pas une garantie de temps de réponse du fournisseur.
- La requête de catalogue est paginée et profite du cache de métadonnées WordPress. Les feuilles de style sont chargées pour les écrans du plugin.
- Réponses limitées à 4 Mio, catalogue limité à 5 000 codes uniques. Au-delà, l’import est refusé explicitement; il ne tronque pas silencieusement les produits. Une pagination ou segmentation fournisseur devra être ajoutée selon le contrat réel.

### Retraits et modifications manuelles

La dépublication est **désactivée par défaut**. Une fois activée, une offre absente lors de deux imports complets, réussis et non vides passe en brouillon. Une erreur, une annulation ou un catalogue vide n’entraîne aucun retrait. Une offre dépubliée automatiquement peut être republiée si elle revient. Les brouillons manuels restent des brouillons; les offres mises à la corbeille ne sont pas recréées. L’import reste propriétaire du titre et du contenu des fiches importées : placer les textes éditoriaux durables sur des pages distinctes.

### WP-Cron et WP-CLI

WP-Cron dépend du trafic. Avec un Cron système, lancer régulièrement depuis le répertoire WordPress :

```sh
wp cron event run --due-now --quiet
wp pcvt status
wp pcvt sync
wp pcvt sync --wait
```

`sync` démarre ou reprend la file. `--wait` traite les lots immédiatement dans le processus CLI; il renvoie une erreur si une reprise fournisseur différée est nécessaire, en laissant la file planifiée. Il ne boucle pas activement pendant `Retry-After`. Les événements sont arrêtés à la désactivation; une file conservée reprend à la réactivation. Le diagnostic **Santé du site** signale notamment une file bloquée ou un import avec erreurs.

## Demandes et confidentialité

**Demandes PCV** est réservé aux administrateurs (`manage_options`). Les éditeurs et auteurs n’héritent pas d’un droit de lecture sur les coordonnées. Le type de contenu n’a aucune route REST publique.

Chaque demande conserve le départ, le prix unitaire indicatif du catalogue, les coordonnées, les voyageurs, le message, le texte et la version du consentement, ainsi que l’URL de la politique de confidentialité disponible au moment de l’envoi. Ce prix n’est pas un calcul du total du groupe.

- Validation des nombres sans conversion permissive des valeurs négatives, limite de 20 voyageurs, champs bornés, dates futures disponibles dans le snapshot.
- Nonce WordPress et horodatage signé, champ anti-robot, délai minimal de 2 s.
- 8 nouvelles demandes par 15 minutes et par adresse réseau hachée; aucune adresse IP brute n’est conservée par le plugin. Un proxy inverse doit fournir correctement `REMOTE_ADDR`; les en-têtes proxy arbitraires ne sont pas acceptés.
- Un jeton de soumission ne crée qu’une demande pendant sa validité; une demande identique est dédoublonnée pendant 15 minutes. La protection emploie des verrous atomiques. Un CAPTCHA externe n’est pas inclus.
- Suivi : Nouvelle, En traitement, Client contacté, Fermée, Annulée. Ces statuts sont internes.
- Avis sans coordonnées via `wp_mail`; résultat « Envoyé » ou « À vérifier ». Un échec conserve la demande et permet le renvoi administratif. Le succès de `wp_mail` ne prouve pas la livraison en boîte de réception; tester SMTP sur le site réel.
- Outils WordPress d’export et d’effacement des données par courriel, avec pagination et suppression définitive des demandes concernées.

Publier et adapter la politique de confidentialité du site, définir l’accès du personnel et la conservation selon vos obligations. Ces fonctions facilitent la gestion; elles ne certifient pas à elles seules la conformité à la Loi 25 ou au RGPD.

## Sécurité des appels et limitations fournisseur

Origine fixe `https://api.touronline.shop`, requêtes HTTPS serveur uniquement, vérification TLS, pas de redirections. Routes de lecture autorisées explicitement; aucun POST/PUT/DELETE fournisseur. Les diagnostics ne recopient pas les réponses brutes ni les messages réseau susceptibles de contenir des secrets.

Les chemins d’images relatifs ne sont pas résolus par supposition. Seules les URL HTTPS absolues admissibles sont affichées; le navigateur les charge directement, avec `referrerpolicy="no-referrer"`. Leur hébergeur reçoit néanmoins l’adresse réseau du visiteur. Aucun téléchargement d’image externe n’est effectué par le serveur du plugin.

La réservation réelle nécessite encore : accès de test TourOnline, contrat OpenAPI complet et réponses réelles, règles du compte/voyageur, flux d’authentification et expiration JWT, idempotence après timeout, séquence de réservation/facture et garantie métier d’absence de paiement. La méthode `preview()` renvoie explicitement une fonctionnalité désactivée. Aucun de ces flux n’est annoncé comme fonctionnel.

## Désactivation et désinstallation

La désactivation arrête les tâches PCVT, conserve les données et n’envoie aucun appel fournisseur. La désinstallation conserve également les contenus et options par défaut.

Pour demander explicitement une suppression des données à la **désinstallation**, ajouter préalablement dans `wp-config.php` :

```php
define('PCVT_REMOVE_DATA_ON_UNINSTALL', true);
```

La suppression définitive concerne alors les offres, demandes et métadonnées PCVT, options et tâches PCVT. La licence définie dans `wp-config.php` et les sauvegardes restent à traiter séparément.

## Vérification et historique

Voir `BILAN_AMELIORATIONS.md` pour les résultats et limites, et `CHANGELOG.md` pour les changements. Les scripts de validation sont livrés dans l’archive de sources séparée, hors du ZIP installable. Le document `BILAN_TECHNIQUE.md` décrit exclusivement le pilote d’origine 0.1.0.
