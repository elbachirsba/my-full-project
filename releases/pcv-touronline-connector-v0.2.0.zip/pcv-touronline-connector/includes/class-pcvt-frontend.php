<?php
if (!defined('ABSPATH')) { exit; }
final class PCVT_Frontend {
    public static function boot() {
        add_shortcode('pcvt_offres',array(__CLASS__,'catalogue'));
        add_shortcode('pcvt_reservation',array(__CLASS__,'booking'));
        add_filter('the_content',array(__CLASS__,'single_content'));
        add_action('admin_post_pcvt_book',array(__CLASS__,'submit'));
        add_action('admin_post_nopriv_pcvt_book',array(__CLASS__,'submit'));
    }
    private static function query_arg($key) { return isset($_GET[$key]) && is_string($_GET[$key]) ? sanitize_text_field(wp_unslash($_GET[$key])) : ''; }
    private static function date($iso) {
        // Supplier departure dates are calendar dates; timezone conversion can shift the day.
        $date=substr((string)$iso,0,10); $dt=DateTimeImmutable::createFromFormat('!Y-m-d',$date,wp_timezone());
        return $dt ? wp_date(get_option('date_format'),$dt->getTimestamp(),wp_timezone()) : '';
    }
    private static function money($price, $currency) { return $price!=='' && is_numeric($price) ? number_format_i18n((float)$price,2).' '.PCVT_Sync::currency($currency) : 'Prix sur demande'; }
    private static function assets() { wp_enqueue_style('pcvt-style'); }
    public static function catalogue($attrs=array()) {
        self::assets();
        $atts=shortcode_atts(array('limit'=>24,'group'=>'','filters'=>'1'),$attrs,'pcvt_offres');
        $page=max(1,min(10000,(int)self::query_arg('pcvt_page'))); $q=self::query_arg('pcvt_q');
        $group=$atts['group']!=='' ? sanitize_text_field($atts['group']) : self::query_arg('pcvt_group');
        $args=array('post_type'=>'pcvt_offer','post_status'=>'publish','posts_per_page'=>min(100,max(1,(int)$atts['limit'])),
            'paged'=>$page,'orderby'=>array('title'=>'ASC','ID'=>'ASC'),'ignore_sticky_posts'=>true,'update_post_term_cache'=>false);
        if ($q!=='') { $args['s']=$q; }
        if ($group!=='') {
            $args['meta_query']=array('relation'=>'OR',array('key'=>'_pcvt_group','value'=>$group),array('key'=>'_pcvt_groups','value'=>'"'.$group.'"','compare'=>'LIKE'));
        }
        $query=new WP_Query($args);
        $html='<section class="pcvt-catalogue" aria-label="Catalogue des voyages">';
        if ($atts['filters']==='1') {
            $html.='<form class="pcvt-filters" method="get" action="'.esc_url(get_permalink()).'">';
            $base=wp_parse_url(get_permalink()); $base_query=array();
            if (!empty($base['query'])) { parse_str($base['query'],$base_query); }
            foreach ($base_query as $key=>$value) { if (is_scalar($value)) { $html.='<input type="hidden" name="'.esc_attr($key).'" value="'.esc_attr($value).'">'; } }
            $html.='<label>Rechercher une offre<input type="search" name="pcvt_q" value="'.esc_attr($q).'" maxlength="100"></label>';
            if ($atts['group']==='') { $html.='<label>Groupe<input name="pcvt_group" value="'.esc_attr($group).'" maxlength="100" placeholder="Nom du groupe"></label>'; }
            $html.='<button type="submit" class="pcvt-btn">Rechercher</button></form>';
        }
        $html.='<p class="pcvt-muted">'.(int)$query->found_posts.' offre(s). Prix et départs indicatifs issus de la dernière synchronisation.</p>';
        if (!$query->posts) { return $html.'<p>Aucune offre ne correspond à votre recherche.</p></section>'; }
        $html.='<div class="pcvt-grid">';
        // WP_Query primes the post metadata cache for the whole page (no per-card SQL).
        foreach ($query->posts as $post) {
            $image=PCVT_Sync::safe_remote_image(get_post_meta($post->ID,'_pcvt_image',true));
            $price=get_post_meta($post->ID,'_pcvt_price',true); $currency=get_post_meta($post->ID,'_pcvt_currency',true);
            $html.='<article class="pcvt-card">';
            if ($image) { $html.='<a href="'.esc_url(get_permalink($post)).'" tabindex="-1" aria-hidden="true"><img loading="lazy" decoding="async" width="640" height="400" referrerpolicy="no-referrer" src="'.esc_url($image).'" alt=""></a>'; }
            $html.='<div class="pcvt-pad"><h3><a href="'.esc_url(get_permalink($post)).'">'.esc_html($post->post_title).'</a></h3>';
            $html.='<p class="pcvt-price">'.esc_html($price!=='' ? 'Dès '.self::money($price,$currency) : 'Prix sur demande').'</p>';
            $html.='<p>'.esc_html(wp_trim_words(wp_strip_all_tags($post->post_excerpt ?: $post->post_content),20)).'</p>';
            $html.='<a class="pcvt-btn" href="'.esc_url(get_permalink($post)).'">Voir l’offre</a></div></article>';
        }
        $html.='</div>';
        $pagination=paginate_links(array('base'=>add_query_arg('pcvt_page','%#%',remove_query_arg('pcvt_page')),
            'format'=>'','current'=>$page,'total'=>(int)$query->max_num_pages,'type'=>'list',
            'prev_text'=>'← Précédent','next_text'=>'Suivant →'));
        if ($pagination) { $html.='<nav class="pcvt-pagination" aria-label="Pages du catalogue">'.$pagination.'</nav>'; }
        return $html.'</section>';
    }
    public static function single_content($html) {
        if (!is_singular('pcvt_offer') || !in_the_loop() || !is_main_query() || post_password_required()) { return $html; }
        $id=get_the_ID(); $images=get_post_meta($id,'_pcvt_images',true);
        if (!is_array($images)) { $images=array(get_post_meta($id,'_pcvt_image',true)); }
        $gallery='';
        foreach (array_slice($images,0,6) as $i=>$image) {
            $image=PCVT_Sync::safe_remote_image($image);
            if ($image) { $gallery.='<img class="pcvt-hero" src="'.esc_url($image).'" alt="'.esc_attr(get_the_title($id)).'" loading="lazy" decoding="async" width="960" height="600" referrerpolicy="no-referrer">'; }
        }
        return $html.($gallery!=='' ? '<div class="pcvt-gallery">'.$gallery.'</div>' : '').self::booking(array('post_id'=>$id));
    }
    public static function booking($attrs=array()) {
        self::assets(); wp_enqueue_script('pcvt-form');
        $id=!empty($attrs['post_id']) ? absint($attrs['post_id']) : get_the_ID();
        if (!$id || get_post_type($id)!=='pcvt_offer' || get_post_status($id)!=='publish' || post_password_required($id)) { return '<p>Aucune offre disponible.</p>'; }
        $dates=PCVT_Sync::available_dates(get_post_meta($id,'_pcvt_dates',true));
        $status=self::query_arg('pcvt_status'); $updated=get_post_meta($id,'_pcvt_updated',true);
        $html='<section class="pcvt-book" id="reservation"><h2>Demander une réservation</h2>';
        $html.='<p><strong>Aucun paiement en ligne.</strong> Votre demande sera examinée par notre équipe. Les places et le prix final restent à confirmer.</p>';
        if ($updated) { $html.='<p class="pcvt-muted">Catalogue actualisé le '.esc_html(get_date_from_gmt($updated,'d/m/Y H:i')).'. Disponibilité indicative.</p>'; }
        if ($status==='received') { $html.='<div class="pcvt-info" role="status">Votre demande a été reçue. Notre équipe vous contactera pour la suite. Aucune place n’est encore réservée.</div>'; }
        $messages=array('expired'=>'Le formulaire a expiré ou a été envoyé trop vite. Actualisez la page et réessayez.',
            'date'=>'Ce départ n’est plus proposé dans notre catalogue. Veuillez choisir une autre date.',
            'invalid'=>'Vérifiez vos coordonnées, le nombre de voyageurs et votre consentement.',
            'rate'=>'Trop de demandes ont été envoyées. Réessayez dans 15 minutes.',
            'busy'=>'Une demande est en cours de traitement. Patientez quelques secondes.',
            'error'=>'L’enregistrement a échoué. Réessayez ou contactez notre équipe.');
        if (isset($messages[$status])) { $html.='<div class="pcvt-error" role="alert">'.esc_html($messages[$status]).'</div>'; }
        if (!$dates) { return $html.'<p>Aucun départ futur disponible dans la dernière synchronisation. Contactez-nous pour vérifier les possibilités.</p></section>'; }
        $html.='<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="pcvt-request-form" data-rest-nonce="'.esc_attr(is_user_logged_in() ? wp_create_nonce('wp_rest') : '').'" data-token-url="'.esc_url(rest_url('pcvt/v1/form/'.$id)).'">';
        $html.='<input type="hidden" name="action" value="pcvt_book"><input type="hidden" name="offer_id" value="'.esc_attr($id).'">';
        foreach (PCVT_Requests::fields($id) as $key=>$value) { $html.='<input type="hidden" name="'.esc_attr($key).'" value="'.esc_attr($value).'">'; }
        $html.='<div class="pcvt-honey" aria-hidden="true"><label>Ne pas remplir<input type="text" name="company_website" tabindex="-1" autocomplete="off"></label></div>';
        $html.='<label>Départ et prix indicatif par personne<select name="date_code" required><option value="">Choisir une date</option>';
        foreach ($dates as $date) {
            $label=self::date($date['dateDepart']);
            if (!empty($date['dateReturn'])) { $label.=' → '.self::date($date['dateReturn']); }
            $label.=' — '.self::money($date['total'],$date['currency']);
            $html.='<option value="'.esc_attr($date['productPriceDateCode']).'">'.esc_html($label).'</option>';
        }
        $html.='</select></label>';
        foreach (array('first'=>array('Prénom','text','given-name',100),'last'=>array('Nom','text','family-name',100),
            'email'=>array('Courriel','email','email',254),'phone'=>array('Téléphone','tel','tel',40)) as $key=>$field) {
            $html.='<label>'.esc_html($field[0]).'<input required maxlength="'.(int)$field[3].'" type="'.esc_attr($field[1]).'" autocomplete="'.esc_attr($field[2]).'" name="'.esc_attr($key).'"></label>';
        }
        $html.='<div class="pcvt-two"><label>Adultes<input type="number" name="adults" min="1" max="20" value="1" required></label><label>Enfants<input type="number" name="children" min="0" max="19" value="0" required></label></div>';
        $html.='<p class="pcvt-muted">20 voyageurs maximum par demande. Le montant affiché n’est pas un devis pour le groupe.</p>';
        $html.='<label>Message (facultatif)<textarea name="note" maxlength="1000" rows="4"></textarea></label>';
        $html.='<label class="pcvt-consent"><input type="checkbox" name="consent" value="1" required> '.esc_html(PCVT_Requests::CONSENT_TEXT).'</label>';
        $privacy=get_privacy_policy_url();
        if ($privacy) { $html.='<p><a href="'.esc_url($privacy).'">Politique de confidentialité</a></p>'; }
        return $html.'<p class="pcvt-form-message" role="status" aria-live="polite"></p><button type="submit">Envoyer ma demande sans paiement</button></form></section>';
    }
    public static function submit() {
        if (strtoupper($_SERVER['REQUEST_METHOD']??'')!=='POST') { wp_die('Méthode invalide.','',array('response'=>405)); }
        $input=wp_unslash($_POST); $ip=isset($_SERVER['REMOTE_ADDR']) ? (string)$_SERVER['REMOTE_ADDR'] : '';
        $result=PCVT_Requests::process($input,$ip);
        $id=isset($input['offer_id']) && is_scalar($input['offer_id']) ? absint($input['offer_id']) : 0;
        $status='received';
        if (is_wp_error($result)) { $status=str_replace('pcvt_','',$result->get_error_code()); }
        if (!in_array($status,array('received','expired','date','invalid','rate','busy'),true)) { $status='error'; }
        $url=$id && get_post_type($id)==='pcvt_offer' && get_post_status($id)==='publish' ? get_permalink($id) : home_url('/');
        nocache_headers(); wp_safe_redirect(add_query_arg('pcvt_status',$status,$url).'#reservation',303); exit;
    }
}
PCVT_Frontend::boot();
