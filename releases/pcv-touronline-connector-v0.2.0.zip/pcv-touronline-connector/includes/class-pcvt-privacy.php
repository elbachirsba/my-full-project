<?php
if (!defined('ABSPATH')) { exit; }
final class PCVT_Privacy {
    public static function boot() {
        add_filter('wp_privacy_personal_data_exporters',function($items) {
            $items['pcvt']=array('exporter_friendly_name'=>'Demandes PCV','callback'=>array(__CLASS__,'export')); return $items;
        });
        add_filter('wp_privacy_personal_data_erasers',function($items) {
            $items['pcvt']=array('eraser_friendly_name'=>'Demandes PCV','callback'=>array(__CLASS__,'erase')); return $items;
        });
        add_action('admin_init',function() {
            if (!function_exists('wp_add_privacy_policy_content')) { return; }
            wp_add_privacy_policy_content('PCV TourOnline Connector',wp_kses_post('<p>Les demandes enregistrent les coordonnées, le départ, le nombre de voyageurs, le message et le consentement dans la base WordPress. Seuls les administrateurs du site peuvent les consulter. Un avis sans coordonnées est envoyé à l’administrateur. Aucune donnée voyageur n’est transmise à TourOnline par ce plugin. Par défaut les demandes de plus de 180 jours sont supprimées définitivement; le responsable du site doit adapter cette durée dans les réglages. Les outils WordPress permettent l’export et l’effacement par courriel. Une empreinte non réversible de l’adresse réseau sert à limiter les soumissions pendant 15 minutes. Les images externes peuvent transmettre l’adresse IP du visiteur à leur hébergeur. Les sauvegardes et journaux de l’hébergeur suivent leur propre durée de conservation.</p>'));
        });
    }
    private static function query($email, $page=1) {
        return get_posts(array('post_type'=>'pcvt_request','post_status'=>array('private','publish','draft','pending','trash'),
            'meta_key'=>'_pcvt_email','meta_value'=>sanitize_email($email),'posts_per_page'=>50,
            'paged'=>max(1,(int)$page),'orderby'=>'ID','order'=>'ASC','fields'=>'ids'));
    }
    public static function export($email, $page=1) {
        $ids=self::query($email,$page); $data=array();
        $labels=array('offer'=>'Offre','code'=>'Code produit','date'=>'Départ','date_return'=>'Retour','first'=>'Prénom','last'=>'Nom',
            'email'=>'Courriel','phone'=>'Téléphone','adults'=>'Adultes','children'=>'Enfants','note'=>'Message',
            'consent'=>'Consentement','consent_version'=>'Version du consentement','consent_text'=>'Texte accepté','privacy_policy_url'=>'Politique de confidentialité','created'=>'Réception','status'=>'Statut',
            'quoted_unit_price'=>'Prix indicatif unitaire','currency'=>'Devise');
        foreach ($ids as $id) {
            $fields=array();
            foreach ($labels as $key=>$label) { $fields[]=array('name'=>$label,'value'=>(string)get_post_meta($id,'_pcvt_'.$key,true)); }
            $data[]=array('group_id'=>'pcvt-requests','group_label'=>'Demandes PCV','item_id'=>'pcvt-'.$id,'data'=>$fields);
        }
        return array('data'=>$data,'done'=>count($ids)<50);
    }
    public static function erase($email, $page=1) {
        // Always take the first remaining page: deleting page one must not skip the next 50 rows.
        $ids=self::query($email,1); $removed=false; $retained=false;
        foreach ($ids as $id) {
            if (wp_delete_post($id,true)) { $removed=true; } else { $retained=true; }
        }
        return array('items_removed'=>$removed,'items_retained'=>$retained,
            'messages'=>$retained ? array('Certaines demandes n’ont pas pu être supprimées; consulter l’administrateur.') : array(),
            'done'=>count($ids)<50 || $retained);
    }
    public static function cleanup() {
        PCVT_Lock::cleanup();
        $days=(int)pcvt_settings()['retention_days'];
        if ($days<=0) { return; }
        $days=min(3650,max(30,$days));
        $ids=get_posts(array('post_type'=>'pcvt_request','post_status'=>array('private','publish','draft','pending','trash'),
            'numberposts'=>100,'fields'=>'ids','orderby'=>'ID','order'=>'ASC',
            'date_query'=>array(array('column'=>'post_date_gmt','before'=>gmdate('Y-m-d H:i:s',time()-$days*DAY_IN_SECONDS)))));
        foreach ($ids as $id) { wp_delete_post($id,true); }
        if (count($ids)===100) { wp_schedule_single_event(time()+MINUTE_IN_SECONDS,'pcvt_retention_event'); }
    }
}
PCVT_Privacy::boot();
