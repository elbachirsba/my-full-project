<?php
if (!defined('ABSPATH')) { exit; }
final class PCVT_Requests {
    const CONSENT_TEXT = 'J’accepte l’utilisation de mes coordonnées pour traiter cette demande.';
    public static function fields($id) {
        $started=time(); $submission=wp_generate_uuid4();
        return array('pcvt_nonce'=>wp_create_nonce('pcvt_book_'.$id), 'pcvt_started'=>$started,
            'pcvt_submission'=>$submission, 'pcvt_signature'=>hash_hmac('sha256',$id.'|'.$started.'|'.$submission,wp_salt('nonce')));
    }
    public static function form_token($request) {
        $id=(int)$request['id'];
        if (get_post_type($id)!=='pcvt_offer' || get_post_status($id)!=='publish' || post_password_required($id)) {
            return new WP_Error('pcvt_offer','Offre indisponible.',array('status'=>404));
        }
        $response=new WP_REST_Response(self::fields($id));
        $response->header('Cache-Control','no-store, no-cache, must-revalidate, max-age=0');
        $response->header('Vary','Cookie');
        return $response;
    }
    private static function text($input, $key) { return isset($input[$key]) && is_scalar($input[$key]) ? trim((string)$input[$key]) : ''; }
    private static function length($value) { return function_exists('mb_strlen') ? mb_strlen($value,'UTF-8') : strlen($value); }
    private static function integer($input, $key, $min, $max) {
        $value=self::text($input,$key);
        if (!preg_match('/^\d{1,10}$/D',$value)) { return false; }
        $number=(int)$value;
        return $number>=$min && $number<=$max ? $number : false;
    }
    private static function error($code) { return new WP_Error('pcvt_'.$code,$code); }
    /** Input must already be unslashed. No redirects/exit: also used by integration tests. */
    public static function process($input, $remote_addr='') {
        if (!is_array($input)) { return self::error('invalid'); }
        $id=self::integer($input,'offer_id',1,PHP_INT_MAX);
        if (!$id || get_post_type($id)!=='pcvt_offer' || get_post_status($id)!=='publish' || post_password_required($id)) { return self::error('offer'); }
        if (!wp_verify_nonce(self::text($input,'pcvt_nonce'),'pcvt_book_'.$id)) { return self::error('expired'); }
        $started=self::integer($input,'pcvt_started',1,PHP_INT_MAX);
        $submission=self::text($input,'pcvt_submission'); $signature=self::text($input,'pcvt_signature');
        if (!$started || !preg_match('/^[a-f0-9-]{36}$/D',$submission) || !hash_equals(hash_hmac('sha256',$id.'|'.$started.'|'.$submission,wp_salt('nonce')),$signature)) { return self::error('expired'); }
        if (time()-$started<2 || time()-$started>DAY_IN_SECONDS) { return self::error('expired'); }
        if (self::text($input,'company_website')!=='' || self::text($input,'consent')!=='1') { return self::error('invalid'); }
        $datecode=self::integer($input,'date_code',1,PHP_INT_MAX); $match=null;
        foreach (PCVT_Sync::available_dates(get_post_meta($id,'_pcvt_dates',true)) as $date) {
            if ((int)$date['productPriceDateCode']===$datecode) { $match=$date; break; }
        }
        if (!$match) { return self::error('date'); }
        $first=sanitize_text_field(self::text($input,'first')); $last=sanitize_text_field(self::text($input,'last'));
        $email=self::text($input,'email'); $phone=sanitize_text_field(self::text($input,'phone'));
        $note=sanitize_textarea_field(self::text($input,'note'));
        $adults=self::integer($input,'adults',1,20); $children=self::integer($input,'children',0,20);
        if ($first==='' || $last==='' || self::length($first)>100 || self::length($last)>100 || strlen($email)>254 || !is_email($email) ||
            strlen($phone)>40 || !preg_match('/^[0-9+() .\-]{7,40}$/D',$phone) || strlen(preg_replace('/\D/','',$phone))<7 ||
            self::length($note)>1000 || $adults===false || $children===false || $adults+$children>20) { return self::error('invalid'); }
        $values=array('offer'=>get_the_title($id), 'offer_id'=>$id, 'code'=>get_post_meta($id,'_pcvt_code',true),
            'date'=>$match['dateDepart'], 'date_return'=>$match['dateReturn']??'', 'date_code'=>$datecode,
            'first'=>$first, 'last'=>$last, 'email'=>sanitize_email($email), 'phone'=>$phone,
            'adults'=>$adults, 'children'=>$children, 'note'=>$note);
        $fingerprint=hash_hmac('sha256',wp_json_encode($values),wp_salt('auth'));
        $submission_hash=hash_hmac('sha256',$submission,wp_salt('auth'));
        $lock=PCVT_Lock::acquire('request_'.$fingerprint,60);
        if (!$lock) { return self::error('busy'); }
        $submission_lock=PCVT_Lock::acquire('submission_'.$submission_hash,60);
        if (!$submission_lock) { PCVT_Lock::release($lock); return self::error('busy'); }
        try {
            foreach (array(array('_pcvt_submission_id',$submission_hash,DAY_IN_SECONDS),array('_pcvt_fingerprint',$fingerprint,15*MINUTE_IN_SECONDS)) as $dedup) {
                $existing=get_posts(array('post_type'=>'pcvt_request','post_status'=>array('private','publish','draft','trash'),
                    'meta_key'=>$dedup[0], 'meta_value'=>$dedup[1], 'fields'=>'ids', 'numberposts'=>1,
                    'date_query'=>array(array('column'=>'post_date_gmt','after'=>gmdate('Y-m-d H:i:s',time()-$dedup[2]),'inclusive'=>true))));
                if ($existing) { return array('id'=>(int)$existing[0],'duplicate'=>true); }
            }
            $ip=filter_var($remote_addr,FILTER_VALIDATE_IP) ? $remote_addr : 'unknown';
            $ratekey='pcvt_rl_'.hash_hmac('sha256',$ip,wp_salt('auth'));
            $rate_lock=PCVT_Lock::acquire($ratekey,30);
            if (!$rate_lock) { return self::error('busy'); }
            try {
                $rate=(int)get_transient($ratekey);
                if ($rate>=8) { return self::error('rate'); }
                set_transient($ratekey,$rate+1,15*MINUTE_IN_SECONDS);
            } finally { PCVT_Lock::release($rate_lock); }
            $values['consent']='Oui'; $values['consent_version']='0.2.0'; $values['consent_text']=self::CONSENT_TEXT;
            $values['privacy_policy_url']=get_privacy_policy_url(); $values['created']=current_time('mysql');
            $values['origin']='WordPress local; aucun transfert fournisseur'; $values['status']='new';
            $values['quoted_unit_price']=$match['total']; $values['currency']=$match['currency'];
            $values['catalogue_updated']=get_post_meta($id,'_pcvt_updated',true);
            $values['fingerprint']=$fingerprint; $values['submission_id']=$submission_hash;
            $meta=array(); foreach ($values as $key=>$value) { $meta['_pcvt_'.$key]=$value; }
            $record=wp_insert_post(wp_slash(array('post_type'=>'pcvt_request','post_status'=>'private',
                'post_title'=>'Demande '.substr(wp_generate_uuid4(),0,8).' — '.get_the_title($id), 'meta_input'=>$meta)),true);
            if (is_wp_error($record) || !$record) { return self::error('storage'); }
            self::notify($record);
            return array('id'=>(int)$record,'duplicate'=>false);
        } finally { PCVT_Lock::release($submission_lock); PCVT_Lock::release($lock); }
    }
    public static function notify($id) {
        $s=pcvt_settings(); $to=is_email($s['admin_email']) ? $s['admin_email'] : get_option('admin_email');
        $sent=wp_mail($to,'Nouvelle demande PCV #'.$id,
            'Une demande locale est disponible dans votre administration : '.admin_url('post.php?post='.$id.'&action=edit')."\nAucune réservation ni place confirmée chez le fournisseur.");
        update_post_meta($id,'_pcvt_notification',$sent ? 'sent' : 'failed');
        return $sent;
    }
    public static function statuses() { return array('new'=>'Nouvelle','in_progress'=>'En traitement','contacted'=>'Client contacté','closed'=>'Fermée','cancelled'=>'Annulée'); }
}
