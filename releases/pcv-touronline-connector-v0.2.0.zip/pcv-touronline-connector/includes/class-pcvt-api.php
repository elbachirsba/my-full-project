<?php
if (!defined('ABSPATH')) { exit; }
final class PCVT_API {
    const ORIGIN = 'https://api.touronline.shop';
    public static function request($method, $path, $query=array(), $json=null) {
        if ($method !== 'GET') { return new WP_Error('pcvt_method','Les écritures fournisseur ne sont pas activées.'); }
        if (!is_string($path) || !preg_match('#^/(?:Setting/v1\.0/setting|ProductGroup/v1\.0|Product/v1\.0/[A-Za-z0-9_%~.\-]+(?:/(?:dates|images|options))?)$#D', $path)) {
            return new WP_Error('pcvt_path','Chemin API invalide.');
        }
        $decoded = rawurldecode($path);
        $parts=explode('/',$path);
        if ($parts[1]==='Product' && preg_match('~[\x00-\x20/\\\\?#%]~',rawurldecode($parts[3]))) {
            return new WP_Error('pcvt_path','Code produit invalide.');
        }
        if (preg_match('~(?:^|/)\.{1,2}(?:/|$)|[\x00-\x20\\\\?#]~', $decoded)) {
            return new WP_Error('pcvt_path','Code produit invalide.');
        }
        $license = pcvt_license();
        if (!$license || preg_match('/[\r\n]/', $license)) { return new WP_Error('pcvt_no_license','Licence TourOnline absente ou invalide.'); }
        $headers = array('License'=>$license, 'Accept'=>'application/json');
        if (defined('PCVT_BEARER_TOKEN') && is_string(PCVT_BEARER_TOKEN) && PCVT_BEARER_TOKEN !== '') {
            if (preg_match('/[\r\n]/', PCVT_BEARER_TOKEN)) { return new WP_Error('pcvt_token','Jeton Bearer invalide.'); }
            $headers['Authorization'] = 'Bearer '.PCVT_BEARER_TOKEN;
        }
        $url = self::ORIGIN.$path;
        if ($query) { $url = add_query_arg($query, $url); }
        $response = wp_safe_remote_request($url, array('method'=>'GET', 'headers'=>$headers,
            'timeout'=>10, 'redirection'=>0, 'sslverify'=>true, 'reject_unsafe_urls'=>true,
            'limit_response_size'=>4*MB_IN_BYTES+1));
        if (is_wp_error($response)) { return new WP_Error('pcvt_transport','Connexion réseau/TLS au fournisseur impossible.', array('retryable'=>true)); }
        $status = (int)wp_remote_retrieve_response_code($response);
        if ($status < 200 || $status >= 300) {
            $retry = wp_remote_retrieve_header($response,'retry-after');
            $retry = is_scalar($retry) ? (string)$retry : '';
            $delay = is_numeric($retry) ? (int)$retry : max(0, (int)strtotime((string)$retry)-time());
            return new WP_Error('pcvt_http','Réponse fournisseur HTTP '.$status.'.',
                array('status'=>$status, 'retryable'=>$status===429 || $status>=500, 'retry_after'=>min(HOUR_IN_SECONDS,max(30,$delay))));
        }
        $body = wp_remote_retrieve_body($response);
        if (strlen($body)>4*MB_IN_BYTES) { return new WP_Error('pcvt_size','Réponse fournisseur trop volumineuse.'); }
        // Associative JSON decoding maps both {} and [] to array(); keep list schemas distinct.
        $expects_list=$path==='/ProductGroup/v1.0' || preg_match('#/(?:dates|images)$#D',$path);
        if ($expects_list && substr(ltrim($body),0,1)!=='[') { return new WP_Error('pcvt_json','Liste JSON attendue pour cette route fournisseur.'); }
        $data = json_decode($body,true,64);
        if (json_last_error()!==JSON_ERROR_NONE || !is_array($data)) {
            return new WP_Error('pcvt_json','Réponse fournisseur JSON non structurée ou invalide.');
        }
        return $data;
    }
    public static function setting() { return self::request('GET','/Setting/v1.0/setting'); }
    public static function groups() { return self::request('GET','/ProductGroup/v1.0'); }
    public static function product($code, $date_code=null) {
        return self::request('GET','/Product/v1.0/'.rawurlencode($code), $date_code!==null ? array('DateCode'=>(int)$date_code) : array());
    }
    public static function dates($code) { return self::request('GET','/Product/v1.0/'.rawurlencode($code).'/dates'); }
    public static function images($code) { return self::request('GET','/Product/v1.0/'.rawurlencode($code).'/images'); }
    public static function options($code, $query=array()) { return self::request('GET','/Product/v1.0/'.rawurlencode($code).'/options',$query); }
    public static function preview($body) { return new WP_Error('pcvt_disabled','Prévisualisation fournisseur en attente de validation métier.'); }
}
