<?php
/**
 * Plugin Name: PCV TourOnline Connector
 * Description: Catalogue TourOnline synchronisé en arrière-plan et demandes locales de réservation sans paiement.
 * Version: 0.2.0
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Author: Projet PC Voyages / WordPress
 * License: GPL-2.0-or-later
 * Text Domain: pcvt
 */
if (!defined('ABSPATH')) { exit; }
define('PCVT_VERSION', '0.2.0');
define('PCVT_PLUGIN_FILE', __FILE__);
define('PCVT_DIR', plugin_dir_path(__FILE__));
define('PCVT_URL', plugin_dir_url(__FILE__));

function pcvt_settings() {
    $defaults = array('license'=>'', 'enabled_sync'=>0, 'lang'=>'fr', 'admin_email'=>'',
        'last_sync'=>'', 'last_result'=>'', 'retention_days'=>180, 'unpublish_missing'=>0, 'batch_size'=>3);
    $settings = get_option('pcvt_settings', null);
    // Upgrades must not silently enable deletion of previously retained customer data.
    if (is_array($settings) && !array_key_exists('retention_days',$settings)) { $defaults['retention_days']=0; }
    return wp_parse_args(is_array($settings) ? $settings : array(), $defaults);
}
function pcvt_license() {
    if (defined('PCVT_LICENSE') && is_string(PCVT_LICENSE)) { return trim(PCVT_LICENSE); }
    return trim((string) pcvt_settings()['license']);
}
foreach (array('lock', 'api', 'sync', 'requests', 'privacy', 'admin', 'frontend') as $pcvt_component) {
    require_once PCVT_DIR.'includes/class-pcvt-'.$pcvt_component.'.php';
}
unset($pcvt_component);

function pcvt_register_types() {
    register_post_type('pcvt_offer', array(
        'labels'=>array('name'=>'Offres PC Voyages', 'singular_name'=>'Offre PC Voyages'),
        'public'=>true, 'show_in_rest'=>true, 'has_archive'=>true,
        'menu_icon'=>'dashicons-palmtree', 'supports'=>array('title','editor','excerpt'),
        'rewrite'=>array('slug'=>'offres-pcv'),
    ));
    // Personal data must not inherit the default editor/author post capabilities.
    $caps = array_fill_keys(array('edit_post','read_post','delete_post','edit_posts','edit_others_posts',
        'publish_posts','read_private_posts','delete_posts','delete_private_posts','delete_published_posts',
        'delete_others_posts','edit_private_posts','edit_published_posts','read'), 'manage_options');
    $caps['create_posts'] = 'do_not_allow';
    register_post_type('pcvt_request', array(
        'labels'=>array('name'=>'Demandes PCV', 'singular_name'=>'Demande PCV'),
        'public'=>false, 'publicly_queryable'=>false, 'exclude_from_search'=>true,
        'show_ui'=>true, 'show_in_rest'=>false, 'menu_icon'=>'dashicons-tickets-alt',
        'supports'=>array('title'), 'capabilities'=>$caps, 'map_meta_cap'=>false,
    ));
}
add_action('init', 'pcvt_register_types');
add_filter('cron_schedules', function($schedules) {
    $schedules['pcvt_quarter_hour'] = array('interval'=>900, 'display'=>'Toutes les 15 minutes (PCVT)');
    return $schedules;
});
function pcvt_schedule() {
    $s = pcvt_settings();
    if (!empty($s['enabled_sync']) && pcvt_license()) {
        if (!wp_next_scheduled('pcvt_sync_event')) { wp_schedule_event(time()+60, 'pcvt_quarter_hour', 'pcvt_sync_event'); }
    } else {
        wp_clear_scheduled_hook('pcvt_sync_event');
    }
    if (!wp_next_scheduled('pcvt_retention_event')) { wp_schedule_event(time()+HOUR_IN_SECONDS, 'daily', 'pcvt_retention_event'); }
}
add_action('init', 'pcvt_schedule', 20);
add_action('pcvt_sync_event', function() {
    if (!empty(pcvt_settings()['enabled_sync']) && pcvt_license()) { PCVT_Sync::run(); }
});
add_action('pcvt_sync_batch', array('PCVT_Sync','worker'));
add_action('pcvt_retention_event', array('PCVT_Privacy','cleanup'));
register_activation_hook(__FILE__, function() {
    add_option('pcvt_settings',pcvt_settings(),'',false);
    pcvt_register_types(); pcvt_schedule(); flush_rewrite_rules();
});
register_deactivation_hook(__FILE__, function() {
    foreach (array('pcvt_sync_event','pcvt_sync_batch','pcvt_retention_event') as $hook) { wp_clear_scheduled_hook($hook); }
    flush_rewrite_rules();
});
add_action('init', array('PCVT_Sync','resume'), 30);
add_action('wp_enqueue_scripts', function() {
    wp_register_style('pcvt-style', PCVT_URL.'assets/pcvt.css', array(), PCVT_VERSION);
    wp_register_script('pcvt-form', PCVT_URL.'assets/pcvt-form.js', array(), PCVT_VERSION, true);
    if (is_singular('pcvt_offer')) { wp_enqueue_style('pcvt-style'); wp_enqueue_script('pcvt-form'); }
});
add_action('rest_api_init', function() {
    register_rest_route('pcvt/v1', '/form/(?P<id>\d+)', array(
        'methods'=>'GET', 'permission_callback'=>'__return_true',
        'callback'=>array('PCVT_Requests','form_token'),
        'args'=>array('id'=>array('sanitize_callback'=>'absint')),
    ));
});
if (defined('WP_CLI') && WP_CLI) {
    WP_CLI::add_command('pcvt status', function() { WP_CLI::line(wp_json_encode(PCVT_Sync::state(), JSON_PRETTY_PRINT)); });
    WP_CLI::add_command('pcvt sync', function($args, $assoc) {
        $result = PCVT_Sync::run();
        if (is_wp_error($result)) { WP_CLI::error($result->get_error_message()); }
        if (isset($assoc['wait'])) {
            do {
                PCVT_Sync::worker(); $state=PCVT_Sync::state();
                if (!empty($state['next_attempt']) && $state['next_attempt']>time()) {
                    WP_CLI::error('Fournisseur temporairement indisponible. La reprise est planifiée; consulter wp pcvt status.');
                }
            }
            while (isset($state['status']) && $state['status']==='running');
            if (empty($state['status']) || $state['status']!=='completed') { WP_CLI::error('Synchronisation interrompue : consulter pcvt status.'); }
            if (!empty($state['failed'])) { WP_CLI::error('Import partiel : '.(int)$state['failed'].' produits en erreur.'); }
        }
        WP_CLI::success('Synchronisation '.(isset($assoc['wait']) ? 'terminée' : 'planifiée').'.');
    });
}
