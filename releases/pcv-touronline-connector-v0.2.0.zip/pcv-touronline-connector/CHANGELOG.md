# Historique

## 0.2.0 — 19 octobre 2026

- Import en arrière-plan, lots réglables, file persistante séparée des checkpoints, reprise et annulation; suppression du blocage sur les 50 premiers produits.
- Verrous atomiques et propriétaire de verrou; nettoyage des verrous expirés.
- Reprises différées bornées pour réseau/429/5xx, respect de Retry-After, conservation des anciennes fiches si les dates sont invalides.
- Vérification des schémas JSON, tailles, dates, codes, prix et images; photos réutilisées 24 h et panne photo non bloquante.
- Mise à jour conditionnelle des fiches, conservation des statuts manuels et appartenances multiples aux groupes.
- Politique optionnelle de dépublication après deux snapshots complets sans le produit.
- Pagination, recherche, filtre, galerie responsive, formulaire accessible et chargement ciblé des ressources.
- Formulaires signés, renouvellement des jetons sur pages mises en cache, validation serveur et dédoublonnage concurrent.
- Accès aux demandes réservé aux administrateurs, suivi interne et résultat de notification avec renvoi.
- Export/effacement WordPress, consentement historisé et conservation configurable; migration sans purge implicite des demandes 0.1.0.
- Désinstallation avec conservation par défaut et suppression uniquement sur option explicite.
- Commandes WP-CLI, diagnostic Santé du site, documentation et suites de validation.
- Écritures fournisseur et preview désactivés explicitement en attente d’un parcours métier vérifié.

## 0.1.0

Pilote initial fourni : catalogue, appels de lecture synchrones et demandes locales sans paiement.
