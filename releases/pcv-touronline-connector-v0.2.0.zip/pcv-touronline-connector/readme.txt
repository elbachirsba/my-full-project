=== PCV TourOnline Connector ===
Contributors: Projet PC Voyages / WordPress
Tags: travel, catalogue, touronline
Requires at least: 6.2
Tested up to: 6.8.3
Requires PHP: 7.4
Stable tag: 0.2.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Catalogue TourOnline synchronisé en arrière-plan et demandes locales privées sans paiement.

== Description ==
Import par lots, reprise, pagination, recherche, suivi des demandes, export/effacement des données et conservation configurable. Une licence TourOnline est nécessaire pour accéder au catalogue réel.

Aucune réservation, facture, inscription client ou opération de paiement n'est créée chez le fournisseur. Les prix et disponibilités sont indicatifs. Consulter README.md pour le fonctionnement et les limitations.

== Installation ==
1. Installer et activer le ZIP dans WordPress, de préférence en préproduction.
2. Configurer la licence dans PCV TourOnline ou PCVT_LICENSE dans wp-config.php.
3. Tester la connexion, démarrer l'import et vérifier la progression WP-Cron.
4. Insérer [pcvt_offres limit="12"] dans une page.
5. Choisir la politique de conservation et tester les notifications sur votre hébergement.

== Changelog ==
= 0.2.0 =
Import en arrière-plan et reprise, photos réutilisées, dédoublonnage, droits d'accès renforcés, pagination, suivi, confidentialité et documentation. Voir CHANGELOG.md.
