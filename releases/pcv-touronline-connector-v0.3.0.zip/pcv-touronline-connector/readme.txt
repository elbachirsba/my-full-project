=== PCV TourOnline Connector ===
Contributors: Projet PC Voyages / WordPress
Tags: travel, catalogue, touronline, booking
Requires at least: 6.2
Tested up to: 6.8.3
Requires PHP: 7.4
Stable tag: 0.3.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Catalogue TourOnline, CRM agent, acompte en espèces et réservation/facturation après validation.

== Description ==
Catalogue paginé et import par lots. Dossiers privés, rôle Agent PCV, devis fournisseur, registre des encaissements en centimes, minimum configurable et confirmation agent. Parcours fournisseur désactivé par défaut.

Après validation de l'agent et des données : réservation, voyageurs, facture avec paiement en ligne désactivé, puis envoi du PDF. Les créations incertaines passent en vérification manuelle et ne sont pas retentées aveuglément.

Le registre cash est local à WordPress : l'API fournie ne permet pas de reporter les espèces dans PC Voyages. Les soldes sont affichés séparément. Licence réelle, association client, effet sur les places, SMTP et Cron à vérifier en préproduction. Voir README.md.

== Installation ==
1. Installer le ZIP et activer en préproduction.
2. Configurer la licence et le JWT si requis, puis importer le catalogue.
3. Insérer [pcvt_offres limit="12"] dans une page.
4. Choisir la règle d'acompte et attribuer le rôle Agent PCV.
5. Vérifier le parcours avec le fournisseur, puis activer explicitement le parcours agent.
6. Configurer un Cron régulier et tester la messagerie.

== Changelog ==
= 0.3.0 =
Parcours agent avec acompte en espèces, réservation, voyageurs, facture et envoi PDF; contrôles de concurrence, reprise et confidentialité. Voir CHANGELOG.md.
