# PCV TourOnline Connector 0.3.0

Catalogue TourOnline et CRM de demandes dans WordPress, avec **acompte reçu en espèces puis validé par un agent**, réservation fournisseur, facture et envoi PDF automatisés.

WordPress 6.2+ · PHP 7.4+ · OpenSSL AES-256-GCM pour les réservations. Aucun WooCommerce, Composer ou service JavaScript externe requis. Le banc de validation utilise WordPress 6.8.3, PHP 8.4 et l’adaptateur SQLite officiel; la licence réelle et MySQL/MariaDB du site cible restent à tester.

## Parcours retenu

1. Le client choisit une offre et un départ, puis envoie sa demande avec ses coordonnées.
2. L’agent ouvre **Demandes PCV**, vérifie le tarif fournisseur, les classes, catégories, arrêts et options éventuelles.
3. Le CRM affiche le **total du groupe** et le **minimum à recevoir**, retournés/calculés à partir de la prévisualisation fournisseur.
4. L’agent enregistre les voyageurs, puis le ou les montants effectivement reçus en espèces. Un solde peut être reçu plus tard.
5. Lorsque le minimum est atteint, l’agent atteste le règlement et l’autorisation du client, puis confirme le dossier.
6. Le traitement en arrière-plan revérifie les prix, disponibilités et conditions, crée la réservation, récupère ses emplacements voyageurs et transmet leurs renseignements.
7. Il crée la facture avec `isPaymentDisabled: true`, vérifie les références et montants, puis joint le PDF fournisseur au courriel destiné au client.
8. Le CRM conserve les références, le suivi d’envoi et l’historique. Si un résultat est incertain, il passe en vérification manuelle.

**Aucune place n’est annoncée comme réservée sur la seule base d’une demande ou d’un versement WordPress.** La création fournisseur et ses références sont affichées. L’effet exact de cette création sur l’inventaire, son expiration et le rattachement comptable au client doivent être vérifiés avec votre licence en préproduction.

## Limite importante sur les espèces

L’OpenAPI fourni décrit la réservation, les voyageurs, la facturation et des pages de paiement hébergées, mais **aucune opération pour enregistrer un reçu d’espèces dans PC Voyages**.

Le plugin enregistre donc l’encaissement et le solde **dans WordPress**. Le solde retourné par PC Voyages est affiché séparément et n’est jamais falsifié pour imiter un paiement fournisseur. La facture PDF fournisseur peut encore afficher le total impayé tant que votre agence n’a pas reporté les espèces dans PC Voyages. Le courriel l’indique avec les montants enregistrés en agence.

Pour automatiser ce rapprochement comptable, le fournisseur doit fournir une opération d’encaissement comptant ou une autre méthode officiellement prise en charge. La création de facture avec `isPaymentDisabled` ne constitue pas un enregistrement de paiement cash.

## Installation et configuration

1. Sauvegarder le site et sa base, puis utiliser une préproduction avec de faux dossiers.
2. Installer le ZIP depuis Extensions → Ajouter → Téléverser. En mise à jour, remplacer le dossier existant `pcv-touronline-connector`.
3. Ouvrir **PCV TourOnline** et configurer la licence. Préférer dans `wp-config.php` :

   ```php
   define('PCVT_LICENSE', 'VOTRE_LICENCE');
   // Si requis et fourni par TourOnline :
   define('PCVT_BEARER_TOKEN', 'VOTRE_JETON');
   ```

   Une constante a priorité. La licence saisie dans les réglages est stockée dans la base sans chiffrement et n’est pas réaffichée. Les jetons des réservations, eux, sont chiffrés avec les clés de sécurité WordPress; conserver ces clés dans les sauvegardes. Une rotation de ces clés peut rendre les anciens jetons illisibles.
4. Tester la connexion, démarrer l’import et vérifier quelques fiches. Seules les offres accessibles avec la licence TourOnline sont importées; un catalogue PCVWeb classique n’est pas automatiquement équivalent.
5. Créer une page contenant `[pcvt_offres limit="12"]`.
6. Dans les réglages, choisir le minimum à encaisser : **fournisseur** (défaut), **pourcentage**, **montant fixe** ou **total**. Une valeur de pourcentage/montant fixe n’est utilisée que dans le mode choisi.
7. Le minimum ne descend jamais sous l’acompte fournisseur connu et ne dépasse pas le total. En mode fournisseur, un acompte retourné nul entraîne une demande de paiement intégral; ce n’est pas une réservation gratuite par défaut.
8. Configurer, si la licence le demande, les références agent/utilisateur fournisseur. La référence utilisateur peut être précisée pour chaque demande. Utiliser uniquement une association client validée chez le fournisseur, sans recopier un identifiant WordPress ou créer un compte par supposition.
9. Attribuer le rôle **Agent PCV** aux personnes autorisées. Les administrateurs conservent l’accès aux réglages et aux rapprochements sensibles.
10. Activer explicitement **Parcours de réservation agent** après vos essais de préproduction. Il est désactivé par défaut; l’installation seule ne crée aucune réservation réelle.

## Utilisation par l’agent

Depuis un dossier dans **Demandes PCV** :

- **Vérifier le prix et l’acompte**. Un premier clic peut charger des tarifs actualisés; sélectionner ensuite la classe et la catégorie. Les options sont chargées avec le contexte de prix, à vérifier explicitement avant le devis. Les quantités et disponibilités des options sont contrôlées. Le prix du groupe provient de l’API, et non d’une multiplication du prix d’appel.
- **Enregistrer les voyageurs** : tous les noms sont nécessaires. Les dates de naissance sont envoyées lorsqu’elles sont renseignées, sans date fictive inventée. Les champs supplémentaires obligatoires propres au fournisseur restent à vérifier sur la licence réelle.
- **Enregistrer les espèces reçues** : montant et devise du devis, référence du reçu, attestation de réception. Plusieurs versements sont possibles; le total ne peut pas dépasser le prix vérifié. Un formulaire rejoué ne crée pas une deuxième écriture.
- **Valider le règlement et créer le dossier fournisseur** : devis de moins de 15 minutes, acompte minimum reçu, voyageurs et autorisation de transmission requis. Si le fournisseur impose des conditions, faire accepter la version affichée au client.
- Actualiser le dossier pour suivre les étapes. Le suivi interne « Nouvelle / En traitement / Fermée… » n’annule ni ne crée de réservation fournisseur; le bloc du dossier PC Voyages fait foi sur les références connues.

Les écritures de caisse restent conservées. Avant transmission, une erreur de saisie peut être corrigée avec une contre-écriture motivée. Après engagement du fournisseur, les corrections et remboursements doivent être traités manuellement et rapprochés dans les deux systèmes; le plugin n’effectue aucun remboursement bancaire ni annulation automatique.

Le rôle Agent PCV peut traiter les demandes, mais ne peut ni modifier les réglages de licence ni supprimer les dossiers et leur historique. Les outils administratifs de confidentialité et la suppression par un administrateur restent disponibles.

## Incidents et reprises

La création d’une réservation ou facture peut réussir chez le fournisseur malgré une réponse réseau perdue. Le plugin sauvegarde l’étape **avant** chaque écriture et ne renvoie jamais automatiquement un POST de création incertain.

- La référence reçue est conservée dès que possible; les jetons ne sont pas affichés.
- Une interruption pendant une création ou une réponse invalide provoque une **vérification manuelle**.
- Si la création a réussi, un administrateur peut rattacher la réservation connue (code et jeton) ou la facture connue (facture et dossier), après vérification de l’appartenance au client. Les données produit, départ, total et devise sont contrôlées. L’API de détail de facture ne prouve pas à elle seule l’association à une réservation; cette association doit être vérifiée dans PC Voyages.
- Une nouvelle tentative de création exige l’attestation administrative que l’opération n’a pas abouti, avec motif enregistré. Ne pas attester une absence sur un simple timeout.
- Une erreur de messagerie conserve la réservation et la facture. **Renvoyer uniquement la facture** ne recrée aucun dossier fournisseur. Un succès `wp_mail` indique l’acceptation de l’envoi, sans prouver la réception en boîte de réception.
- Un changement de prix, de disponibilité, de conditions ou de licence bloque la suite avant une nouvelle création et conserve les paiements déjà enregistrés pour traitement par l’agent.

Les voyageurs utilisent les indices réellement retournés par `GET /Reservation/...`; des indices ambigus ou un nombre de voyageurs incohérent arrêtent le traitement. Le mapping de ces indices, des chambres, catégories et comptes doit être vérifié avec des réponses réelles de votre licence.

## Exécution automatique : Cron indispensable

Chaque étape est persistante et traite un nombre limité d’appels. **Un Cron système régulier est recommandé pour ce parcours financier**, particulièrement sur un site peu fréquenté. Les processus ne restent pas actifs entre les requêtes; une simple confirmation agent ne garantit pas une exécution immédiate sur un site sans trafic.

Exécuter chaque minute depuis le répertoire WordPress, avec WP-CLI et les mêmes variables/configuration que le site :

```sh
wp cron event run --due-now --quiet
```

WP-Cron natif reste utilisable avec du trafic, mais sa cadence n’est pas garantie. Les étapes peuvent prendre plusieurs cycles de Cron. Les prévisions de prix sont revérifiées; une disponibilité vérifiée trop anciennement est contrôlée de nouveau avant création. Les travaux interrompus sont repris ou placés en vérification selon leur étape. La désactivation arrête les événements; la réactivation réenregistre les travaux en attente.

Pour le catalogue :

```sh
wp pcvt status
wp pcvt sync
wp pcvt sync --wait
```

`--wait` traite l’import catalogue, pas les réservations financières. Une reprise différée fournisseur sort sans attente active et reste planifiée.

## Catalogue et shortcodes

```text
[pcvt_offres]
[pcvt_offres limit="12"]
[pcvt_offres group="Nom du groupe" limit="12"]
[pcvt_offres filters="0"]
[pcvt_reservation post_id="123"]
```

Pagination de 1 à 100 offres par page, recherche et filtre, appartenances à plusieurs groupes, galerie et formulaire responsive. Préférer un catalogue par page pour éviter des contrôles partageant les mêmes paramètres d’URL.

Import par lots de 3 produits, réglables de 1 à 10. File séparée des checkpoints, reprise, verrou atomique, annulation et réécriture seulement des fiches modifiées. Photos réutilisées pendant 24 h; leur panne ne bloque pas un produit valide. Réponses JSON bornées à 4 Mio et catalogue limité explicitement à 5 000 produits. Ce plafond n’est pas un résultat de test de charge.

Dépublication optionnelle après deux imports complets réussis et non vides sans le produit. Les brouillons et suppressions manuels sont préservés. L’import reste propriétaire du texte et du titre des fiches; placer vos textes éditoriaux durables ailleurs.

Les dates/prix publics sont des snapshots indicatifs; le devis agent est vérifié séparément. Les formulaires sont signés et renouvelés via une route WordPress du même site. Exclure `/wp-json/pcvt/v1/form/*` et son équivalent `?rest_route=/pcvt/v1/form/*` des caches forcés; les réponses indiquent `Cache-Control: no-store`. Sans JavaScript, une page récente reste utilisable. La limitation à 8 nouvelles demandes par 15 minutes/adresse hachée ne remplace pas une protection anti-abus de l’hébergeur.

## Confidentialité et documents

Les demandes ne sont pas publiques et n’ont pas de route REST publique. Les données nécessaires sont transmises au fournisseur uniquement dans le parcours autorisé et approuvé. Le client autorise cette transmission ou l’agent en atteste après l’avoir obtenue; la date, l’agent et les conditions sont historisés.

Les outils WordPress exportent les coordonnées, voyageurs, encaissements et références. Les jetons chiffrés ne sont pas exportés. L’effacement explicite supprime le dossier local et arrête ses tâches, mais ne supprime pas une réservation, une facture, un courriel déjà envoyé ou une sauvegarde chez un tiers.

La purge automatique réglable vise les anciennes demandes **sans données financières**. Les dossiers avec encaissement ou référence fournisseur sont conservés pour gestion manuelle. Une nouvelle installation propose 180 jours pour les demandes non financières; une migration de 0.1.0 conserve le mode manuel si aucun choix antérieur n’existe. Adapter votre politique et les sauvegardes aux obligations de votre agence.

La facture est récupérée uniquement depuis les routes HTTPS connues de `api.touronline.shop`, sans transmettre de licence à un domaine arbitraire. Le PDF est vérifié, attaché depuis un fichier temporaire privé, puis ce fichier est supprimé. Aucun PDF n’est publié dans la médiathèque. Si le répertoire temporaire du serveur se trouve sous la racine web, configurer un dossier privé réellement hors de cette racine :

```php
define('PCVT_PRIVATE_DIR', '/chemin/prive/hors-racine-web');
```

Un autre domaine d’hébergement des factures nécessite un contrat fournisseur et une adaptation contrôlée; le plugin n’ouvre pas une URL arbitraire. Les images de catalogue sont chargées directement par le navigateur en HTTPS; leur hébergeur voit l’adresse réseau du visiteur.

## Désinstallation

Désactivation : tâches arrêtées, données conservées. Désinstallation : données conservées par défaut. Pour demander explicitement leur suppression définitive lors de la désinstallation :

```php
define('PCVT_REMOVE_DATA_ON_UNINSTALL', true);
```

Cela retire les contenus, métadonnées, options, tâches et rôle PCVT. La constante de licence dans `wp-config.php`, les sauvegardes, courriels envoyés et données fournisseur doivent être gérés séparément. Aucune annulation de voyage ou de facture n’est envoyée pendant cette suppression.

## Validation et limites restantes

Les tests emploient de véritables fonctions WordPress, écritures en base, sessions navigateur et processus concurrents, avec API fournisseur et courriels simulés/interceptés. Aucun paiement ou dossier réel n’a été créé pendant le développement.

Avant usage réel, tester la licence/JWT, l’association du client, les voyageurs/chambres/options, le blocage et l’expiration des places, les factures et leur PDF, SMTP, Cron et MySQL/MariaDB sur votre hébergement. L’OpenAPI ne documente pas de garantie d’idempotence des créations ni d’opération de reçu cash; les reprises et soldes ont été conçus en conséquence.

Voir `BILAN_AMELIORATIONS.md`, `CHANGELOG.md` et les tests fournis séparément. `BILAN_TECHNIQUE.md` et `BILAN_AMELIORATIONS_v0.2.0.md` sont des archives des versions précédentes.
