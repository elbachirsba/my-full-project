<?php
if (!defined('WP_UNINSTALL_PLUGIN')) { exit; }
// Retain offers and customer records unless the site owner explicitly opts in via wp-config.php.
if (!defined('PCVT_REMOVE_DATA_ON_UNINSTALL') || PCVT_REMOVE_DATA_ON_UNINSTALL!==true) { return; }
foreach (array('pcvt_offer','pcvt_request') as $type) {
    if (!post_type_exists($type)) { register_post_type($type,array('public'=>false)); }
    do {
        $ids=get_posts(array('post_type'=>$type,'post_status'=>array('publish','private','draft','pending','future','trash','auto-draft'),
            'fields'=>'ids','numberposts'=>100,'orderby'=>'ID','order'=>'ASC'));
        $removed=0;
        foreach ($ids as $id) { if (wp_delete_post($id,true)) { $removed++; } }
    } while (count($ids)===100 && $removed>0);
}
foreach (array('pcvt_sync_event','pcvt_sync_batch','pcvt_retention_event','pcvt_booking_step') as $hook) { wp_unschedule_hook($hook); }
foreach (array('pcvt_settings','pcvt_sync_state','pcvt_sync_queue','pcvt_schema_version') as $key) { delete_option($key); }
global $wpdb;
foreach (array('pcvt_lock_','pcvt_pending_booking_','_transient_pcvt_','_transient_timeout_pcvt_') as $prefix) {
    $keys=$wpdb->get_col($wpdb->prepare("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",$wpdb->esc_like($prefix).'%'));
    foreach ($keys as $key) { delete_option($key); }
}
delete_option('rewrite_rules');
remove_role('pcvt_agent');
$pcvt_admin_role=get_role('administrator');
if ($pcvt_admin_role) { $pcvt_admin_role->remove_cap('manage_pcvt_bookings'); }
