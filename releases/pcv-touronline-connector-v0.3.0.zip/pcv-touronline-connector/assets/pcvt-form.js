/* Renew cached form credentials without sending any customer data to a third party. */
(function () {
    'use strict';
    document.querySelectorAll('.pcvt-request-form').forEach(function (form) {
        var button = form.querySelector('button[type="submit"]');
        var message = form.querySelector('.pcvt-form-message');
        var readyAt = 0;
        var pending = null;
        function refresh() {
            if (pending) { return pending; }
            var headers = {};
            if (form.dataset.restNonce) { headers['X-WP-Nonce'] = form.dataset.restNonce; }
            pending = fetch(form.dataset.tokenUrl, { credentials: 'same-origin', cache: 'no-store', headers: headers })
                .then(function (response) { if (!response.ok) { throw new Error('token'); } return response.json(); })
                .then(function (data) {
                    ['pcvt_nonce', 'pcvt_started', 'pcvt_submission', 'pcvt_signature'].forEach(function (key) {
                        if (!data[key] || !form.elements[key]) { throw new Error('fields'); }
                    });
                    Object.keys(data).forEach(function (key) { if (form.elements[key]) { form.elements[key].value = data[key]; } });
                    readyAt = Date.now() + 2100;
                }).catch(function () {
                    // The server-rendered signed credentials remain usable without JavaScript/REST.
                }).finally(function () { pending = null; });
            return pending;
        }
        refresh();
        form.addEventListener('submit', function (event) {
            var adults = Number(form.elements.adults.value);
            var children = Number(form.elements.children.value);
            if (adults + children > 20) {
                event.preventDefault(); message.textContent = 'La demande doit compter au plus 20 voyageurs.'; return;
            }
            if (pending || Date.now() < readyAt) {
                event.preventDefault(); message.textContent = 'Veuillez patienter quelques secondes puis envoyer votre demande.'; return;
            }
            // Refresh if a visitor leaves a tab open beyond the signed form validity.
            if (Date.now() / 1000 - Number(form.elements.pcvt_started.value) > 3600) {
                event.preventDefault(); message.textContent = 'Formulaire actualisé. Vous pourrez envoyer votre demande dans quelques secondes.'; refresh(); return;
            }
            button.disabled = true; message.textContent = 'Envoi en cours…';
        });
        window.addEventListener('pageshow', function () { button.disabled = false; });
    });
}());
