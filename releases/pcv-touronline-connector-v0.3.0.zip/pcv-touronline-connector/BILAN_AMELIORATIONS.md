# PCV TourOnline Connector 0.3.0 — acompte validé par l’agent

Date : 19 octobre 2026. Cette version complète 0.2.0 à partir du document OpenAPI `TourOnline_Gateway` 1.0 transmis et du parcours demandé : le client soumet sa demande, l’agence reçoit des espèces, puis l’agent valide le règlement avant transmission fournisseur et facturation.

## Fonctionnement livré

Le plugin propose un CRM opérationnel dans **Demandes PCV**, avec un rôle **Agent PCV** et un parcours de réservation désactivé par défaut.

L’agent obtient le prix du groupe par `POST /Reservation/v1.0/preview`, avec les codes de départ, classes, catégories, chambres, arrêt et options sélectionnés. Les options sont contrôlées avec le contexte documenté de `/Product/.../options`. Le total et l’acompte viennent du fournisseur; le registre ne multiplie pas simplement le prix d’appel de la fiche publique.

Le minimum local peut suivre le fournisseur, un pourcentage, un montant fixe ou le total. Il ne descend pas sous l’acompte fournisseur et ne dépasse pas le total. Les écritures sont en centimes entiers, avec agent, date et référence du reçu. Des versements successifs sont permis; un montant dépassant le solde, une mauvaise devise ou un identifiant de reçu rejoué avec un autre montant sont refusés.

La confirmation exige un devis récent, le minimum effectivement enregistré, tous les noms des voyageurs et l’autorisation du client. Les conditions fournisseur sont présentées lorsqu’elles sont requises. Les renseignements restent locaux avant cette validation.

Après validation, le traitement en arrière-plan :

1. Revérifie le départ, le prix, le minimum et les conditions.
2. Crée la réservation et conserve ses références.
3. Lit les emplacements voyageurs effectivement retournés, puis envoie les voyageurs par `PUT /Pax/v1.0`.
4. Crée la facture par `POST /Invoice/v1.0` avec `isPaymentDisabled: true`.
5. Vérifie la facture et son montant, récupère le PDF depuis les routes autorisées, puis l’attache au courriel du client.

La progression et les résultats sont visibles dans le CRM. Les voyageurs et les événements restent consultables; le jeton fournisseur n’est pas affiché.

## Exemple de minimum

Exemple fictif : total fournisseur de **1 000 CAD**, acompte fournisseur de **200 CAD**, règle agence de **30 %**.

| Élément | Résultat |
|---|---:|
| Minimum à recevoir en agence | 300 CAD |
| Premier versement reçu | 100 CAD — confirmation refusée |
| Second versement reçu | 200 CAD — minimum atteint |
| Solde suivi dans WordPress | 700 CAD |

Le paiement peut aussi être intégral. Une règle de pourcentage n’est pas activée arbitrairement sur votre site : le mode par défaut suit le fournisseur, et l’administrateur choisit sa politique.

## Encaissement cash : limite de l’OpenAPI

Le document fourni ne comporte pas de route permettant d’enregistrer un reçu d’espèces dans PC Voyages. Les opérations Payment concernent des pages de paiement hébergées et l’annulation d’une transaction reçue; elles ne décrivent pas un dépôt cash.

Le plugin ne fabrique donc pas de reçu fournisseur et ne marque pas sa facture comme payée par supposition. Il conserve un **solde agence WordPress** et le **solde retourné par PC Voyages**, distincts. La facture PDF est celle du fournisseur; le courriel rappelle les encaissements agence et la possible différence de solde jusqu’au rapprochement. Le solde fournisseur affiché est le snapshot lu après la création de facture, et non un suivi continu des opérations effectuées ensuite hors du plugin.

Pour automatiser aussi la comptabilisation des espèces dans PC Voyages, une méthode fournisseur supplémentaire est nécessaire. En attendant, cette partie reste manuelle dans PC Voyages.

## Contrôles contre les doubles créations et les erreurs

- Confirmation agent unique par devis et dossier; aucun POST financier déclenché par le formulaire public.
- Verrou atomique par dossier, renouvellement des lectures après acquisition et tests avec caches préchargés dans huit processus indépendants.
- Journal de caisse append-only pour l’agent; correction séparée possible avant engagement fournisseur. L’agent ne peut pas supprimer le dossier et son historique.
- Sauvegarde des étapes avant les appels de création; un checkpoint non persistant empêche l’appel suivant.
- Aucune répétition automatique d’une création après réponse perdue ou interruption en cours d’écriture.
- Rattachement d’une réservation existante ou d’une facture existante, après vérification administrative et contrôles de cohérence.
- Nouvelle création après incident uniquement si un administrateur atteste avoir vérifié l’absence de résultat chez le fournisseur, avec motif historisé.
- Arrêt si prix, minimum, conditions, licence, devis ou autorisation changent.
- Indices voyageurs réellement lus, sans inventer les positions manquantes. Les indices ambigus arrêtent la transmission.
- Facture et réservation conservées en cas d’échec mail; renvoi de document sans nouvelle création fournisseur.

Il n’existe pas de garantie d’idempotence documentée côté fournisseur. Une attestation d’absence ne doit pas être donnée sur la seule base d’un timeout. La correspondance client/réservation d’une facture doit aussi être vérifiée dans PC Voyages : ses seuls montant et devise ne suffisent pas à prouver son appartenance.

## Confidentialité et exploitation

Les agents disposent d’un rôle opérationnel, sans accès aux secrets/réglages ni droit de suppression des dossiers. Les références utilisateur fournisseur sont explicites, par configuration ou dossier; aucun compte client n’est créé automatiquement.

Les jetons de réservation sont chiffrés en AES-256-GCM avec les clés WordPress et liés au dossier. Ils ne sont pas inclus dans l’export de données personnelles. Un PDF est téléchargé avec vérification TLS, sans redirection ni envoi d’authentification à un hôte arbitraire. Son fichier temporaire est privé et supprimé après la tentative d’envoi.

L’export WordPress inclut voyageurs, versements, corrections et références. Les demandes avec données financières sont exclues de la purge automatique; un administrateur peut toujours effectuer un effacement explicite. Cet effacement arrête les tâches locales, sans annuler ou effacer des données chez le fournisseur, dans les sauvegardes ou dans les courriels déjà envoyés.

L’exécution nécessite un Cron fiable. Sur un site peu fréquenté, prévoir un Cron système chaque minute avec `wp cron event run --due-now --quiet`. Le traitement comprend plusieurs événements successifs; la confirmation agent n’est pas une promesse d’exécution immédiate sans trafic/Cron. Le succès de `wp_mail` prouve l’acceptation de l’envoi, pas sa réception finale.

## Validation de la version livrée

| Suite | Réussis | Échecs |
|---|---:|---:|
| Catalogue, formulaires et confidentialité WordPress | 74 | 0 |
| Parcours acompte/réservation/facture | 61 | 0 |
| Navigateur : catalogue et demandes | 21 | 0 |
| Navigateur : véritable parcours Agent PCV | 13 | 0 |
| Encaissements concurrents, caches préchargés | 3 | 0 |
| Verrou : huit processus WordPress | 2 | 0 |
| WP-CLI catalogue | 5 | 0 |
| Conservation et suppression à la désinstallation | 4 | 0 |
| **Total** | **183** | **0** |

Aucun test ignoré dans ces suites. Syntaxe PHP/JavaScript et scripts Python vérifiés. Le ZIP est contrôlé pour son intégrité et sa correspondance avec les fichiers validés.

Environnement : WordPress 6.8.3, PHP 8.4.24, intégration SQLite officielle de WordPress, thème Twenty Twenty-Five et Chromium. Les requêtes vers WordPress, sessions et écritures en base sont réelles sur le site jetable. **Les réponses fournisseur, encaissements et courriels sont simulés/interceptés. Aucun dossier, paiement ou courriel client réel n’a été créé.**

Les scénarios couvrent notamment le minimum insuffisant, les versements fractionnés, les doubles clics et POST rejoués, les écritures échouées, les dépassements concurrents, les changements de prix/conditions, les réponses perdues après création, le rattachement de références, les reprises après désactivation et les échecs PDF/mail.

## À vérifier avec la licence réelle

- Licence, JWT et association au bon client/utilisateur fournisseur; aucune référence ne doit être inventée.
- Tarifs, chambres, catégories, options et champs voyageurs exigés sur les produits réellement vendus.
- Effet exact de la création sur les places, délai de maintien, expiration et annulation. L’OpenAPI décrit la création, mais pas ces garanties d’inventaire.
- Facture/PDF, identité du client, paiement désactivé et méthode officielle de report des espèces.
- SMTP, Cron, temps d’exécution PHP, thème et plugins de cache/sécurité du site cible.
- MySQL/MariaDB et autres versions de PHP : non inclus dans cette validation.

Le développement du parcours demandé est livré et ses tests simulés passent. L’activation en production dépend de ces vérifications fournisseur et hébergeur; elle n’a pas été effectuée ici.
