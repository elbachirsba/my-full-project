> **Archive historique : pilote 0.1.0.** Ce document est conservé comme source de l’analyse. Pour la version actuelle livrée, consulter `README.md`, `CHANGELOG.md` et `BILAN_AMELIORATIONS.md`. Les mentions « cette version » ci-dessous concernent exclusivement 0.1.0.

# Bilan technique détaillé — PCV TourOnline Connector

**Version :** 0.1.0 (pilote, non validé sur la plateforme TravelWorks)  
**Date :** 19 octobre 2026  
**Source principale :** export OpenAPI JSON fourni par l'utilisateur, titre `TourOnline_Gateway`, version `1.0`, OpenAPI `3.0.1`.  
**Sources annexes :** échanges de Karine Lavallée et Tony Gerace, document fournisseur « Sentinel.Net Xml Specs 2022 FR », documentation officielle WordPress (HTTP API / Plugin Handbook).

## 1. Synthèse sans ambiguïté

La plateforme **PCVWeb / PC Voyages classique** ne propose pas une API générale selon Tony. L'API **TourOnline** peut exposer les produits éligibles à TourOnline mais une licence adaptée doit être activée et reliée au bon catalogue. Le fichier Swagger prouve l'existence des **routes**, pas le fonctionnement des données pour votre licence.

La version livrée :

- Réalise des appels HTTP de **lecture** à l'API TourOnline (avec licence configurée).
- Importe les produits visibles par TourOnline en fiches WordPress ; conserve dates, prix, photos et groupes.
- Présente les offres sur des pages WordPress et collecte des **demandes locales** sans paiement.
- Ne crée **pas** de réservation TourOnline/PC Voyages et ne crée aucune facture : validation fournisseur indispensable avant d'activer des appels d'écriture.

**Aucun accès de test réel n'a encore été reçu : aucune réservation n'a été créée et aucune synchronisation réelle n'a été constatée.** La syntaxe PHP a été vérifiée mais l'installation sur un WordPress réel et les tests métier restent à faire.

## 2. Connexion API : base et en-têtes

Base HTTPS fixe : `https://api.touronline.shop`

L'en-tête fournisseur donné par Tony : `License: <CODE_LICENCE>`.

La spécification OpenAPI déclare aussi `Authorization: Bearer <JWT>` comme schéma de sécurité global. Ce jeton est pris en charge **uniquement** si la constante `PCVT_BEARER_TOKEN` est définie. Les opérations de `POST /Login/v1.0/signin` permettent de recevoir un token, mais le plugin n'automatise **pas** la gestion des comptes clients à ce stade.

Exemple de requête côté serveur (à remplacer par une valeur d'essai, ne jamais publier une clé) :

```http
GET /ProductGroup/v1.0 HTTP/1.1
Host: api.touronline.shop
Accept: application/json
License: CODE_LICENCE_DE_TEST
```

Exemple PHP WordPress équivalent :

```php
$response = wp_safe_remote_request('https://api.touronline.shop/ProductGroup/v1.0', [
    'method' => 'GET',
    'headers' => [
        'License' => PCVT_LICENSE,
        'Accept' => 'application/json',
    ],
    'timeout' => 20,
    'sslverify' => true,
    'redirection' => 0,
]);
if (is_wp_error($response)) { /* journaliser une erreur SANS secrets */ }
$data = json_decode(wp_remote_retrieve_body($response), true);
```

Cette requête est un **exemple documenté**, non une réponse réelle reçue de votre licence.

### Paramètres administratifs

| Paramètre | Emplacement | Sens |
|---|---|---|
| `License` | `PCVT_LICENSE` dans `wp-config.php` ou formulaire WordPress | Code de licence TourOnline |
| `Authorization` | `PCVT_BEARER_TOKEN` dans `wp-config.php` | JWT facultativement configuré, selon les besoins du fournisseur |
| Langue | administration WordPress : `fr`/`en` | Langue préférée pour les champs multilingues |
| Synchronisation | option `enabled_sync` | Désactivée par défaut, WP-Cron toutes les 15 minutes si activée |
| Courriel de notification | option `admin_email` | Destinataire de notification de demande locale |

La licence dans la base WordPress est conservée comme option serveur **non chiffrée**. Pour une exploitation professionnelle, préférer la constante dans `wp-config.php`, hors dépôt de code et hors webroot si possible.

## 3. Requêtes effectivement utilisées par le plugin

| Usage | Méthode | Chemin | Moment |
|---|---|---|---|
| Test de connexion | GET | `/Setting/v1.0/setting` | Bouton « Tester connexion API » |
| Catalogue / groupes | GET | `/ProductGroup/v1.0` | Synchronisation |
| Fiche produit | GET | `/Product/v1.0/{ProductCode}` | Chaque produit importé |
| Dates / disponibilité | GET | `/Product/v1.0/{ProductCode}/dates` | Chaque produit importé |
| Photos | GET | `/Product/v1.0/{ProductCode}/images` | Chaque produit importé |

Méthodes présentes dans le client PHP, **mais pas encore invoquées** dans le parcours WordPress :

- `GET /Product/v1.0/{ProductCode}/options` pour les options de réservation.
- `POST /Reservation/v1.0/preview` pour le devis ou la prévisualisation.

**Aucune requête POST de création de réservation/facture ni DELETE n'est émise** par la version 0.1.0. La seule écriture est interne à la base WordPress (demande de réservation).

## 4. Mapping des données de produits

| Champ API | Usage dans WordPress | Statut |
|---|---|---|
| `ProductGroup` : `code`, `name`, `listProduct[]` | Identification des groupes et liste de produits | Implémenté |
| `listProduct[].code` | `_pcvt_code`, identifiant stable de l'offre | Implémenté |
| `ProductDetail.name.french` / `.english` | `post_title` | Implémenté |
| `ProductDetail.description` | `post_content` | Implémenté |
| `ProductDetail.listSection[]` | Sections dans le contenu WordPress | Implémenté |
| `ProductDetail.listClass[]` | `_pcvt_classes` (pour futur formulaire complet) | Stocké, non utilisé |
| `ProductDetail.listBusPickup[]` | `_pcvt_pickups` | Stocké, non utilisé |
| `ProductListProduct.pricing.total` | `_pcvt_price` (prix d'appel) | Implémenté |
| `ProductListProduct.pricing.currency` | `_pcvt_currency` | Implémenté |
| `ProductDate.productPriceDateCode` | Choix du départ dans le formulaire | Implémenté |
| `ProductDate.dateDepart`, `dateReturn` | Métadonnées du départ | Date de départ affichée |
| `ProductDate.isAvailable` | Inclusion dans la liste des dates sélectionnables | Implémenté sur snapshot |
| `ProductDate.pricing.total` / `currency` | Prix de la date sélectionnée | Affiché |
| `ProductImage.pathImage` | Image principale de la fiche | Seulement URL HTTPS absolue |
| `ProductDetail.listImage[]` | Repli si `/images` renvoie liste vide | Partiellement |

**Limites :** l'API peut renvoyer des chemins d'image relatifs ; leur URL finale doit être déterminée avec le fournisseur. L'inventaire en temps réel ne doit pas être annoncé si le contenu WordPress provient d'une synchronisation espacée. Le plugin ne supprime pas automatiquement les offres retirées du catalogue source.

## 5. Workflow WordPress actuel (pilote)

1. Un administrateur renseigne la licence.
2. Il lance le test `GET /Setting/v1.0/setting`.
3. Il lance manuellement la synchronisation (ou active le Cron ultérieurement).
4. Le plugin reçoit `listProduct[]`, puis demande détails, dates, images, et écrit/actualise des `pcvt_offer`.
5. Une page avec `[pcvt_offres]` affiche le catalogue.
6. Le visiteur ouvre une offre, choisit une date et fournit prénom, nom, courriel, téléphone, adultes, enfants, note et consentement.
7. Le plugin valide et crée un `pcvt_request` **privé** dans la base WordPress, puis envoie un bref avis à l'admin.
8. Aucun paiement ; aucune place n'est bloquée ; aucun dossier n'est créé dans PCVWeb. Les agents doivent traiter manuellement.

**Ne pas confondre « demande reçue » et « réservation confirmée ».** Le libellé côté client le rappelle explicitement.

## 6. Flux futur nécessaire pour une réservation réelle — NON ACTIVÉ

### POST `/Reservation/v1.0/preview`

Schéma `TourOnlineAPIReservPreviewBody` : `agent`, `busPickup`, `corporateAccount`, `dateDepart`, `dateReturn`, `listOption[{code,quantity}]`, `nbAdult`, `nbChild`, `nbRoom`, `product`, `pricingCategoryCode`, `pricingClassCode`, `productPriceCategoryCode`, `productPriceClassCode`, `productPriceDateCode`, `project`.

### POST `/Reservation/v1.0`

Schéma `TourOnlineAPIReservCreateBody` : les champs précédents plus `user`. Réponse `GatewayReservationCreateModel_V1_0` avec `reservationCode`, `token`.

**Attention** : l'objet de création de réservation ne comporte **pas** de champs `firstName`, `lastName`, `email` ou `telephone` ! Le compte / voyageur / rooming doit être associé autrement. Il est dangereux de transmettre une réservation vide ou sous un mauvais voyageur. Le flux exact doit être expliqué par Tony.

### POST `/Invoice/v1.0`

Schéma `GatewayInvoiceCreateBody_V1_0` : `{ "isPaymentDisabled": true, "lang": "fr", "reservation": "CODE", "token": "TOKEN" }`.

Cette propriété **suggère** une facturation sans initiation de paiement, mais ne confirme ni la réussite métier, ni l'absence d'encaissement lors d'autres opérations, ni la création du bon dossier PCVWeb. Réponse prévue : `{ "file": "...", "invoice": "..." }` via `ReservTransfertResultModel`.

### Connexion / inscription

- `POST /Login/v1.0/signin` prend `login`, `password`; réponse `TokenModel.token`.
- `POST /Login/v1.0/pax` prend `firstName`, `lastName`, `email`, `telephone`, `lang`, `password`.
- `POST /Login/v1.0/customer` prend `email`, `password`, `token`.
- `POST /Login/v1.0/autologin` prend `token`.

Une inscription automatique ne doit **pas** être implémentée sans connaître les règles de consentement, d'authentification, d'unicité des comptes et d'envoi d'emails du fournisseur. Cela réclame une validation de Tony.

## 7. Sécurité, erreurs et protections

- Clé licence jamais injectée dans le navigateur ; appels API **serveur → fournisseur** uniquement.
- Origine HTTPS `api.touronline.shop` codée en dur, chemins filtrés ; pas de base URL arbitraire (protection SSRF).
- `wp_safe_remote_request`, `sslverify=true`, `redirection=0`, timeout 20 s.
- Rejets sur HTTP non-2xx, erreur WordPress, JSON invalide ; messages d'erreur évitant les tokens.
- Boutons d'administration réservés aux utilisateurs `manage_options`, nonces WordPress.
- Formulaire public avec validation serveur, nonce, champ invisible anti-bot, délai minimal 2 secondes et quota anti-spam transitoire.
- Enregistrement des demandes en type privé `pcvt_request`, non exposé dans REST ; données personnelles non incluses dans les emails de notification.
- Limite prudente : 50 produits maximum par synchronisation ; import seulement si détail, dates et images renvoient une réponse JSON valide ; ancienne fiche conservée en cas d'erreur.
- **À faire avant production :** tests sur WordPress réel, mesures anti-spam avancées, politique de conservation des données (Loi 25), mécanisme d'effacement, tests de charge, politique de dépublication et validation des images de TravelWorks.

## 8. Questions indispensables pour Tony

1. TourOnline peut-il lire **toutes** les offres du module Tour Premium utilisées dans notre licence PCVWeb (ou seulement celles publiées/paramétrées dans TourOnline) ?
2. TourOnline (et son API) dispose-t-il d'une licence d'essai connectée à un jeu de données fictives / préproduction ?
3. Faut-il un **JWT Bearer** en plus de l'en-tête `License` pour chaque route ? Quelle durée de validité et quel renouvellement ?
4. Comment un **visiteur invité** transmet-il prénom, nom, courriel, téléphone et voyageurs à `POST /Reservation` quand ces propriétés ne figurent pas dans le schéma du corps ?
5. Quelle séquence exacte rend un dossier visible dans PCVWeb : réservation seule, ajout de voyageurs, puis facture ?
6. `POST /Invoice` avec `isPaymentDisabled=true` garantit-il **zéro paiement en ligne** ? Quel statut est attribué au dossier ?
7. Comment prévenir doublons et courses concurrentes (idempotency key) ? Comment retrouver une réservation après timeout ?
8. Limites d'appel, URL de test indépendante, mécanismes de dépublication et formats URL d'images ?

## 9. Fichiers inclus

- `pcv-touronline-connector.php` — amorçage, types de publications, Cron, notice de confidentialité.
- `includes/class-pcvt-api.php` — transport JSON et accès aux routes de lecture.
- `includes/class-pcvt-sync.php` — découverte, import des fiches, métadonnées et photos.
- `includes/class-pcvt-admin.php` — interface de configuration, boutons de test/sync, consultation de demandes.
- `includes/class-pcvt-frontend.php` — shortcodes, fiches produit, formulaire sans paiement.
- `assets/pcvt.css` — grille responsive et style du formulaire.
- `README.md` — procédure d'installation.
- `BILAN_TECHNIQUE.md` — cette documentation.

## 10. Liens sources

- Swagger UI du fournisseur : https://api.touronline.shop/swagger/ui/index.html
- OpenAPI JSON : https://api.touronline.shop/swagger/v1.0/swagger.json (fourni dans la conversation ; l'URL distante peut être inaccessible sans navigateur)
- Tour Premium : https://www.travelworkssolution.com/fr/logiciel-agence-voyage/gestion-des-tours
- WordPress HTTP API : https://developer.wordpress.org/plugins/http-api/
- WordPress plugins : https://developer.wordpress.org/plugins/
- WordPress sécurité / nonces : https://developer.wordpress.org/apis/security/nonces/

## 11. Inventaire exhaustif des opérations OpenAPI v1.0

La liste ci-dessous est extraite automatiquement du document OpenAPI fourni ; les colonnes « Statut » décrivent **ce plugin 0.1.0**, pas la disponibilité contractuelle de chaque endpoint sur une licence donnée.

| Méthode | Route | Fonction déclarée | Statut dans le plugin |
|---|---|---|---|
| `GET` | `/Invoice/v1.0/byfile` | Invoice detail information | Non intégré |
| `GET` | `/Invoice/v1.0` | List of pending invoices | Non intégré |
| `POST` | `/Invoice/v1.0` | Create invoice | Non intégré |
| `GET` | `/Invoice/v1.0/{Invoice}/printurl` | URL Invoice document | Non intégré |
| `GET` | `/Invoice/v1.0/print` | Invoice document | Non intégré |
| `POST` | `/Login/v1.0/autologin` | sans résumé | Non intégré |
| `POST` | `/Login/v1.0/signin` | sans résumé | Non intégré |
| `POST` | `/Login/v1.0/pax` | sans résumé | Non intégré |
| `POST` | `/Login/v1.0/customer` | sans résumé | Non intégré |
| `POST` | `/Login/v1.0/reset-password` | sans résumé | Non intégré |
| `POST` | `/Login/v1.0/send-reset-password` | sans résumé | Non intégré |
| `POST` | `/Login/v1.0/set-reset-password` | sans résumé | Non intégré |
| `GET` | `/Pax/v1.0/byCAAMember` | Find passenger by CAA Member | Non intégré |
| `PUT` | `/Pax/v1.0` | Update passenger | Non intégré |
| `GET` | `/Payment/v1.0/url/reservation/{Reservation}` | Get URL to payment request | Non intégré |
| `GET` | `/Payment/v1.0/url/invoice/{Invoice}` | Get URL to payment request | Non intégré |
| `POST` | `/Payment/v1.0/cancel` | Cancel payment | Non intégré |
| `GET` | `/Product/v1.0/{ProductCode}` | Product detail information | Actif : sync |
| `GET` | `/Product/v1.0/{ProductCode}/flyer` | Product flyer file | Non intégré |
| `GET` | `/Product/v1.0/{ProductCode}/dates` | Date information | Actif : sync |
| `GET` | `/Product/v1.0/{ProductCode}/images` | Product images | Actif : sync |
| `GET` | `/Product/v1.0/{ProductCode}/options` | Product Options information | Client disponible, non appelé |
| `GET` | `/ProductGroup/v1.0` | List available product groups | Actif : sync |
| `GET` | `/Reservation/v1.0/{ReservationCode}` | Reservation information | Non intégré |
| `DELETE` | `/Reservation/v1.0/{ReservationCode}` | Delete reservation | Non intégré |
| `POST` | `/Reservation/v1.0/preview` | Preview reservation information | Client disponible, non appelé |
| `POST` | `/Reservation/v1.0` | Create booking reservation | Non intégré |
| `GET` | `/Setting/v1.0/setting` | Settings information | Actif : diagnostic |
| `GET` | `/Setting/v1.0/terms` | Get Terms & Conditions | Non intégré |
| `GET` | `/User/v1.0/pax` | sans résumé | Non intégré |
| `PUT` | `/User/v1.0/pax` | sans résumé | Non intégré |
| `GET` | `/User/v1.0/customer` | sans résumé | Non intégré |
| `PUT` | `/User/v1.0/customer` | sans résumé | Non intégré |
| `GET` | `/User/v1.0/projects` | sans résumé | Non intégré |
| `PUT` | `/User/v1.0/password` | sans résumé | Non intégré |
| `PUT` | `/User/v1.0/email` | sans résumé | Non intégré |
