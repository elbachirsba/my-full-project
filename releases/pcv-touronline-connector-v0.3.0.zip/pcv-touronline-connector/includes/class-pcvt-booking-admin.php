<?php
if (!defined('ABSPATH')) { exit; }
final class PCVT_Booking_Admin {
    public static function boot() {
        add_action('add_meta_boxes_pcvt_request',function() { add_meta_box('pcvt_booking','Encaissement, acompte et dossier PC Voyages',array(__CLASS__,'box'),'pcvt_request','normal','high'); });
        foreach (array('quote','cash','pax','confirm','retry','resend','attach','void') as $action) {
            add_action('admin_post_pcvt_booking_'.$action,function() use ($action) { self::handle($action); });
        }
        add_action('admin_notices',function() {
            $key='pcvt_booking_notice_'.get_current_user_id(); $notice=get_transient($key);
            if ($notice) { delete_transient($key); echo '<div class="notice notice-info"><p>'.esc_html($notice).'</p></div>'; }
        });
        add_filter('manage_pcvt_request_posts_columns',function($columns) { $columns['pcvt_booking']='Dossier / règlement'; return $columns; });
        add_action('manage_pcvt_request_posts_custom_column',function($name,$id) {
            if ($name!=='pcvt_booking' || !current_user_can('manage_pcvt_bookings')) { return; }
            $s=PCVT_Booking::state($id); echo esc_html(PCVT_Booking::phases()[$s['phase']]??$s['phase']);
            $q=PCVT_Booking::quote_data($id);
            if ($q) { echo '<br>'.esc_html('Reçu : '.PCVT_Money::display(PCVT_Booking::paid($id,$q['currency']),$q['currency'])); }
        },10,2);
    }
    private static function input($key,$max=300) { return isset($_POST[$key]) && is_scalar($_POST[$key]) ? substr(sanitize_text_field(wp_unslash((string)$_POST[$key])),0,$max) : ''; }
    private static function button($action,$label,$primary=false) {
        echo '<button type="submit" formnovalidate class="button '.($primary ? 'button-primary' : '').'" formaction="'.esc_url(admin_url('admin-post.php')).'" name="action" value="pcvt_booking_'.esc_attr($action).'">'.esc_html($label).'</button> ';
    }
    public static function handle($action) {
        if (strtoupper($_SERVER['REQUEST_METHOD']??'')!=='POST') { wp_die('Méthode invalide.','',array('response'=>405)); }
        $raw=self::input('request_id',10); $id=ctype_digit($raw) ? (int)$raw : 0;
        $guard=PCVT_Booking::guard($id); if (is_wp_error($guard)) { wp_die(esc_html($guard->get_error_message()),'',array('response'=>403)); }
        check_admin_referer('pcvt_booking_'.$id,'pcvt_booking_nonce');
        try {
        if ($action==='quote') {
            $options=isset($_POST['booking_options']) && is_array($_POST['booking_options']) ? wp_unslash($_POST['booking_options']) : array();
            $r=PCVT_Booking::quote($id,array('nb_room'=>self::input('booking_rooms',2),'class_code'=>self::input('booking_class',20),'category_code'=>self::input('booking_category',20),'bus_pickup'=>self::input('booking_pickup',20),
                'options'=>$options,'options_reviewed'=>self::input('booking_options_reviewed',1)==='1','options_context'=>self::input('booking_options_context',64),'supplier_user'=>self::input('booking_supplier_user',180)));
            $success='Prix et acompte minimum vérifiés. Aucun encaissement ou blocage de place n’a encore été demandé.';
        } elseif ($action==='pax') {
            $p=isset($_POST['booking_travelers']) && is_array($_POST['booking_travelers']) ? wp_unslash($_POST['booking_travelers']) : array();
            $r=PCVT_Booking::save_travelers($id,$p); $success='Voyageurs enregistrés dans WordPress.';
        } elseif ($action==='cash') {
            if (self::input('booking_cash_received',1)!=='1') { $r=new WP_Error('pcvt_cash_attestation','Confirmer que les espèces ont réellement été reçues.'); }
            else { $r=PCVT_Booking::cash($id,self::input('booking_amount',20),self::input('booking_currency',3),self::input('booking_operation',36),self::input('booking_receipt',120)); }
            $success='Encaissement enregistré dans WordPress. Le solde fournisseur n’a pas été modifié par cette écriture.';
        } elseif ($action==='void') {
            $r=PCVT_Booking::void_cash($id,self::input('booking_void_id',36),self::input('booking_reason')); $success='Écriture corrigée par une contre-écriture conservée dans l’historique.';
        } elseif ($action==='confirm') {
            if (self::input('booking_agent_confirm',1)!=='1') { $r=new WP_Error('pcvt_agent_attestation','Confirmer la vérification du dossier et du règlement.'); }
            else { $r=PCVT_Booking::confirm($id,self::input('booking_revision',36),self::input('booking_supplier_consent',1)==='1',self::input('booking_terms_consent',1)==='1'); }
            $success='Validation agent reçue. La réservation, les voyageurs, la facture et son envoi seront traités par étapes. Actualiser le dossier pour suivre le résultat.';
        } elseif ($action==='attach') {
            $kind=self::input('booking_attach_kind',20);
            if (self::input('booking_attach_verified',1)!=='1') { $r=new WP_Error('pcvt_reconciliation','Attester la vérification du dossier dans PC Voyages.'); }
            else { $r=PCVT_Booking::attach($id,$kind,self::input('booking_attach_code',180),self::input('booking_attach_secret',8192),self::input('booking_reason')); }
            $success='Référence fournisseur vérifiée et rattachée. La suite reprend sans recréer cette référence.';
        } else {
            $r=PCVT_Booking::retry($id,self::input('booking_reason'),self::input('booking_verified_absent',1)==='1',$action==='resend');
            $success=$action==='resend' ? 'Renvoi de la facture planifié, sans nouvelle réservation ni facture.' : 'Reprise autorisée et historisée.';
        }
        } catch (Throwable $e) { $r=new WP_Error('pcvt_storage','L’étape n’a pas pu être enregistrée. Vérifier le dossier et les références fournisseur avant de recommencer.'); $success=''; }
        set_transient('pcvt_booking_notice_'.get_current_user_id(),is_wp_error($r) ? $r->get_error_message() : $success,MINUTE_IN_SECONDS);
        wp_safe_redirect(admin_url('post.php?post='.$id.'&action=edit'),303); exit;
    }
    public static function box($post) {
        if (!current_user_can('manage_pcvt_bookings')) { return; }
        $id=$post->ID; $state=PCVT_Booking::state($id); $q=PCVT_Booking::quote_data($id); $s=pcvt_settings();
        $phase=$state['phase']; $editable=in_array($phase,array('draft','quote_ready','quote_changed'),true);
        wp_nonce_field('pcvt_booking_'.$id,'pcvt_booking_nonce');
        echo '<input type="hidden" name="request_id" value="'.(int)$id.'">';
        echo '<p><strong>État :</strong> '.esc_html(PCVT_Booking::phases()[$phase]??$phase).'</p>';
        if (!empty($state['error'])) { echo '<div class="notice notice-warning inline"><p>'.esc_html($state['error']).'</p></div>'; }
        if (empty($s['enabled_booking'])) { echo '<p>Parcours fournisseur désactivé. Un administrateur doit configurer la licence et activer le parcours agent dans PCV TourOnline.</p>'; }
        foreach (array('reservation_code'=>'Réservation fournisseur','file'=>'Dossier PCV','invoice'=>'Facture fournisseur') as $key=>$label) {
            if (!empty($state[$key])) { echo '<p><strong>'.esc_html($label).' :</strong> '.esc_html($state[$key]).'</p>'; }
        }
        if (!$editable) {
            echo '<h3>Voyageurs du dossier</h3><ol>';
            foreach ((array)get_post_meta($id,'_pcvt_travelers',true) as $p) {
                if (is_array($p)) { echo '<li>'.esc_html(($p['firstName']??'').' '.($p['lastName']??'').(!empty($p['birthDate']) ? ' — '.substr($p['birthDate'],0,10) : '')).'</li>'; }
            }
            echo '</ol>';
        }
        if ($q) {
            $paid=PCVT_Booking::paid($id,$q['currency']);
            echo '<p><strong>Total vérifié :</strong> '.esc_html(PCVT_Money::display($q['total_minor'],$q['currency'])).' · <strong>Acompte minimum :</strong> '.esc_html(PCVT_Money::display($q['minimum_minor'],$q['currency'])).'</p>';
            echo '<p><strong>Reçu en agence :</strong> '.esc_html(PCVT_Money::display($paid,$q['currency'])).' · <strong>Solde agence :</strong> '.esc_html(PCVT_Money::display(max(0,$q['total_minor']-$paid),$q['currency'])).'</p>';
            if (isset($state['supplier_balance_minor'])) { echo '<p><strong>Solde retourné par PC Voyages :</strong> '.esc_html(PCVT_Money::display($state['supplier_balance_minor'],$q['currency'])).' (peut différer tant que les espèces n’y sont pas reportées).</p>'; }
            echo '<input type="hidden" name="booking_currency" value="'.esc_attr($q['currency']).'"><input type="hidden" name="booking_revision" value="'.esc_attr($q['revision']).'">';
        }
        echo '<p>Les prix et places sont revérifiés avant la création. Un paiement local ne prouve pas une place bloquée. Les références fournisseur et les erreurs restent visibles ici.</p>';
        if ($editable) {
            echo '<hr><h3>1. Vérifier le tarif</h3>';
            $choices=get_post_meta($id,'_pcvt_booking_choices',true);
            if (!is_array($choices)) { $offer=PCVT_Booking::offer_id($id); $choices=array('classes'=>get_post_meta($offer,'_pcvt_classes',true),'pickups'=>get_post_meta($offer,'_pcvt_pickups',true)); }
            $body=$q['body']??array();
            echo '<p><label>Référence utilisateur client TourOnline, si requise <input name="booking_supplier_user" maxlength="180" value="'.esc_attr($q['supplier_user']??$s['supplier_user']).'"></label></p><p class="description">Utiliser uniquement une référence client fournisseur vérifiée. Ce champ n’est pas un identifiant WordPress; aucun compte client n’est créé automatiquement.</p>';
            echo '<p><label>Chambres / unités <input name="booking_rooms" type="number" min="1" max="20" value="'.(int)($body['nbRoom']??1).'"></label></p>';
            echo '<p><label>Classe <select name="booking_class"><option value="">Choisir si proposé</option>';
            foreach (is_array($choices['classes']??null) ? $choices['classes'] : array() as $c) {
                if (!is_array($c) || !isset($c['code'])) { continue; }
                $name=PCVT_Sync::localized($c['pricingClass']['name']??'',pcvt_settings()['lang']);
                echo '<option value="'.esc_attr($c['code']).'" '.selected((string)($body['productPriceClassCode']??''),(string)$c['code'],false).'>'.esc_html($name ?: (string)$c['code']).'</option>';
            }
            echo '</select></label> <label>Catégorie <select name="booking_category"><option value="">Choisir si proposé</option>';
            $seen=array();
            foreach (is_array($choices['classes']??null) ? $choices['classes'] : array() as $c) {
                foreach (is_array($c['listCategory']??null) ? $c['listCategory'] : array() as $category) {
                    if (!is_array($category) || !isset($category['code']) || isset($seen[$category['code']])) { continue; }
                    $seen[$category['code']]=true;
                    $name=PCVT_Sync::localized($category['pricingCategory']['name']??'',pcvt_settings()['lang']);
                    echo '<option value="'.esc_attr($category['code']).'" '.selected((string)($body['productPriceCategoryCode']??''),(string)$category['code'],false).'>'.esc_html(($name ?: (string)$category['code']).' — classe '.($c['code']??'')).'</option>';
                }
            }
            echo '</select></label></p><p><label>Arrêt <select name="booking_pickup"><option value="">Non précisé</option>';
            foreach (is_array($choices['pickups']??null) ? $choices['pickups'] : array() as $pickup) {
                if (!is_array($pickup) || !isset($pickup['code'])) { continue; }
                echo '<option value="'.esc_attr($pickup['code']).'" '.selected((string)($body['busPickup']??''),(string)$pickup['code'],false).'>'.esc_html($pickup['name']??(string)$pickup['code']).'</option>';
            }
            echo '</select></label></p>';
            $options=get_post_meta($id,'_pcvt_booking_options',true); $chosen=array(); foreach ($body['listOption']??array() as $opt) { $chosen[$opt['code']]=$opt['quantity']; }
            if (is_array($options)) {
                echo '<fieldset><legend>Options fournisseur à vérifier</legend>';
                foreach ($options as $option) {
                    if (!is_array($option) || !isset($option['code'])) { continue; }
                    $label=PCVT_Sync::localized($option['name']??'',pcvt_settings()['lang']) ?: (string)$option['code'];
                    echo '<p><label>'.esc_html($label).' <input type="number" min="0" max="100" name="booking_options['.esc_attr($option['code']).']" value="'.(int)($chosen[$option['code']]??0).'"></label></p>';
                }
                echo '<input type="hidden" name="booking_options_context" value="'.esc_attr(get_post_meta($id,'_pcvt_booking_options_context',true)).'"><p><label><input type="checkbox" name="booking_options_reviewed" value="1"> J’ai vérifié les options et leurs quantités avec le client.</label></p></fieldset>';
            }
            self::button('quote','Vérifier le prix et l’acompte');
            echo '<p class="description">Un premier clic peut charger des tarifs et options actualisés à choisir. Le prix total provient de la prévisualisation fournisseur, options sélectionnées comprises. Le devis est valable 15 minutes pour la confirmation agent.</p>';
            echo '<hr><h3>2. Compléter les voyageurs</h3>';
            $travelers=get_post_meta($id,'_pcvt_travelers',true); $count=min(20,(int)get_post_meta($id,'_pcvt_adults',true)+(int)get_post_meta($id,'_pcvt_children',true));
            for ($i=0;$i<$count;$i++) {
                $p=is_array($travelers) ? ($travelers[$i]??array()) : array();
                if (!$p && $i===0) { $p=array('firstName'=>get_post_meta($id,'_pcvt_first',true),'lastName'=>get_post_meta($id,'_pcvt_last',true)); }
                echo '<fieldset style="margin:12px 0"><legend>Voyageur '.($i+1).'</legend>';
                foreach (array('firstName'=>'Prénom','lastName'=>'Nom') as $key=>$label) { echo '<label>'.esc_html($label).' <input maxlength="100" name="booking_travelers['.$i.']['.esc_attr($key).']" value="'.esc_attr($p[$key]??'').'"></label> '; }
                echo '<label>Date de naissance, si nécessaire <input type="date" name="booking_travelers['.$i.'][birthDate]" value="'.esc_attr(substr($p['birthDate']??'',0,10)).'"></label></fieldset>';
            }
            self::button('pax','Enregistrer les voyageurs');
        }
        if ($q) {
            echo '<hr><h3>3. Encaissements en espèces</h3><p><label>Montant reçu <input name="booking_amount" type="text" inputmode="decimal" placeholder="100,00"></label> <label>Référence du reçu <input name="booking_receipt" maxlength="120"></label></p>';
            echo '<input type="hidden" name="booking_operation" value="'.esc_attr(wp_generate_uuid4()).'">';
            echo '<p><label><input type="checkbox" name="booking_cash_received" value="1"> J’atteste avoir réellement reçu ce montant en espèces.</label></p>';
            self::button('cash','Enregistrer les espèces reçues');
            echo '<p class="description">Cette écriture n’effectue ni débit bancaire ni enregistrement de reçu dans PC Voyages.</p>';
            $voids=array(); foreach (get_post_meta($id,'_pcvt_cash_void',false) as $v) { $voids[$v['entry_id']??'']=true; }
            echo '<ul>';
            foreach (PCVT_Booking::ledger($id) as $e) {
                echo '<li>'.esc_html(($e['at']??'').' — '.PCVT_Money::display((int)($e['amount_minor']??0),$e['currency']??'CAD').' — reçu '.($e['reference']??'').' — agent #'.($e['agent']??0).(isset($voids[$e['id']??'']) ? ' — CORRIGÉE' : '')).' <code>'.esc_html($e['id']??'').'</code></li>';
            }
            echo '</ul>';
            if ($editable) {
                echo '<p><label>Écriture à corriger <input name="booking_void_id" maxlength="36" placeholder="Identifiant de l’écriture"></label></p>';
                self::button('void','Corriger cette écriture (motif requis)');
                echo '<hr><h3>4. Confirmer et transmettre</h3>';
                if ($q['terms']!=='') { echo '<details><summary>Conditions fournisseur à faire accepter</summary>'.wp_kses_post($q['terms']).'</details><p><label><input type="checkbox" name="booking_terms_consent" value="1"> Le client a accepté ces conditions fournisseur.</label></p>'; }
                echo '<p><label><input type="checkbox" name="booking_supplier_consent" value="1"> Le client autorise la transmission de ses renseignements et de ceux des voyageurs à PC Voyages/TourOnline.</label></p>';
                echo '<p><label><input type="checkbox" name="booking_agent_confirm" value="1"> J’ai vérifié le dossier, le montant réellement encaissé, le prix accepté par le client et les voyageurs. Je demande la création fournisseur.</label></p>';
                self::button('confirm','Valider le règlement et créer le dossier fournisseur',true);
                echo '<p>Le minimum affiché doit être encaissé. La réservation, les voyageurs, la facture sans paiement en ligne puis son envoi PDF seront traités automatiquement par étapes.</p>';
            }
        }
        if (in_array($phase,array('manual_review','email_failed','completed'),true)) {
            echo '<hr><h3>Vérification / reprise</h3><p><label>Motif et vérification effectuée <input class="large-text" name="booking_reason" maxlength="300"></label></p>';
            if (in_array($phase,array('completed','email_failed'),true)) { self::button('resend','Renvoyer uniquement la facture'); }
            if ($phase==='manual_review') {
                echo '<p>Une création interrompue a pu réussir. Vérifier les références dans PC Voyages avant toute nouvelle tentative.</p>';
                if (current_user_can('manage_options')) {
                    echo '<p><label><input type="checkbox" name="booking_verified_absent" value="1"> J’ai vérifié chez le fournisseur que la réservation/facture de l’étape interrompue n’a PAS été créée.</label></p>';
                }
                self::button('retry','Autoriser la reprise après vérification');
                if (current_user_can('manage_options')) {
                    echo '<h4>Rattacher une création qui a réussi chez le fournisseur</h4><p><select name="booking_attach_kind"><option value="reservation">Réservation</option><option value="invoice">Facture</option></select> <label>Code <input name="booking_attach_code" maxlength="180"></label></p>';
                    echo '<p><label>Jeton de réservation ou code dossier de la facture <input type="password" name="booking_attach_secret" autocomplete="new-password" maxlength="8192"></label></p>';
                    echo '<p><label><input type="checkbox" name="booking_attach_verified" value="1"> J’ai vérifié dans PC Voyages que cette référence appartient bien à ce client, ce départ et cette réservation.</label></p>';
                    self::button('attach','Vérifier et rattacher la référence existante');
                }
            }
        } elseif (!$editable) { echo '<p><a class="button" href="'.esc_url(admin_url('post.php?post='.$id.'&action=edit')).'">Actualiser le suivi</a> — exécution par WP-Cron.</p>'; }
        echo '<hr><h3>Historique des actions</h3><ul>';
        $events=array('quote_verified'=>'Tarif et acompte vérifiés','cash_recorded'=>'Encaissement enregistré','cash_voided'=>'Écriture de caisse corrigée','travelers_saved'=>'Voyageurs enregistrés',
            'agent_approved'=>'Dossier validé par l’agent','workflow_stopped'=>'Traitement arrêté pour vérification','reservation_created'=>'Réservation fournisseur créée',
            'travelers_transmitted'=>'Voyageurs transmis au fournisseur','invoice_created'=>'Facture fournisseur créée','invoice_mail_accepted'=>'Facture acceptée par la messagerie',
            'invoice_resend_requested'=>'Nouvelle copie de facture demandée','retry_authorized'=>'Reprise autorisée après vérification',
            'existing_reservation_attached'=>'Réservation existante vérifiée et rattachée','existing_invoice_attached'=>'Facture existante vérifiée et rattachée');
        foreach (array_slice(get_post_meta($id,'_pcvt_audit',false),-20) as $event) {
            $user=get_userdata((int)($event['actor']??0)); $name=$user ? $user->display_name : 'Compte #'.(int)($event['actor']??0);
            $date=!empty($event['at']) ? wp_date('d/m/Y H:i',strtotime($event['at'])) : '';
            echo '<li>'.esc_html($date.' — '.$name.' — '.($events[$event['event']??'']??'Action enregistrée').(!empty($event['data']['reason']) ? ' : '.$event['data']['reason'] : '')).'</li>';
        }
        echo '</ul>';
    }
}
PCVT_Booking_Admin::boot();
