<?php
if (!defined('ABSPATH')) { exit; }
final class PCVT_API {
    const ORIGIN = 'https://api.touronline.shop';
    public static function request($method,$path,$query=array(),$json=null,$format='json') {
        $read='#^/(?:Setting/v1\.0/(?:setting|terms)|ProductGroup/v1\.0|Product/v1\.0/[A-Za-z0-9_%~.\-]+(?:/(?:dates|images|options))?|Reservation/v1\.0/[A-Za-z0-9_%~.\-]+|Invoice/v1\.0/(?:byfile|print|[A-Za-z0-9_%~.\-]+/printurl))$#D';
        $write=array('POST'=>array('/Reservation/v1.0/preview','/Reservation/v1.0','/Invoice/v1.0'),'PUT'=>array('/Pax/v1.0'));
        if ($method!=='GET' && (!isset($write[$method]) || !in_array($path,$write[$method],true))) { return new WP_Error('pcvt_method','Opération fournisseur non autorisée.'); }
        if ($method!=='GET' && empty(pcvt_settings()['enabled_booking'])) { return new WP_Error('pcvt_disabled','Activer le parcours agent dans les réglages avant tout appel de réservation.'); }
        if (!is_string($path) || ($method==='GET' && !preg_match($read,$path))) { return new WP_Error('pcvt_path','Chemin API invalide.'); }
        foreach (explode('/',trim($path,'/')) as $segment) {
            $part=rawurldecode($segment);
            if ($part==='.' || $part==='..' || preg_match('~[\x00-\x20/\\\\?#%]~',$part)) { return new WP_Error('pcvt_path','Identifiant API invalide.'); }
        }
        $license=pcvt_license();
        if (!$license || preg_match('/[\r\n]/',$license)) { return new WP_Error('pcvt_no_license','Licence TourOnline absente ou invalide.'); }
        $headers=array('License'=>$license,'Accept'=>$format==='pdf' ? 'application/pdf' : 'application/json');
        if (defined('PCVT_BEARER_TOKEN') && is_string(PCVT_BEARER_TOKEN) && PCVT_BEARER_TOKEN!=='') {
            if (preg_match('/[\r\n]/',PCVT_BEARER_TOKEN)) { return new WP_Error('pcvt_token','Jeton Bearer invalide.'); }
            $headers['Authorization']='Bearer '.PCVT_BEARER_TOKEN;
        }
        $url=self::ORIGIN.$path;
        if ($query) { $url=add_query_arg($query,$url); }
        $max=($format==='pdf' ? 10 : 4)*MB_IN_BYTES;
        $args=array('method'=>$method,'headers'=>$headers,'timeout'=>$method==='GET' ? 10 : 20,
            'redirection'=>0,'sslverify'=>true,'reject_unsafe_urls'=>true,'limit_response_size'=>$max+1);
        if ($method!=='GET') {
            $args['headers']['Content-Type']='application/json; charset=utf-8';
            $args['body']=wp_json_encode($json);
            if ($args['body']===false) { return new WP_Error('pcvt_json','Corps de requête invalide.'); }
        }
        $response=wp_safe_remote_request($url,$args);
        if (is_wp_error($response)) { return new WP_Error('pcvt_transport','Connexion réseau/TLS au fournisseur impossible.',array('retryable'=>true)); }
        $status=(int)wp_remote_retrieve_response_code($response);
        if ($status<200 || $status>=300) {
            $retry=wp_remote_retrieve_header($response,'retry-after'); $retry=is_scalar($retry) ? (string)$retry : '';
            $delay=is_numeric($retry) ? (int)$retry : max(0,(int)strtotime($retry)-time());
            return new WP_Error('pcvt_http','Réponse fournisseur HTTP '.$status.'.',array('status'=>$status,
                'retryable'=>$status===429 || $status>=500,'retry_after'=>min(HOUR_IN_SECONDS,max(30,$delay))));
        }
        $body=wp_remote_retrieve_body($response);
        if (strlen($body)>$max) { return new WP_Error('pcvt_size','Réponse fournisseur trop volumineuse.'); }
        if ($format==='pdf') {
            $type=wp_remote_retrieve_header($response,'content-type');
            if (!is_string($type) || stripos($type,'application/pdf')!==0 || strpos($body,'%PDF-')!==0) { return new WP_Error('pcvt_pdf','Le fournisseur n’a pas retourné un PDF valide.'); }
            return $body;
        }
        if ($method==='PUT' && trim($body)==='') { return true; }
        $expects_list=$path==='/ProductGroup/v1.0' || preg_match('#/(?:dates|images|options)$#D',$path);
        if ($expects_list && substr(ltrim($body),0,1)!=='[') { return new WP_Error('pcvt_json','Liste JSON attendue pour cette route fournisseur.'); }
        $data=json_decode($body,true,64);
        if (json_last_error()!==JSON_ERROR_NONE || !is_array($data)) { return new WP_Error('pcvt_json','Réponse fournisseur JSON non structurée ou invalide.'); }
        return $data;
    }
    public static function setting() { return self::request('GET','/Setting/v1.0/setting'); }
    public static function terms($lang) { return self::request('GET','/Setting/v1.0/terms',array('Lang'=>$lang)); }
    public static function groups() { return self::request('GET','/ProductGroup/v1.0'); }
    public static function product($code,$date_code=null) { return self::request('GET','/Product/v1.0/'.rawurlencode($code),$date_code!==null ? array('DateCode'=>(int)$date_code) : array()); }
    public static function dates($code) { return self::request('GET','/Product/v1.0/'.rawurlencode($code).'/dates'); }
    public static function images($code) { return self::request('GET','/Product/v1.0/'.rawurlencode($code).'/images'); }
    public static function options($code,$query=array()) { return self::request('GET','/Product/v1.0/'.rawurlencode($code).'/options',$query); }
    public static function preview($body) { return self::request('POST','/Reservation/v1.0/preview',array(),$body); }
    public static function create_reservation($body) { return self::request('POST','/Reservation/v1.0',array(),$body); }
    public static function reservation($code,$token) { return self::request('GET','/Reservation/v1.0/'.rawurlencode($code),array('Token'=>$token)); }
    public static function passengers($body) { return self::request('PUT','/Pax/v1.0',array(),$body); }
    public static function create_invoice($code,$token,$lang) { return self::request('POST','/Invoice/v1.0',array(),array('isPaymentDisabled'=>true,'lang'=>$lang,'reservation'=>$code,'token'=>$token)); }
    public static function invoice($file) { return self::request('GET','/Invoice/v1.0/byfile',array('File'=>$file)); }
    public static function invoice_pdf($invoice,$file) {
        $r=self::request('GET','/Invoice/v1.0/'.rawurlencode($invoice).'/printurl',array('File'=>$file));
        if (is_wp_error($r)) { return $r; }
        $p=isset($r['url']) && is_string($r['url']) ? wp_parse_url($r['url']) : false;
        if (!$p || ($p['scheme']??'')!=='https' || strtolower($p['host']??'')!=='api.touronline.shop' ||
            ($p['path']??'')!=='/Invoice/v1.0/print' || isset($p['user']) || isset($p['pass']) || isset($p['port']) || isset($p['fragment'])) {
            return new WP_Error('pcvt_pdf_url','URL de facture hors du contrat connu; vérifier avec le fournisseur.');
        }
        $q=array(); parse_str($p['query']??'',$q); $token='';
        foreach ($q as $key=>$value) { if (strtolower($key)==='token' && is_string($value)) { $token=$value; } }
        if ($token==='' || strlen($token)>4096 || preg_match('/[\r\n]/',$token)) { return new WP_Error('pcvt_pdf_token','Jeton de document absent ou invalide.'); }
        return self::request('GET','/Invoice/v1.0/print',array('Token'=>$token),null,'pdf');
    }
}
