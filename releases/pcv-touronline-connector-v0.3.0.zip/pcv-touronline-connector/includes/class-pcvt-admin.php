<?php
if (!defined('ABSPATH')) { exit; }
final class PCVT_Admin {
    public static function boot() {
        add_action('admin_menu',array(__CLASS__,'menu'));
        foreach (array('save','test','sync','cancel','renotify') as $action) { add_action('admin_post_pcvt_'.$action,array(__CLASS__,$action)); }
        add_action('add_meta_boxes_pcvt_request',array(__CLASS__,'request_metabox'));
        add_action('save_post_pcvt_request',array(__CLASS__,'save_request'));
        add_filter('manage_pcvt_request_posts_columns',array(__CLASS__,'columns'));
        add_action('manage_pcvt_request_posts_custom_column',array(__CLASS__,'column_value'),10,2);
        add_filter('site_status_tests',array(__CLASS__,'health_tests'));
    }
    public static function menu() { add_menu_page('PCV TourOnline','PCV TourOnline','manage_options','pcvt-dashboard',array(__CLASS__,'page'),'dashicons-admin-links',57); }
    private static function guard($action) {
        if (!current_user_can('manage_options')) { wp_die('Accès refusé.','',array('response'=>403)); }
        if (strtoupper($_SERVER['REQUEST_METHOD']??'')!=='POST') { wp_die('Méthode invalide.','',array('response'=>405)); }
        check_admin_referer($action,$action==='pcvt_renotify' ? '_wpnonce_pcvt_renotify' : '_wpnonce');
    }
    private static function notice($message) {
        set_transient('pcvt_admin_notice_'.get_current_user_id(),$message,MINUTE_IN_SECONDS);
        wp_safe_redirect(admin_url('admin.php?page=pcvt-dashboard'),303); exit;
    }
    private static function input($array,$key) { return isset($array[$key]) && is_scalar($array[$key]) ? trim((string)$array[$key]) : ''; }
    public static function save() {
        self::guard('pcvt_save');
        $input=isset($_POST['pcvt']) && is_array($_POST['pcvt']) ? wp_unslash($_POST['pcvt']) : array(); $s=pcvt_settings();
        $license=self::input($input,'license');
        if ($license!=='') {
            if (strlen($license)>180 || preg_match('/[\r\n]/',$license)) { self::notice('Licence invalide : aucun paramètre modifié.'); }
            $s['license']=sanitize_text_field($license);
        }
        if (!empty($input['clear_license'])) { $s['license']=''; }
        $email=self::input($input,'admin_email');
        if ($email!=='' && !is_email($email)) { self::notice('Courriel de notification invalide : aucun paramètre modifié.'); }
        $s['admin_email']=sanitize_email($email); $s['enabled_sync']=!empty($input['enabled_sync']) ? 1 : 0;
        $s['unpublish_missing']=!empty($input['unpublish_missing']) ? 1 : 0;
        $s['lang']=self::input($input,'lang')==='en' ? 'en' : 'fr';
        $retention=self::input($input,'retention_days');
        if (!ctype_digit($retention) || ((int)$retention!==0 && ((int)$retention<30 || (int)$retention>3650))) { self::notice('Conservation : choisir 0, ou une durée de 30 à 3 650 jours. Aucun paramètre modifié.'); }
        $s['retention_days']=(int)$retention;
        $s['batch_size']=min(10,max(1,(int)self::input($input,'batch_size')));
        $s['enabled_booking']=!empty($input['enabled_booking']) ? 1 : 0;
        $mode=self::input($input,'deposit_mode');
        $s['deposit_mode']=in_array($mode,array('supplier','percent','fixed','full'),true) ? $mode : 'supplier';
        $value=self::input($input,'deposit_value');
        if (in_array($s['deposit_mode'],array('percent','fixed'),true)) {
            $amount=PCVT_Money::parse($value);
            if (is_wp_error($amount) || $amount<=0 || ($s['deposit_mode']==='percent' && $amount>10000)) { self::notice('Acompte invalide : saisir un montant positif ou un pourcentage supérieur à 0 et au plus 100.'); }
            $s['deposit_value']=str_replace(',','.',$value);
        }
        $s['supplier_agent']=sanitize_text_field(self::input($input,'supplier_agent'));
        $s['supplier_user']=sanitize_text_field(self::input($input,'supplier_user'));
        update_option('pcvt_settings',$s,false); pcvt_schedule();
        self::notice('Paramètres enregistrés. Toute réservation fournisseur nécessite la validation du règlement par un agent autorisé.');
    }
    public static function test() {
        self::guard('pcvt_test'); $r=PCVT_API::setting();
        self::notice(is_wp_error($r) ? 'Connexion échouée : '.$r->get_error_message() : 'Connexion vérifiée : GET /Setting/v1.0/setting retourne du JSON structuré. Les droits sur le catalogue restent à vérifier par un import.');
    }
    public static function sync() {
        self::guard('pcvt_sync'); $r=PCVT_Sync::run();
        self::notice(is_wp_error($r) ? $r->get_error_message() : 'Import en arrière-plan : '.(int)$r['total'].' produits. Actualisez cette page pour suivre la progression.');
    }
    public static function cancel() {
        self::guard('pcvt_cancel'); $r=PCVT_Sync::cancel(); self::notice(is_wp_error($r) ? $r->get_error_message() : 'Import arrêté. Les offres déjà traitées sont conservées.');
    }
    public static function renotify() {
        self::guard('pcvt_renotify'); $id=isset($_POST['request_id']) && is_scalar($_POST['request_id']) ? absint($_POST['request_id']) : 0;
        if (get_post_type($id)!=='pcvt_request' || !current_user_can('edit_post',$id)) { self::notice('Demande inconnue.'); }
        self::notice(PCVT_Requests::notify($id) ? 'Avis renvoyé au destinataire configuré.' : 'Échec de wp_mail : vérifier la configuration de messagerie WordPress.');
    }
    private static function action_form($action,$label,$class='secondary') {
        echo '<form style="display:inline-block;margin:0 12px 12px 0" method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
        echo '<input type="hidden" name="action" value="pcvt_'.esc_attr($action).'">'; wp_nonce_field('pcvt_'.$action);
        submit_button($label,$class,'submit',false); echo '</form>';
    }
    public static function page() {
        if (!current_user_can('manage_options')) { return; }
        $s=pcvt_settings(); $state=PCVT_Sync::state(); $notice=get_transient('pcvt_admin_notice_'.get_current_user_id());
        if ($notice) { delete_transient('pcvt_admin_notice_'.get_current_user_id()); }
        ?>
        <div class="wrap"><h1>PCV TourOnline Connector <?php echo esc_html(PCVT_VERSION); ?></h1>
        <?php if ($notice): ?><div class="notice notice-info"><p><?php echo esc_html($notice); ?></p></div><?php endif; ?>
        <div class="notice notice-warning inline"><p>Catalogue et CRM de demandes. Si le parcours agent est activé, un agent peut enregistrer un règlement en espèces puis demander la réservation, la facture fournisseur et son envoi. Aucun paiement en ligne ni création automatique de compte client. Les espèces ne sont pas reportées dans PC Voyages par l’API fournie.</p></div>
        <h2>Synchronisation</h2>
        <p><?php echo esc_html($s['last_sync'] ?: 'Aucun import'); ?> — <?php echo esc_html($s['last_result']); ?></p>
        <?php if (!empty($state['status'])): ?>
            <p><strong>État :</strong> <?php echo esc_html($state['status']); ?> — <?php echo (int)($state['cursor']??0); ?> / <?php echo (int)($state['total']??0); ?> produits traités.</p>
            <?php if ($state['status']==='running'): ?><progress max="<?php echo max(1,(int)$state['total']); ?>" value="<?php echo (int)$state['cursor']; ?>"></progress>
                <p>Les lots sont exécutés par WP-Cron. <a href="<?php echo esc_url(admin_url('admin.php?page=pcvt-dashboard')); ?>">Actualiser la progression</a>. Pour un site sans trafic, utiliser un Cron système ou <code>wp pcvt sync --wait</code>.</p>
            <?php endif; ?>
            <?php if (!empty($state['issues'])): ?><ul><?php foreach ($state['issues'] as $issue) { echo '<li>'.esc_html($issue).'</li>'; } ?></ul><?php endif; ?>
        <?php endif; ?>
        <?php self::action_form('test','Tester la connexion'); self::action_form('sync','Démarrer / reprendre l’import','primary'); ?>
        <?php if (!empty($state['status']) && $state['status']==='running') { self::action_form('cancel','Arrêter l’import'); } ?>
        <h2>Configuration</h2>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <input type="hidden" name="action" value="pcvt_save"><?php wp_nonce_field('pcvt_save'); ?>
        <table class="form-table"><tbody>
        <tr><th><label for="pcvt_license">Licence TourOnline</label></th><td><input id="pcvt_license" type="password" autocomplete="new-password" name="pcvt[license]" maxlength="180" class="regular-text" placeholder="<?php echo pcvt_license() ? 'Configurée — laisser vide pour conserver' : 'Licence à renseigner'; ?>">
        <p class="description">La valeur n’est jamais réaffichée. Préférer la constante <code>PCVT_LICENSE</code> dans wp-config.php. Jeton facultatif : <code>PCVT_BEARER_TOKEN</code>. Une constante a priorité sur la base.</p>
        <label><input type="checkbox" name="pcvt[clear_license]" value="1"> Effacer la licence en base</label></td></tr>
        <tr><th><label for="pcvt_lang">Langue des données</label></th><td><select id="pcvt_lang" name="pcvt[lang]"><option value="fr" <?php selected($s['lang'],'fr'); ?>>Français</option><option value="en" <?php selected($s['lang'],'en'); ?>>English</option></select><p class="description">Les libellés de l’interface restent en français. Une nouvelle synchronisation applique la langue aux fiches.</p></td></tr>
        <tr><th>Import automatique</th><td><label><input name="pcvt[enabled_sync]" type="checkbox" value="1" <?php checked($s['enabled_sync'],1); ?>> Toutes les 15 minutes, si la licence est configurée</label></td></tr>
        <tr><th>Parcours de réservation agent</th><td><label><input name="pcvt[enabled_booking]" type="checkbox" value="1" <?php checked($s['enabled_booking'],1); ?>> Autoriser les appels de réservation et facturation après validation de l’agent</label><p class="description">Désactivé par défaut. Tester d’abord avec la licence de préproduction, le JWT si requis et les données fournisseur. Les créations peuvent engager les disponibilités et le dossier client.</p></td></tr>
        <tr><th><label for="pcvt_deposit_mode">Minimum à encaisser</label></th><td><select id="pcvt_deposit_mode" name="pcvt[deposit_mode]">
        <?php foreach (array('supplier'=>'Acompte retourné par le fournisseur','percent'=>'Pourcentage du total','fixed'=>'Montant fixe dans la devise du devis','full'=>'Paiement intégral') as $key=>$label) { echo '<option value="'.esc_attr($key).'" '.selected($s['deposit_mode'],$key,false).'>'.esc_html($label).'</option>'; } ?>
        </select> <label>Valeur <input id="pcvt_deposit_value" name="pcvt[deposit_value]" inputmode="decimal" value="<?php echo esc_attr($s['deposit_value']); ?>"></label><p class="description">Le minimum retenu ne descend jamais sous l’acompte fournisseur. Un acompte fournisseur nul en mode fournisseur demande le total. Aucun montant n’est débité en ligne.</p></td></tr>
        <tr><th>Références fournisseur facultatives</th><td><label>Agent <input name="pcvt[supplier_agent]" value="<?php echo esc_attr($s['supplier_agent']); ?>" maxlength="180"></label><br><label>Utilisateur fournisseur <input name="pcvt[supplier_user]" value="<?php echo esc_attr($s['supplier_user']); ?>" maxlength="180"></label><p class="description">Uniquement les références communiquées par le fournisseur; ne pas saisir ici un identifiant utilisateur WordPress ou inventer une référence client. Les voyageurs sont transmis séparément.</p></td></tr>
        <tr><th><label for="pcvt_batch">Produits par lot</label></th><td><input id="pcvt_batch" name="pcvt[batch_size]" type="number" min="1" max="10" value="<?php echo (int)$s['batch_size']; ?>"><p class="description">3 par défaut; contrôle du temps entre les produits. Réduire à 1 sur un hébergement à temps d’exécution court.</p></td></tr>
        <tr><th>Offres retirées du catalogue</th><td><label><input name="pcvt[unpublish_missing]" type="checkbox" value="1" <?php checked($s['unpublish_missing'],1); ?>> Passer en brouillon après deux imports complets réussis sans le produit</label><p class="description">Désactivé par défaut. Aucun retrait sur catalogue vide, import incomplet ou interrompu. Les brouillons et suppressions manuels sont préservés.</p></td></tr>
        <tr><th><label for="pcvt_email">Courriel des avis</label></th><td><input id="pcvt_email" class="regular-text" type="email" name="pcvt[admin_email]" value="<?php echo esc_attr($s['admin_email']); ?>" placeholder="<?php echo esc_attr(get_option('admin_email')); ?>"><p class="description">Les coordonnées des clients ne figurent pas dans les avis. Un enregistrement demeure reçu même si l’envoi échoue.</p></td></tr>
        <tr><th><label for="pcvt_retention">Conservation des demandes</label></th><td><input id="pcvt_retention" type="number" min="0" max="3650" name="pcvt[retention_days]" value="<?php echo (int)$s['retention_days']; ?>"> jours
        <p class="description"><strong>Suppression définitive</strong> des demandes anciennes sans écriture financière. Les demandes avec encaissement ou référence fournisseur sont conservées pour une gestion manuelle. Valeurs : 30–3 650 jours, ou 0 pour une suppression manuelle. Nouvelle installation : 180 jours. Adapter la politique du site et les sauvegardes.</p></td></tr>
        </tbody></table><?php submit_button('Enregistrer'); ?></form>
        <h2>Catalogue et demandes</h2><p>Créer une page contenant <code>[pcvt_offres limit="12"]</code>. Filtres : recherche et groupe; pagination automatique. Pour un groupe fixe : <code>[pcvt_offres group="Nom du groupe"]</code>.</p>
        <p><a href="<?php echo esc_url(admin_url('edit.php?post_type=pcvt_request')); ?>">Consulter les demandes</a> · Export/effacement par courriel dans les outils de confidentialité WordPress.</p>
        <p>Diagnostic : Outils → Santé du site. Documentation : <code>README.md</code>, <code>BILAN_AMELIORATIONS.md</code>.</p></div>
        <?php
    }
    public static function request_metabox() { add_meta_box('pcvt_request_details','Données client et suivi interne',array(__CLASS__,'details'),'pcvt_request','normal','high'); }
    public static function details($post) {
        if (!current_user_can('manage_pcvt_bookings')) { return; }
        foreach (array('offer'=>'Offre','code'=>'Code produit','date'=>'Départ','date_return'=>'Retour','date_code'=>'Code du départ',
            'first'=>'Prénom','last'=>'Nom','email'=>'Courriel','phone'=>'Téléphone','adults'=>'Adultes','children'=>'Enfants',
            'note'=>'Message','consent'=>'Consentement','created'=>'Réception','quoted_unit_price'=>'Prix unitaire indicatif',
            'currency'=>'Devise','catalogue_updated'=>'Catalogue actualisé (UTC)','notification'=>'Avis administrateur') as $key=>$label) {
            $value=get_post_meta($post->ID,'_pcvt_'.$key,true);
            echo '<p><strong>'.esc_html($label).' :</strong> '.nl2br(esc_html(is_scalar($value) ? (string)$value : '')).'</p>';
        }
        wp_nonce_field('pcvt_request_'.$post->ID,'pcvt_request_nonce');
        echo '<p><label for="pcvt_request_status"><strong>Suivi interne :</strong></label> <select id="pcvt_request_status" name="pcvt_request_status">';
        $status=get_post_meta($post->ID,'_pcvt_status',true) ?: 'new';
        foreach (PCVT_Requests::statuses() as $key=>$label) { echo '<option value="'.esc_attr($key).'" '.selected($status,$key,false).'>'.esc_html($label).'</option>'; }
        echo '</select></p><p>Enregistrer avec « Mettre à jour ». Ces statuts de suivi ne créent ni n’annulent une réservation fournisseur. Le bloc d’encaissement et dossier PC Voyages indique les références et le résultat réel du traitement.</p>';
        if (!current_user_can('manage_options')) { return; }
        $nonce=wp_create_nonce('pcvt_renotify');
        // A button on the existing edit form avoids invalid nested forms.
        echo '<p><button type="submit" class="button" formaction="'.esc_url(admin_url('admin-post.php')).'" name="action" value="pcvt_renotify">Renvoyer l’avis administrateur</button></p>';
        echo '<input type="hidden" name="request_id" value="'.(int)$post->ID.'"><input type="hidden" name="_wpnonce_pcvt_renotify" value="'.esc_attr($nonce).'">';
    }
    public static function save_request($id) {
        if (!current_user_can('manage_pcvt_bookings') || wp_is_post_revision($id) || (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)) { return; }
        $nonce=isset($_POST['pcvt_request_nonce']) && is_string($_POST['pcvt_request_nonce']) ? sanitize_text_field(wp_unslash($_POST['pcvt_request_nonce'])) : '';
        if (!wp_verify_nonce($nonce,'pcvt_request_'.$id)) { return; }
        $status=isset($_POST['pcvt_request_status']) && is_string($_POST['pcvt_request_status']) ? sanitize_key(wp_unslash($_POST['pcvt_request_status'])) : '';
        if (isset(PCVT_Requests::statuses()[$status])) { update_post_meta($id,'_pcvt_status',$status); }
    }
    public static function columns($columns) { return array_merge($columns,array('pcvt_client'=>'Client','pcvt_offer'=>'Offre','pcvt_date'=>'Départ','pcvt_status'=>'Suivi','pcvt_notification'=>'Avis')); }
    public static function column_value($name,$id) {
        if (!current_user_can('manage_pcvt_bookings')) { return; }
        if ($name==='pcvt_client') { echo esc_html(get_post_meta($id,'_pcvt_first',true).' '.get_post_meta($id,'_pcvt_last',true)); }
        elseif ($name==='pcvt_offer') { echo esc_html(get_post_meta($id,'_pcvt_offer',true)); }
        elseif ($name==='pcvt_date') { echo esc_html(get_post_meta($id,'_pcvt_date',true)); }
        elseif ($name==='pcvt_status') { $s=get_post_meta($id,'_pcvt_status',true) ?: 'new'; echo esc_html(PCVT_Requests::statuses()[$s]??$s); }
        elseif ($name==='pcvt_notification') { echo esc_html(get_post_meta($id,'_pcvt_notification',true)==='sent' ? 'Envoyé' : 'À vérifier'); }
    }
    public static function health_tests($tests) {
        $tests['direct']['pcvt_readiness']=array('label'=>'PCV TourOnline','test'=>array(__CLASS__,'health')); return $tests;
    }
    public static function health() {
        $s=pcvt_settings(); $state=PCVT_Sync::state(); $issues=array();
        if (!pcvt_license()) { $issues[]='Licence fournisseur absente.'; }
        if (!empty($s['enabled_sync']) && defined('DISABLE_WP_CRON') && DISABLE_WP_CRON) { $issues[]='WP-Cron automatique désactivé : vérifier le Cron système.'; }
        if (!empty($state['failed'])) { $issues[]='Le dernier import comporte des erreurs.'; }
        if (!empty($state['status']) && $state['status']==='running' && time()-(int)$state['heartbeat']>10*MINUTE_IN_SECONDS) { $issues[]='La file d’import ne progresse plus depuis 10 minutes.'; }
        return array('label'=>$issues ? 'PCV TourOnline : points à vérifier' : 'PCV TourOnline : prérequis configurés',
            'status'=>$issues ? 'recommended' : 'good','badge'=>array('label'=>'PCV','color'=>'blue'),
            'description'=>'<p>'.esc_html($issues ? implode(' ',$issues) : 'Les paramètres sont présents. Seuls un import et des tests fournisseur peuvent confirmer l’intégration réelle.').'</p>',
            'actions'=>'<a href="'.esc_url(admin_url('admin.php?page=pcvt-dashboard')).'">Configurer PCV TourOnline</a>','test'=>'pcvt_readiness');
    }
}
PCVT_Admin::boot();
