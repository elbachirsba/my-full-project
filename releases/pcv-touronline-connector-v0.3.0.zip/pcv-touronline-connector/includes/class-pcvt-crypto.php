<?php
if (!defined('ABSPATH')) { exit; }
final class PCVT_Crypto {
    private static function key() { return hash('sha256',wp_salt('auth').'|'.wp_salt('secure_auth'),true); }
    public static function ready() { return function_exists('openssl_encrypt') && in_array('aes-256-gcm',openssl_get_cipher_methods(),true); }
    public static function encrypt($value,$id) {
        if (!self::ready()) { return new WP_Error('pcvt_crypto','OpenSSL AES-256-GCM est nécessaire pour les jetons de réservation.'); }
        try {
            $iv=random_bytes(12); $tag='';
            $cipher=openssl_encrypt($value,'aes-256-gcm',self::key(),OPENSSL_RAW_DATA,$iv,$tag,'pcvt:reservation:'.$id);
            if ($cipher===false) { return new WP_Error('pcvt_crypto','Chiffrement du jeton impossible.'); }
            return 'v1:'.base64_encode($iv.$tag.$cipher);
        } catch (Throwable $e) { return new WP_Error('pcvt_crypto','Chiffrement du jeton impossible.'); }
    }
    public static function decrypt($value,$id) {
        if (!self::ready() || !is_string($value) || strpos($value,'v1:')!==0) { return new WP_Error('pcvt_crypto','Jeton fournisseur indisponible.'); }
        $raw=base64_decode(substr($value,3),true);
        if ($raw===false || strlen($raw)<29) { return new WP_Error('pcvt_crypto','Jeton fournisseur illisible.'); }
        $plain=openssl_decrypt(substr($raw,28),'aes-256-gcm',self::key(),OPENSSL_RAW_DATA,substr($raw,0,12),substr($raw,12,16),'pcvt:reservation:'.$id);
        return $plain===false ? new WP_Error('pcvt_crypto','Jeton illisible : vérifier les clés de sécurité WordPress et la sauvegarde.') : $plain;
    }
}
