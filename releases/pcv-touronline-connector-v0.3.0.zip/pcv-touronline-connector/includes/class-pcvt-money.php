<?php
if (!defined('ABSPATH')) { exit; }
/** Monetary ledger values are integer cents, never binary floating-point balances. */
final class PCVT_Money {
    public static function parse($value) {
        if (!is_scalar($value) || is_bool($value)) { return new WP_Error('pcvt_amount','Montant invalide.'); }
        $value=trim((string)$value);
        if (!preg_match('/^(0|[1-9][0-9]{0,7})(?:[.,]([0-9]{1,2}))?$/D',$value,$m)) { return new WP_Error('pcvt_amount','Utiliser un montant positif avec au plus deux décimales.'); }
        $whole=(int)$m[1];
        if ($whole>intdiv(PHP_INT_MAX-99,100)) { return new WP_Error('pcvt_amount','Montant trop élevé.'); }
        return $whole*100+(int)str_pad($m[2]??'',2,'0');
    }
    public static function from_api($value) {
        if (is_float($value)) {
            if (!is_finite($value) || $value<0 || $value>99999999.99) { return new WP_Error('pcvt_amount','Montant fournisseur invalide.'); }
            $value=number_format($value,2,'.','');
        }
        return self::parse($value);
    }
    public static function decimal($minor) { return intdiv($minor,100).'.'.str_pad((string)($minor%100),2,'0',STR_PAD_LEFT); }
    public static function display($minor,$currency) { return number_format_i18n($minor/100,2).' '.PCVT_Sync::currency($currency); }
    public static function minimum($total,$supplier_deposit,$mode,$value) {
        if ($total<0 || $supplier_deposit<0 || $supplier_deposit>$total) { return new WP_Error('pcvt_deposit','Acompte fournisseur incohérent.'); }
        if ($mode==='percent') {
            $basis=self::parse($value);
            if (is_wp_error($basis) || $basis<=0 || $basis>10000) { return new WP_Error('pcvt_deposit','Le pourcentage doit être supérieur à 0 et au plus 100.'); }
            $local=intdiv($total,10000)*$basis+intdiv(($total%10000)*$basis+9999,10000);
        } elseif ($mode==='fixed') {
            $local=self::parse($value);
            if (is_wp_error($local) || $local<=0) { return new WP_Error('pcvt_deposit','Acompte fixe invalide.'); }
        } elseif ($mode==='full') { $local=$total; }
        else { $local=$supplier_deposit>0 ? $supplier_deposit : $total; }
        return min($total,max($local,$supplier_deposit));
    }
}
