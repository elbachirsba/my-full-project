<?php
if (!defined('ABSPATH')) { exit; }
/** Atomic locks stored as non-autoloaded options, safe with or without a persistent cache. */
final class PCVT_Lock {
    public static function acquire($name, $ttl=180) {
        global $wpdb;
        $key = 'pcvt_lock_'.md5($name);
        $value = (time()+$ttl).':'.wp_generate_uuid4();
        // add_option() uses an upsert in WordPress: two concurrent callers can both win.
        // INSERT IGNORE relies on the unique option_name index and never changes an owner.
        if (self::insert($key,$value)) { return array($key,$value); }
        $old = $wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name = %s",$key));
        if (is_string($old) && (int)$old < time()) {
            self::release(array($key,$old));
            if (self::insert($key,$value)) { return array($key,$value); }
        }
        return false;
    }
    private static function insert($key,$value) {
        global $wpdb;
        $inserted=$wpdb->query($wpdb->prepare("INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'no')",$key,$value));
        if ($inserted!==1) { return false; }
        self::invalidate($key); return true;
    }
    private static function invalidate($key) {
        wp_cache_delete($key,'options');
        $notoptions=wp_cache_get('notoptions','options');
        if (is_array($notoptions) && isset($notoptions[$key])) {
            unset($notoptions[$key]); wp_cache_set('notoptions',$notoptions,'options');
        }
    }
    public static function release($lock) {
        if (!$lock) { return; }
        global $wpdb;
        // Compare-and-delete prevents an expired worker from deleting its successor's lock.
        $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s", $lock[0], $lock[1]));
        self::invalidate($lock[0]);
    }
    public static function cleanup() {
        global $wpdb;
        $rows=$wpdb->get_results($wpdb->prepare("SELECT option_name, option_value FROM {$wpdb->options} WHERE option_name LIKE %s LIMIT 500",$wpdb->esc_like('pcvt_lock_').'%'));
        foreach ($rows as $row) {
            if ((int)$row->option_value<time()) { self::release(array($row->option_name,$row->option_value)); }
        }
    }
}
