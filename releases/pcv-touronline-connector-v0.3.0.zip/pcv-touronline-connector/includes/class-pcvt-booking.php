<?php
if (!defined('ABSPATH')) { exit; }
/** Agent-controlled, checkpointed supplier workflow. Creation POSTs are never blindly retried. */
final class PCVT_Booking {
    const META = '_pcvt_booking';
    public static function boot() {
        add_action('pcvt_booking_step',array(__CLASS__,'worker'));
        add_action('init',array(__CLASS__,'resume'),35);
        add_action('before_delete_post',function($id,$post) {
            if ($post->post_type==='pcvt_request') { delete_option('pcvt_pending_booking_'.$id); wp_clear_scheduled_hook('pcvt_booking_step',array((int)$id)); }
        },10,2);
    }
    public static function state($id) { $s=get_post_meta($id,self::META,true); return is_array($s) ? $s : array('phase'=>'draft'); }
    public static function quote_data($id) { $q=get_post_meta($id,'_pcvt_quote',true); return is_array($q) ? $q : array(); }
    private static function put($id,$state) {
        $state['updated_at']=time(); update_post_meta($id,self::META,wp_slash($state));
        if (get_post_meta($id,self::META,true)!==$state) { throw new RuntimeException('Booking checkpoint could not be persisted.'); }
    }
    private static function lock($id,$ttl) {
        $lock=PCVT_Lock::acquire('booking-'.$id,$ttl);
        // Another PHP process may have committed after this request primed a metadata cache.
        if ($lock) { wp_cache_delete($id,'post_meta'); }
        return $lock;
    }
    private static function error($code,$text) { return new WP_Error('pcvt_'.$code,$text); }
    public static function guard($id) {
        if (!current_user_can('manage_pcvt_bookings')) { return self::error('forbidden','Accès réservé aux agents PCV autorisés.'); }
        if (get_post_type($id)!=='pcvt_request' || get_post_status($id)==='trash') { return self::error('request','Demande introuvable.'); }
        return true;
    }
    private static function text($input,$key,$max=180) {
        if (!isset($input[$key]) || !is_scalar($input[$key])) { return ''; }
        $value=sanitize_text_field((string)$input[$key]);
        return function_exists('mb_substr') ? mb_substr($value,0,$max,'UTF-8') : substr($value,0,$max);
    }
    public static function audit($id,$event,$data=array(),$actor=null) {
        // Only explicitly selected non-secret metadata is logged by callers.
        add_post_meta($id,'_pcvt_audit',wp_slash(array('at'=>gmdate('c'),'actor'=>$actor===null ? get_current_user_id() : (int)$actor,'event'=>$event,'data'=>$data)));
    }
    private static function schedule($id,$delay=2) {
        if (!wp_next_scheduled('pcvt_booking_step',array((int)$id))) { wp_schedule_single_event(time()+max(1,(int)$delay),'pcvt_booking_step',array((int)$id)); }
    }
    public static function resume() {
        global $wpdb;
        // Indexed option-name prefix lookup; never load all personal records on page views.
        $keys=$wpdb->get_col($wpdb->prepare("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s LIMIT 50",$wpdb->esc_like('pcvt_pending_booking_').'%'));
        foreach ($keys as $key) { self::schedule((int)substr($key,strlen('pcvt_pending_booking_'))); }
    }
    private static function pending($id,$add) {
        $key='pcvt_pending_booking_'.(int)$id;
        if ($add) { add_option($key,1,'',false); } else { delete_option($key); }
    }
    public static function phases() { return array('draft'=>'Demande reçue','quote_ready'=>'Prix vérifié — règlement attendu','quote_changed'=>'Prix ou disponibilité à revoir',
        'queued'=>'Validation agent reçue','ready_create'=>'Contrôles fournisseur effectués','creating_reservation'=>'Création de réservation en cours',
        'reservation_created'=>'Réservation fournisseur créée','updating_passengers'=>'Transmission des voyageurs en cours','passengers_saved'=>'Voyageurs transmis',
        'creating_invoice'=>'Création de facture en cours','invoice_created'=>'Facture fournisseur créée','ready_email'=>'Facture prête à envoyer',
        'sending_invoice'=>'Envoi de facture en cours','email_failed'=>'Facture créée — envoi à reprendre','completed'=>'Réservation et facture créées — courriel accepté',
        'manual_review'=>'Vérification manuelle requise'); }
    public static function offer_id($id) {
        $offer=(int)get_post_meta($id,'_pcvt_offer_id',true);
        if ($offer && get_post_type($offer)==='pcvt_offer') { return $offer; }
        $ids=get_posts(array('post_type'=>'pcvt_offer','post_status'=>array('publish','draft'),'meta_key'=>'_pcvt_code','meta_value'=>get_post_meta($id,'_pcvt_code',true),'fields'=>'ids','numberposts'=>1));
        return (int)($ids[0]??0);
    }
    private static function body($id,$input) {
        $s=pcvt_settings(); $code=(string)get_post_meta($id,'_pcvt_code',true); $date=(int)get_post_meta($id,'_pcvt_date_code',true);
        $adults=(int)get_post_meta($id,'_pcvt_adults',true); $children=(int)get_post_meta($id,'_pcvt_children',true);
        if (!$code || !$date || $adults<1 || $children<0 || $adults+$children>20) { return self::error('booking_input','Produit, départ ou voyageurs invalides.'); }
        $room=self::text($input,'nb_room');
        if ($room==='') { $room='1'; }
        if (!ctype_digit($room) || (int)$room<1 || (int)$room>$adults+$children) { return self::error('rooms','Nombre de chambres invalide.'); }
        $detail=PCVT_API::product($code,$date);
        if (is_wp_error($detail)) { return $detail; }
        $classes=is_array($detail['listClass']??null) ? $detail['listClass'] : array();
        $pickups=is_array($detail['listBusPickup']??null) ? $detail['listBusPickup'] : array();
        update_post_meta($id,'_pcvt_booking_choices',wp_slash(array('classes'=>$classes,'pickups'=>$pickups)));
        $body=array('product'=>$code,'productPriceDateCode'=>$date,'nbAdult'=>$adults,'nbChild'=>$children,'nbRoom'=>(int)$room);
        if ($classes) {
            $class_code=self::text($input,'class_code'); $category_code=self::text($input,'category_code'); $selected=null;
            foreach ($classes as $class) { if (is_array($class) && (string)($class['code']??'')===$class_code) { $selected=$class; break; } }
            if (!$selected) { return self::error('class','Les tarifs ont été chargés. Choisir une classe et une catégorie, puis vérifier le prix.'); }
            $category=null;
            foreach (is_array($selected['listCategory']??null) ? $selected['listCategory'] : array() as $c) { if (is_array($c) && (string)($c['code']??'')===$category_code) { $category=$c; break; } }
            if (!$category) { return self::error('category','Choisir une catégorie correspondant à la classe.'); }
            foreach (array('productPriceClassCode'=>$selected['code']??null,'pricingClassCode'=>$selected['pricingClass']['code']??null,
                'productPriceCategoryCode'=>$category['code']??null,'pricingCategoryCode'=>$category['pricingCategory']['code']??null) as $key=>$value) {
                if (!is_numeric($value) || (int)$value<0) { return self::error('class','Tarif fournisseur incomplet.'); }
                $body[$key]=(int)$value;
            }
            if (!empty($selected['hasOption'])) {
                $query=array('PricingCategory'=>$body['pricingCategoryCode'],'PricingClass'=>$body['pricingClassCode'],'NbPax'=>$adults+$children,'NbRoom'=>$body['nbRoom']);
                $depart=get_post_meta($id,'_pcvt_date',true); $return=get_post_meta($id,'_pcvt_date_return',true);
                if (is_string($depart) && $depart!=='') { $query['DateFrom']=$depart; }
                if (is_string($return) && $return!=='') { $query['DateTo']=$return; }
                $options=PCVT_API::options($code,$query); if (is_wp_error($options)) { return $options; }
                $context=hash('sha256',wp_json_encode($query));
                update_post_meta($id,'_pcvt_booking_options',wp_slash(array_slice($options,0,100)));
                update_post_meta($id,'_pcvt_booking_options_context',$context);
                if (count($options)>100 || empty($input['options_reviewed']) || !isset($input['options_context']) || !is_string($input['options_context']) || !hash_equals($context,$input['options_context'])) { return self::error('options','Options actualisées : vérifier les quantités et cocher leur validation avant de demander le prix.'); }
                $known=array(); foreach ($options as $o) { if (is_array($o) && isset($o['code']) && is_int($o['code']) && $o['code']>=0) { $known[$o['code']]=$o; } }
                $chosen=$input['options']??array(); if (!is_array($chosen)) { return self::error('options','Sélection d’options invalide.'); }
                $body['listOption']=array();
                foreach ($chosen as $key=>$quantity) {
                    if (!ctype_digit((string)$key) || !is_scalar($quantity) || !preg_match('/^[0-9]{1,3}$/D',(string)$quantity) || (int)$quantity>100 || !isset($known[(int)$key])) { return self::error('options','Code ou quantité d’option invalide.'); }
                    if ((int)$quantity===0) { continue; }
                    $o=$known[(int)$key];
                    if (!empty($o['hasInventory']) && (int)$quantity>(int)($o['availability']??0)) { return self::error('options','Une option ne dispose plus de la quantité demandée.'); }
                    $body['listOption'][]=array('code'=>(int)$key,'quantity'=>(int)$quantity);
                }
            }
        }
        $pickup=self::text($input,'bus_pickup');
        if ($pickup!=='') {
            $found=false; foreach ($pickups as $p) { if (is_array($p) && (string)($p['code']??'')===$pickup) { $found=true; break; } }
            if (!$found || !ctype_digit($pickup)) { return self::error('pickup','Arrêt de départ invalide.'); }
            $body['busPickup']=(int)$pickup;
        }
        if (!empty($s['supplier_agent'])) { $body['agent']=$s['supplier_agent']; }
        return $body;
    }
    private static function available($code,$date_code) {
        $dates=PCVT_API::dates($code); if (is_wp_error($dates)) { return $dates; }
        foreach (PCVT_Sync::available_dates(PCVT_Sync::safe_dates($dates)) as $d) {
            if ((int)$d['productPriceDateCode']===$date_code) { return true; }
        }
        return self::error('sold_out','Ce départ n’est plus disponible chez le fournisseur; aucune création de réservation effectuée.');
    }
    private static function totals($preview) {
        if (!is_array($preview) || !isset($preview['total'],$preview['deposit'],$preview['currency']) || !is_string($preview['currency']) || !preg_match('/^[A-Z]{3}$/D',$preview['currency'])) { return self::error('quote_schema','Total, acompte et devise fournisseur sont nécessaires.'); }
        $total=PCVT_Money::from_api($preview['total']); $deposit=PCVT_Money::from_api($preview['deposit']);
        if (is_wp_error($total) || is_wp_error($deposit) || $deposit>$total) { return self::error('quote_schema','Montants fournisseur incohérents.'); }
        $s=pcvt_settings(); $minimum=PCVT_Money::minimum($total,$deposit,$s['deposit_mode'],$s['deposit_value']);
        if (is_wp_error($minimum)) { return $minimum; }
        return array('total_minor'=>$total,'supplier_deposit_minor'=>$deposit,'minimum_minor'=>$minimum,'currency'=>$preview['currency']);
    }
    private static function license_fingerprint() { return hash_hmac('sha256',pcvt_license(),wp_salt('nonce')); }
    private static function reference_used($id,$key,$code) {
        return (bool)get_posts(array('post_type'=>'pcvt_request','post_status'=>array('private','draft','publish','trash'),
            'meta_key'=>$key,'meta_value'=>$code,'fields'=>'ids','numberposts'=>1,'post__not_in'=>array($id)));
    }
    public static function quote($id,$input=array()) {
        $guard=self::guard($id); if (is_wp_error($guard)) { return $guard; }
        if (empty(pcvt_settings()['enabled_booking'])) { return self::error('disabled','Activer le parcours agent dans les réglages.'); }
        $lock=self::lock($id,180); if (!$lock) { return self::error('busy','Ce dossier est en cours de traitement.'); }
        try {
            $state=self::state($id);
            if (!in_array($state['phase'],array('draft','quote_ready','quote_changed'),true) || !empty($state['reservation_code'])) { return self::error('immutable','Un dossier fournisseur est engagé : conserver sa référence et effectuer la vérification manuelle.'); }
            $body=self::body($id,$input); if (is_wp_error($body)) { return $body; }
            $ok=self::available($body['product'],$body['productPriceDateCode']); if (is_wp_error($ok)) { return $ok; }
            $preview=PCVT_API::preview($body); if (is_wp_error($preview)) { return $preview; }
            $totals=self::totals($preview); if (is_wp_error($totals)) { return $totals; }
            if (!self::matches($preview,array_merge($totals,array('body'=>$body)))) { return self::error('quote_schema','La prévisualisation ne correspond pas au produit et au départ choisis.'); }
            $previous=self::quote_data($id);
            if ($previous && self::paid($id,$previous['currency'])>0 && $previous['currency']!==$totals['currency']) { return self::error('currency','Un encaissement existe dans une autre devise; corriger le dossier avant de changer de devise.'); }
            if (self::paid($id,$totals['currency'])>$totals['total_minor']) { return self::error('overpayment','Le nouveau prix est inférieur au montant déjà reçu; régler la correction de caisse avant de valider ce prix.'); }
            $terms='';
            if (!empty($preview['withTerms'])) {
                $r=PCVT_API::terms(pcvt_settings()['lang']); if (is_wp_error($r)) { return $r; }
                if (!isset($r['terms']) || !is_string($r['terms']) || trim($r['terms'])==='') { return self::error('terms','Conditions fournisseur manquantes.'); }
                $terms=wp_kses_post($r['terms']);
            }
            $q=array_merge($totals,array('body'=>$body,'at'=>time(),'agent'=>get_current_user_id(),'terms'=>$terms,'terms_hash'=>hash('sha256',$terms),'revision'=>wp_generate_uuid4(),
                'license_fingerprint'=>self::license_fingerprint(),'supplier_user'=>self::text($input,'supplier_user') ?: pcvt_settings()['supplier_user']));
            update_post_meta($id,'_pcvt_quote',wp_slash($q));
            $state=array('phase'=>'quote_ready'); self::put($id,$state);
            self::audit($id,'quote_verified',array('total_minor'=>$q['total_minor'],'minimum_minor'=>$q['minimum_minor'],'currency'=>$q['currency']));
            return $q;
        } finally { PCVT_Lock::release($lock); }
    }
    public static function ledger($id) { return get_post_meta($id,'_pcvt_cash_entry',false); }
    public static function paid($id,$currency) {
        $voids=get_post_meta($id,'_pcvt_cash_void',false); $voided=array();
        foreach ($voids as $v) { if (is_array($v)) { $voided[$v['entry_id']??'']=true; } }
        $total=0;
        foreach (self::ledger($id) as $entry) { if (is_array($entry) && !isset($voided[$entry['id']??'']) && ($entry['currency']??'')===$currency) { $total+=(int)$entry['amount_minor']; } }
        return $total;
    }
    public static function cash($id,$amount,$currency,$operation,$reference='') {
        $guard=self::guard($id); if (is_wp_error($guard)) { return $guard; }
        $minor=PCVT_Money::parse($amount);
        if (is_wp_error($minor) || $minor<=0 || !is_string($operation) || !preg_match('/^[a-f0-9-]{36}$/D',$operation)) { return self::error('cash','Montant ou identifiant d’encaissement invalide.'); }
        $lock=self::lock($id,60); if (!$lock) { return self::error('busy','Ce dossier est en cours de traitement.'); }
        try {
            foreach (self::ledger($id) as $entry) {
                if (($entry['id']??'')===$operation) {
                    return ($entry['amount_minor']??null)===$minor && ($entry['currency']??'')===$currency ? $entry : self::error('cash_conflict','Cet identifiant d’encaissement appartient déjà à un autre montant ou une autre devise.');
                }
            }
            $q=self::quote_data($id);
            if (!$q || $currency!==$q['currency']) { return self::error('currency','Vérifier le prix et la devise avant l’encaissement.'); }
            if ($minor>$q['total_minor']-self::paid($id,$currency)) { return self::error('overpayment','Le montant dépasse le solde restant dans WordPress.'); }
            $entry=array('id'=>$operation,'at'=>gmdate('c'),'agent'=>get_current_user_id(),'amount_minor'=>$minor,'currency'=>$currency,'method'=>'cash','reference'=>substr(sanitize_text_field((string)$reference),0,120));
            update_post_meta($id,'_pcvt_financial_record',1);
            if ((int)get_post_meta($id,'_pcvt_financial_record',true)!==1 || !add_post_meta($id,'_pcvt_cash_entry',wp_slash($entry))) { return self::error('storage','L’encaissement n’a pas pu être enregistré. Vérifier la base avant toute nouvelle saisie.'); }
            self::audit($id,'cash_recorded',array('entry_id'=>$operation,'amount_minor'=>$minor,'currency'=>$currency));
            return $entry;
        } finally { PCVT_Lock::release($lock); }
    }
    public static function void_cash($id,$entry_id,$reason) {
        $guard=self::guard($id); if (is_wp_error($guard)) { return $guard; }
        if (!is_string($reason) || strlen(trim($reason))<5) { return self::error('reason','Préciser le motif de correction de caisse.'); }
        $lock=self::lock($id,60); if (!$lock) { return self::error('busy','Dossier en cours.'); }
        try {
            if (!in_array(self::state($id)['phase'],array('draft','quote_ready','quote_changed'),true)) { return self::error('cash_locked','Le fournisseur est engagé : traiter la correction/remboursement manuellement dans les deux systèmes.'); }
            $exists=false; foreach (self::ledger($id) as $e) { if (($e['id']??'')===$entry_id) { $exists=true; } }
            if (!$exists) { return self::error('cash','Écriture de caisse inconnue.'); }
            foreach (get_post_meta($id,'_pcvt_cash_void',false) as $v) { if (($v['entry_id']??'')===$entry_id) { return true; } }
            add_post_meta($id,'_pcvt_cash_void',wp_slash(array('entry_id'=>$entry_id,'at'=>gmdate('c'),'agent'=>get_current_user_id(),'reason'=>substr(sanitize_text_field($reason),0,300))));
            self::audit($id,'cash_voided',array('entry_id'=>$entry_id)); return true;
        } finally { PCVT_Lock::release($lock); }
    }
    public static function save_travelers($id,$travelers) {
        $guard=self::guard($id); if (is_wp_error($guard)) { return $guard; }
        $count=(int)get_post_meta($id,'_pcvt_adults',true)+(int)get_post_meta($id,'_pcvt_children',true);
        if (!is_array($travelers) || count($travelers)!==$count || $count<1 || $count>20) { return self::error('pax','Renseigner chaque voyageur.'); }
        $safe=array();
        foreach (array_values($travelers) as $p) {
            if (!is_array($p)) { return self::error('pax','Voyageur invalide.'); }
            $first=self::text($p,'firstName',100); $last=self::text($p,'lastName',100); $birth=self::text($p,'birthDate',10);
            if (!$first || !$last) { return self::error('pax','Prénom et nom sont requis pour chaque voyageur.'); }
            $row=array('firstName'=>$first,'lastName'=>$last);
            if ($birth!=='') {
                $d=DateTimeImmutable::createFromFormat('!Y-m-d',$birth);
                if (!$d || $d->format('Y-m-d')!==$birth || $birth>wp_date('Y-m-d')) { return self::error('pax','Date de naissance invalide.'); }
                $row['birthDate']=$birth.'T00:00:00';
            }
            $safe[]=$row;
        }
        $lock=self::lock($id,60); if (!$lock) { return self::error('busy','Dossier en cours.'); }
        try {
            if (!in_array(self::state($id)['phase'],array('draft','quote_ready','quote_changed'),true)) { return self::error('immutable','Les voyageurs du dossier transmis ne peuvent pas être remplacés localement.'); }
            update_post_meta($id,'_pcvt_travelers',wp_slash($safe)); self::audit($id,'travelers_saved',array('count'=>count($safe))); return true;
        } finally { PCVT_Lock::release($lock); }
    }
    public static function confirm($id,$revision,$consent=false,$terms=false) {
        $guard=self::guard($id); if (is_wp_error($guard)) { return $guard; }
        if (empty(pcvt_settings()['enabled_booking'])) { return self::error('disabled','Parcours fournisseur désactivé.'); }
        if (!PCVT_Crypto::ready()) { return self::error('crypto','OpenSSL AES-256-GCM requis.'); }
        $lock=self::lock($id,60); if (!$lock) { return self::error('busy','Dossier en cours.'); }
        try {
            $state=self::state($id); $q=self::quote_data($id);
            if ($state['phase']!=='quote_ready') { return self::error('already_started','Dossier déjà soumis ou à vérifier : aucune nouvelle création envoyée.'); }
            if (!$q || !is_string($revision) || !hash_equals($q['revision'],$revision) || time()-$q['at']>15*MINUTE_IN_SECONDS) { return self::error('quote_expired','Vérifier de nouveau le prix : le devis date de plus de 15 minutes ou a changé.'); }
            if (!hash_equals($q['license_fingerprint'],self::license_fingerprint())) { return self::error('license_changed','La licence a changé depuis le devis; vérifier de nouveau le prix avec le bon catalogue.'); }
            if (self::paid($id,$q['currency'])<$q['minimum_minor']) { return self::error('deposit_required','L’acompte minimum n’a pas été encaissé et validé.'); }
            $travelers=get_post_meta($id,'_pcvt_travelers',true);
            if (!is_array($travelers) || count($travelers)!==$q['body']['nbAdult']+$q['body']['nbChild']) { return self::error('pax','Enregistrer les noms de tous les voyageurs avant de confirmer.'); }
            if (!$consent && !get_post_meta($id,'_pcvt_supplier_consent',true)) { return self::error('consent','L’autorisation du client de transmettre les voyageurs au fournisseur est requise.'); }
            if ($q['terms']!=='' && !$terms) { return self::error('terms','Confirmer l’acceptation des conditions fournisseur par le client.'); }
            $state=array('phase'=>'queued','agent'=>get_current_user_id(),'approved_at'=>time(),'quote_revision'=>$q['revision'],'lang'=>pcvt_settings()['lang'],'supplier_user'=>$q['supplier_user']);
            update_post_meta($id,'_pcvt_supplier_consent',1);
            self::put($id,$state); self::audit($id,'agent_approved',array('paid_minor'=>self::paid($id,$q['currency']),'terms_hash'=>$q['terms_hash'],'consent_attested'=>true));
            self::pending($id,true); self::schedule($id); return $state;
        } finally { PCVT_Lock::release($lock); }
    }
    private static function stop($id,&$state,$error,$operation,$phase='manual_review') {
        $state['phase']=$phase; $state['operation']=$operation; $state['error']=is_wp_error($error) ? $error->get_error_message() : (string)$error;
        self::put($id,$state); self::pending($id,false); wp_clear_scheduled_hook('pcvt_booking_step',array((int)$id));
        self::audit($id,'workflow_stopped',array('operation'=>$operation,'code'=>is_wp_error($error) ? $error->get_error_code() : 'unexpected'),$state['agent']??0);
    }
    private static function token($id) { return PCVT_Crypto::decrypt(get_post_meta($id,'_pcvt_supplier_token',true),$id); }
    private static function identifier($value) { return is_string($value) && strlen($value)>0 && strlen($value)<=180 && !preg_match('~[\x00-\x20/\\\\?#%]~',$value) && $value!=='.' && $value!=='..'; }
    private static function matches($reservation,$q) {
        $total=PCVT_Money::from_api($reservation['total']??null);
        return !is_wp_error($total) && $total===$q['total_minor'] && ($reservation['currency']??'')===$q['currency'] &&
            ($reservation['mainProduct']['code']??'')===$q['body']['product'] && (int)($reservation['productPriceDateCode']??0)===$q['body']['productPriceDateCode'];
    }
    private static function pax_body($id,$reservation,$token,$q) {
        if (!self::matches($reservation,$q)) { return self::error('reservation_mismatch','La réservation reçue ne correspond pas au produit, au départ, au prix ou à la devise validés.'); }
        $indexes=array();
        foreach (is_array($reservation['listRoom']??null) ? $reservation['listRoom'] : array() as $room) {
            foreach (is_array($room['listPax']??null) ? $room['listPax'] : array() as $p) {
                if (!isset($p['index']) || !is_int($p['index']) || $p['index']<0) { return self::error('pax_indices','Index de voyageur fournisseur invalide.'); }
                $indexes[]=$p['index'];
            }
        }
        $travelers=get_post_meta($id,'_pcvt_travelers',true);
        if (!is_array($travelers) || count($indexes)!==count($travelers) || count(array_unique($indexes))!==count($indexes)) { return self::error('pax_indices','Les emplacements voyageurs sont incomplets ou ambigus; aucune association inventée.'); }
        $out=array();
        foreach ($travelers as $i=>$p) {
            $row=$p; $row['index']=$indexes[$i];
            if ($i===0) { $row['email']=get_post_meta($id,'_pcvt_email',true); $row['tel1']=get_post_meta($id,'_pcvt_phone',true); }
            $out[]=$row;
        }
        return array('reservationCode'=>$reservation['code'],'token'=>$token,'listPax'=>$out);
    }
    public static function worker($id) {
        $id=(int)$id; if (get_post_type($id)!=='pcvt_request' || get_post_status($id)==='trash') { self::pending($id,false); return; }
        $lock=self::lock($id,300); if (!$lock) { self::schedule($id,30); return; }
        try {
            wp_clear_scheduled_hook('pcvt_booking_step',array($id)); $state=self::state($id); $q=self::quote_data($id);
            if (!in_array($state['phase'],array('queued','ready_create','creating_reservation','reservation_created','updating_passengers','passengers_saved','creating_invoice','invoice_created','ready_email','sending_invoice'),true)) { self::pending($id,false); return; }
            if (in_array($state['phase'],array('creating_reservation','creating_invoice','updating_passengers','sending_invoice'),true)) { self::stop($id,$state,self::error('uncertain','Traitement interrompu : vérifier le résultat chez le fournisseur avant toute reprise.'),$state['phase']); return; }
            if (empty(pcvt_settings()['enabled_booking']) || empty($state['agent']) || !user_can($state['agent'],'manage_pcvt_bookings') || !$q || ($state['quote_revision']??'')!==$q['revision'] || !hash_equals($q['license_fingerprint']??'',self::license_fingerprint())) {
                $state['resume_phase']=$state['phase']; self::stop($id,$state,self::error('approval','Configuration, licence, devis ou autorisation agent indisponible.'),'approval'); return;
            }
            self::schedule($id,300); // Watchdog; in-flight creation states trigger manual review on recovery.
            if ($state['phase']==='queued') {
                $available=self::available($q['body']['product'],$q['body']['productPriceDateCode']);
                if (is_wp_error($available)) { self::stop($id,$state,$available,'preflight','quote_changed'); return; }
                $preview=PCVT_API::preview($q['body']); $totals=is_wp_error($preview) ? $preview : self::totals($preview);
                if (is_wp_error($totals)) { self::stop($id,$state,$totals,'preflight','quote_changed'); return; }
                if ($totals!==array_intersect_key($q,$totals) || self::paid($id,$q['currency'])<$totals['minimum_minor']) { self::stop($id,$state,self::error('quote_changed','Le prix, l’acompte ou les paramètres ont changé. Faire vérifier et accepter le nouveau prix.'),'preflight','quote_changed'); return; }
                if (!self::matches($preview,$q)) { self::stop($id,$state,self::error('quote_changed','Le produit ou le départ ne correspondent plus au devis.'),'preflight','quote_changed'); return; }
                $terms='';
                if (!empty($preview['withTerms'])) {
                    $r=PCVT_API::terms($state['lang']);
                    if (is_wp_error($r) || !is_string($r['terms']??null)) { self::stop($id,$state,self::error('terms','Conditions fournisseur indisponibles.'),'preflight','quote_changed'); return; }
                    $terms=wp_kses_post($r['terms']);
                }
                if (!hash_equals($q['terms_hash'],hash('sha256',$terms))) { self::stop($id,$state,self::error('terms','Les conditions fournisseur ont changé; faire accepter la nouvelle version.'),'preflight','quote_changed'); return; }
                $state['phase']='ready_create'; $state['availability_verified_at']=time();
            } elseif ($state['phase']==='ready_create') {
                if (time()-(int)($state['availability_verified_at']??0)>2*MINUTE_IN_SECONDS) { $state['phase']='queued'; self::put($id,$state); wp_clear_scheduled_hook('pcvt_booking_step',array($id)); self::schedule($id); return; }
                $state['phase']='creating_reservation'; self::put($id,$state);
                $body=$q['body']; if (!empty($state['supplier_user'])) { $body['user']=$state['supplier_user']; }
                $r=PCVT_API::create_reservation($body);
                if (is_wp_error($r) || !self::identifier($r['reservationCode']??null) || !is_string($r['token']??null) || $r['token']==='' || strlen($r['token'])>8192 || preg_match('/[\r\n]/',$r['token'])) { self::stop($id,$state,is_wp_error($r) ? $r : self::error('reservation_response','Réponse de création incomplète. Ne pas recréer sans vérification fournisseur.'),'creating_reservation'); return; }
                if (self::reference_used($id,'_pcvt_supplier_reservation',$r['reservationCode'])) { self::stop($id,$state,self::error('duplicate_reference','Le fournisseur a retourné une réservation déjà associée à une autre demande.'),'creating_reservation'); return; }
                $encrypted=PCVT_Crypto::encrypt($r['token'],$id);
                $state['reservation_code']=$r['reservationCode']; update_post_meta($id,'_pcvt_supplier_reservation',$r['reservationCode']);
                update_post_meta($id,'_pcvt_financial_record',1);
                if (is_wp_error($encrypted)) { self::stop($id,$state,$encrypted,'creating_reservation'); return; }
                update_post_meta($id,'_pcvt_supplier_token',$encrypted);
                if (get_post_meta($id,'_pcvt_supplier_token',true)!==$encrypted || get_post_meta($id,'_pcvt_supplier_reservation',true)!==$r['reservationCode']) { self::stop($id,$state,self::error('storage','Réservation créée mais référence ou jeton non sauvegardé; rattacher le dossier existant.'),'creating_reservation'); return; }
                $state['phase']='reservation_created';
                self::audit($id,'reservation_created',array('code'=>$r['reservationCode']),$state['agent']);
            } elseif ($state['phase']==='reservation_created') {
                $token=self::token($id); if (is_wp_error($token)) { self::stop($id,$state,$token,'reservation_created'); return; }
                $r=PCVT_API::reservation($state['reservation_code'],$token);
                if (is_wp_error($r)) { self::stop($id,$state,$r,'reservation_created'); return; }
                if (($r['code']??'')!==$state['reservation_code']) { self::stop($id,$state,self::error('reservation_mismatch','Code de réservation inattendu.'),'reservation_created'); return; }
                $body=self::pax_body($id,$r,$token,$q); if (is_wp_error($body)) { self::stop($id,$state,$body,'reservation_created'); return; }
                $state['phase']='updating_passengers'; self::put($id,$state);
                $r=PCVT_API::passengers($body); if (is_wp_error($r)) { self::stop($id,$state,$r,'updating_passengers'); return; }
                $state['phase']='passengers_saved'; self::audit($id,'travelers_transmitted',array('count'=>count($body['listPax'])),$state['agent']);
            } elseif ($state['phase']==='passengers_saved') {
                $token=self::token($id); if (is_wp_error($token)) { self::stop($id,$state,$token,'passengers_saved'); return; }
                $state['phase']='creating_invoice'; self::put($id,$state);
                $r=PCVT_API::create_invoice($state['reservation_code'],$token,$state['lang']);
                if (is_wp_error($r) || !self::identifier($r['file']??null) || !self::identifier($r['invoice']??null)) { self::stop($id,$state,is_wp_error($r) ? $r : self::error('invoice_response','Réponse de facturation incomplète; vérifier avant de relancer.'),'creating_invoice'); return; }
                if (self::reference_used($id,'_pcvt_supplier_invoice',$r['invoice'])) { self::stop($id,$state,self::error('duplicate_reference','La facture retournée est déjà associée à une autre demande.'),'creating_invoice'); return; }
                $state['file']=$r['file']; $state['invoice']=$r['invoice']; $state['phase']='invoice_created';
                update_post_meta($id,'_pcvt_supplier_invoice',$r['invoice']); self::audit($id,'invoice_created',array('file'=>$r['file'],'invoice'=>$r['invoice']),$state['agent']);
            } elseif ($state['phase']==='invoice_created') {
                $r=PCVT_API::invoice($state['file']); if (is_wp_error($r)) { self::stop($id,$state,$r,'invoice_created'); return; }
                $total=PCVT_Money::from_api($r['total']??null); $balance=PCVT_Money::from_api($r['balance']??null);
                if (($r['invoice']??'')!==$state['invoice'] || ($r['file']??'')!==$state['file'] || ($r['currency']??'')!==$q['currency'] || is_wp_error($total) || $total!==$q['total_minor'] || is_wp_error($balance) || $balance>$total) { self::stop($id,$state,self::error('invoice_mismatch','La facture fournisseur ne correspond pas au devis validé.'),'invoice_created'); return; }
                $state['supplier_balance_minor']=$balance; $state['supplier_balance_at']=time(); $state['phase']='ready_email';
            } elseif ($state['phase']==='ready_email') {
                $state['phase']='sending_invoice'; self::put($id,$state);
                $sent=self::send_invoice($id,$state,$q);
                if (is_wp_error($sent)) { self::stop($id,$state,$sent,'sending_invoice','email_failed'); return; }
                $state['phase']='completed'; $state['email_at']=time(); $state['email_status']='accepted';
                self::audit($id,'invoice_mail_accepted',array('invoice'=>$state['invoice']),$state['agent']);
            }
            self::put($id,$state); wp_clear_scheduled_hook('pcvt_booking_step',array($id));
            if ($state['phase']==='completed') { self::pending($id,false); } else { self::schedule($id); }
        } catch (Throwable $e) {
            $state=self::state($id); self::stop($id,$state,self::error('unexpected','Traitement interrompu; contrôle manuel nécessaire avant reprise.'),$state['phase']??'unknown');
        } finally { PCVT_Lock::release($lock); }
    }
    private static function send_invoice($id,$state,$q) {
        $email=get_post_meta($id,'_pcvt_email',true);
        if (!is_email($email)) { return self::error('email','Courriel du client invalide.'); }
        $pdf=PCVT_API::invoice_pdf($state['invoice'],$state['file']); if (is_wp_error($pdf)) { return $pdf; }
        $dir=defined('PCVT_PRIVATE_DIR') ? PCVT_PRIVATE_DIR : sys_get_temp_dir(); $real=is_string($dir) ? realpath($dir) : false; $web=realpath(ABSPATH);
        if (!$real || !is_writable($real) || ($web && ($real===$web || strpos($real,$web.DIRECTORY_SEPARATOR)===0))) { return self::error('private_storage','Configurer PCVT_PRIVATE_DIR dans un dossier accessible hors de la racine web.'); }
        $temp=tempnam($real,'pcvt-invoice-');
        if (!$temp) { return self::error('private_storage','Création du document temporaire impossible.'); }
        $file=$temp.'.pdf';
        if (!rename($temp,$file)) { @unlink($temp); return self::error('private_storage','Préparation de la pièce jointe impossible.'); }
        try {
            chmod($file,0600);
            if (file_put_contents($file,$pdf)!==strlen($pdf)) { return self::error('private_storage','Écriture du document impossible.'); }
            $paid=self::paid($id,$q['currency']);
            $text="Bonjour,\n\nVeuillez trouver votre facture fournisseur en pièce jointe.\nRéservation : ".$state['reservation_code']."\nFacture : ".$state['invoice']."\nTotal : ".PCVT_Money::display($q['total_minor'],$q['currency'])."\nEncaissement enregistré par votre agence : ".PCVT_Money::display($paid,$q['currency'])."\nSolde dans le suivi de l’agence : ".PCVT_Money::display(max(0,$q['total_minor']-$paid),$q['currency'])."\n\nLe solde de la facture fournisseur peut différer tant que votre paiement en espèces n’a pas été reporté dans PC Voyages. Pour toute question, contactez votre conseiller.\n";
            if (!wp_mail($email,'Votre facture de voyage '.$state['invoice'],$text,array(),array($file))) { return self::error('mail_failed','Facture créée, mais la messagerie a refusé l’envoi. Reprendre uniquement l’envoi.'); }
            return true;
        } finally { if (is_file($file)) { unlink($file); } }
    }
    public static function retry($id,$reason,$verified_absent=false,$resend=false) {
        $guard=self::guard($id); if (is_wp_error($guard)) { return $guard; }
        if (!is_string($reason) || strlen(trim($reason))<5) { return self::error('reason','Décrire la vérification effectuée avant reprise.'); }
        $lock=self::lock($id,60); if (!$lock) { return self::error('busy','Dossier en cours.'); }
        try {
            $state=self::state($id); $phase=$state['phase'];
            if ($resend && in_array($phase,array('completed','email_failed'),true)) { $next='ready_email'; }
            elseif ($phase==='manual_review') {
                $op=$state['operation']??'';
                if (in_array($op,array('creating_reservation','creating_invoice'),true)) {
                    if (!current_user_can('manage_options') || !$verified_absent) { return self::error('verify_absence','Un administrateur doit vérifier chez le fournisseur qu’aucune création n’a abouti et attester cette absence.'); }
                    $next=$op==='creating_reservation' ? 'queued' : 'passengers_saved';
                } else {
                    $map=array('reservation_created'=>'reservation_created','updating_passengers'=>'reservation_created','passengers_saved'=>'passengers_saved','invoice_created'=>'invoice_created','sending_invoice'=>'ready_email');
                    if ($op==='approval' && in_array($state['resume_phase']??'',array('queued','ready_create','reservation_created','passengers_saved','invoice_created','ready_email'),true)) { $map['approval']=$state['resume_phase']; }
                    if (!isset($map[$op])) { return self::error('review','Rattacher le dossier connu ou contacter le fournisseur avant reprise.'); }
                    $next=$map[$op];
                }
            } else { return self::error('review','Ce dossier ne nécessite pas cette reprise.'); }
            $state['phase']=$next; $state['agent']=get_current_user_id(); unset($state['error'],$state['operation']); self::put($id,$state);
            self::audit($id,$resend ? 'invoice_resend_requested' : 'retry_authorized',array('next'=>$next,'absence_attested'=>(bool)$verified_absent,'reason'=>substr(sanitize_text_field($reason),0,300)));
            self::pending($id,true); self::schedule($id); return true;
        } finally { PCVT_Lock::release($lock); }
    }
    public static function attach($id,$kind,$code,$token_or_file,$reason) {
        $guard=self::guard($id); if (is_wp_error($guard)) { return $guard; }
        if (!current_user_can('manage_options') || !is_string($reason) || strlen(trim($reason))<5 || !self::identifier($code)) { return self::error('review','Rattachement réservé à un administrateur avec référence et motif de vérification.'); }
        $lock=self::lock($id,120); if (!$lock) { return self::error('busy','Dossier en cours.'); }
        try {
            $state=self::state($id); $q=self::quote_data($id);
            if ($state['phase']!=='manual_review' || !$q) { return self::error('review','Rattachement disponible uniquement pour un résultat incertain.'); }
            $key=$kind==='reservation' ? '_pcvt_supplier_reservation' : '_pcvt_supplier_invoice';
            $duplicates=get_posts(array('post_type'=>'pcvt_request','post_status'=>array('private','draft','publish','trash'),'meta_key'=>$key,'meta_value'=>$code,'fields'=>'ids','numberposts'=>2,'post__not_in'=>array($id)));
            if ($duplicates) { return self::error('duplicate','Cette référence est déjà rattachée à une autre demande WordPress.'); }
            if ($kind==='reservation' && ($state['operation']??'')==='creating_reservation') {
                if (!is_string($token_or_file) || $token_or_file==='' || strlen($token_or_file)>8192 || preg_match('/[\r\n]/',$token_or_file)) { return self::error('token','Jeton de réservation invalide.'); }
                $r=PCVT_API::reservation($code,$token_or_file);
                if (is_wp_error($r)) { return $r; }
                if (($r['code']??'')!==$code || !self::matches($r,$q)) { return self::error('reservation_mismatch','Le dossier ne correspond pas au devis.'); }
                $encrypted=PCVT_Crypto::encrypt($token_or_file,$id); if (is_wp_error($encrypted)) { return $encrypted; }
                update_post_meta($id,'_pcvt_supplier_token',$encrypted); update_post_meta($id,$key,$code); $state['reservation_code']=$code; $state['phase']='reservation_created';
            } elseif ($kind==='invoice' && ($state['operation']??'')==='creating_invoice' && !empty($state['reservation_code']) && self::identifier($token_or_file)) {
                $r=PCVT_API::invoice($token_or_file); if (is_wp_error($r)) { return $r; }
                $total=PCVT_Money::from_api($r['total']??null);
                if (($r['invoice']??'')!==$code || ($r['file']??'')!==$token_or_file || ($r['currency']??'')!==$q['currency'] || is_wp_error($total) || $total!==$q['total_minor']) { return self::error('invoice_mismatch','La facture ne correspond pas au montant, à la devise et aux références vérifiées.'); }
                $state['file']=$token_or_file; $state['invoice']=$code; $state['phase']='invoice_created'; update_post_meta($id,$key,$code);
            } else { return self::error('review','Cette opération de rattachement ne correspond pas à l’étape interrompue.'); }
            $state['agent']=get_current_user_id(); unset($state['error'],$state['operation']); self::put($id,$state);
            self::audit($id,'existing_'.$kind.'_attached',array('code'=>$code,'reason'=>substr(sanitize_text_field($reason),0,300)));
            self::pending($id,true); self::schedule($id); return true;
        } finally { PCVT_Lock::release($lock); }
    }
}
PCVT_Booking::boot();
