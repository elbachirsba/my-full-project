<?php
if (!defined('ABSPATH')) { exit; }
final class PCVT_Sync {
    const OPTION = 'pcvt_sync_state';
    const QUEUE_OPTION = 'pcvt_sync_queue';
    public static function state() { $s=get_option(self::OPTION,array()); return is_array($s) ? $s : array(); }
    public static function localized($value, $lang='fr') {
        if (is_string($value)) { return $value; }
        if (!is_array($value)) { return ''; }
        foreach ($lang==='en' ? array('english','french','lang1','lang2') : array('french','english','lang1','lang2') as $key) {
            if (isset($value[$key]) && is_scalar($value[$key]) && (string)$value[$key]!=='') { return (string)$value[$key]; }
        }
        return '';
    }
    private static function rich_text($html) {
        // Cosmetic removal of non-content blocks; wp_kses_post remains the security boundary.
        $html=preg_replace('#<(script|style|iframe|object|noscript)\b[^>]*>.*?</\1\s*>#is','',(string)$html);
        return wp_kses_post($html);
    }
    private static function is_list($data) { return is_array($data) && array_values($data)===$data; }
    public static function run() {
        $lock=PCVT_Lock::acquire('sync');
        if (!$lock) { return new WP_Error('pcvt_busy','Un traitement de synchronisation est déjà actif.'); }
        try {
            $state=self::state();
            if (isset($state['status']) && $state['status']==='running') { self::resume(); return $state; }
            $groups=PCVT_API::groups();
            if (is_wp_error($groups)) { self::set_status($groups->get_error_message()); return $groups; }
            if (!self::is_list($groups)) { return self::format_error(); }
            $queue=array(); $settings=pcvt_settings();
            foreach ($groups as $group) {
                if (!is_array($group) || !isset($group['listProduct']) || !self::is_list($group['listProduct'])) { return self::format_error(); }
                foreach ($group['listProduct'] as $item) {
                    if (!is_array($item) || !isset($item['code']) || !is_scalar($item['code'])) { return self::format_error(); }
                    $code=trim((string)$item['code']);
                    if ($code==='' || strlen($code)>180 || preg_match('/[\x00-\x20\/\\\\?#]/',$code) || $code==='.' || $code==='..') { return self::format_error(); }
                    if (!isset($queue[$code])) {
                        $item['code']=$code;
                        $item['groups']=array();
                        $queue[$code]=$item;
                    }
                    $name=sanitize_text_field(self::localized($group['name']??'', $settings['lang']));
                    if ($name!=='' && !in_array($name,$queue[$code]['groups'],true)) { $queue[$code]['groups'][]=$name; }
                    if (count($queue)>5000) { return new WP_Error('pcvt_catalog_size','Catalogue supérieur à 5 000 produits : segmentation fournisseur nécessaire, aucun import tronqué.'); }
                }
            }
            $state=array('id'=>wp_generate_uuid4(), 'status'=>'running', 'started'=>time(), 'heartbeat'=>time(),
                'lang'=>$settings['lang'], 'cursor'=>0, 'total'=>count($queue),
                'created'=>0, 'updated'=>0, 'unchanged'=>0, 'skipped'=>0, 'failed'=>0, 'unpublished'=>0,
                'attempt'=>0, 'next_attempt'=>0, 'issues'=>array());
            // The catalogue snapshot is immutable; checkpoints write only the small status record.
            update_option(self::QUEUE_OPTION,array_values($queue),false);
            update_option(self::OPTION,$state,false);
            self::schedule(1);
            self::set_status('Import planifié : '.$state['total'].' produits.');
            return $state;
        } finally { PCVT_Lock::release($lock); }
    }
    private static function format_error() {
        $error=new WP_Error('pcvt_format','Structure du catalogue fournisseur invalide; les offres existantes sont conservées.');
        self::set_status($error->get_error_message()); return $error;
    }
    public static function resume() {
        if (wp_next_scheduled('pcvt_sync_batch')) { return; }
        $state=self::state();
        if (isset($state['status']) && $state['status']==='running' && !wp_next_scheduled('pcvt_sync_batch')) {
            self::schedule(max(1,(int)($state['next_attempt']??0)-time()));
        }
    }
    private static function schedule($delay=5) {
        if (!wp_next_scheduled('pcvt_sync_batch')) { wp_schedule_single_event(time()+max(1,(int)$delay),'pcvt_sync_batch'); }
    }
    public static function cancel() {
        $lock=PCVT_Lock::acquire('sync');
        if (!$lock) { return new WP_Error('pcvt_busy','Un lot est en cours; réessayez après sa fin.'); }
        try {
            $state=self::state(); $state['status']='cancelled'; unset($state['queue']);
            update_option(self::OPTION,$state,false); delete_option(self::QUEUE_OPTION); wp_clear_scheduled_hook('pcvt_sync_batch');
            self::set_status('Import arrêté par un administrateur.'); return true;
        } finally { PCVT_Lock::release($lock); }
    }
    public static function worker() {
        $lock=PCVT_Lock::acquire('sync',180);
        if (!$lock) { return; }
        try {
            $state=self::state();
            if (empty($state['status']) || $state['status']!=='running') { return; }
            $queue=get_option(self::QUEUE_OPTION,array());
            if (!is_array($queue) || count($queue)!==(int)$state['total']) {
                $state['status']='failed'; $state['issues'][]='File de produits manquante ou corrompue; relancer un import.';
                update_option(self::OPTION,$state,false); wp_clear_scheduled_hook('pcvt_sync_batch'); return;
            }
            // Drop the pending watchdog before creating the next one; direct CLI runs use the same path.
            wp_clear_scheduled_hook('pcvt_sync_batch');
            if (!empty($state['next_attempt']) && time()<$state['next_attempt']) { self::schedule($state['next_attempt']-time()); return; }
            self::schedule(180); // Crash recovery, including PHP process termination.
            $started=microtime(true); $batch=min(10,max(1,(int)pcvt_settings()['batch_size']));
            for ($i=0; $i<$batch && $state['cursor']<$state['total']; $i++) {
                if ($i>0 && microtime(true)-$started>=20) { break; }
                $item=$queue[$state['cursor']];
                $result=self::import($item,$state['lang']);
                if (is_wp_error($result)) {
                    $data=$result->get_error_data();
                    if (is_array($data) && !empty($data['retryable']) && $state['attempt']<2) {
                        $state['attempt']++;
                        $state['next_attempt']=time()+max(30*(int)$state['attempt'],(int)($data['retry_after']??0));
                        $state['heartbeat']=time(); update_option(self::OPTION,$state,false);
                        wp_clear_scheduled_hook('pcvt_sync_batch'); self::schedule($state['next_attempt']-time()); return;
                    }
                    $state['failed']++;
                    if (count($state['issues'])<20) { $state['issues'][]=sanitize_text_field($item['code']).' : '.$result->get_error_message(); }
                } else { $state[$result]++; }
                $state['cursor']++; $state['attempt']=0; $state['next_attempt']=0; $state['heartbeat']=time();
                // Checkpoint after every product. An interrupted upsert can safely run again.
                update_option(self::OPTION,$state,false);
            }
            wp_clear_scheduled_hook('pcvt_sync_batch');
            if ($state['cursor']>=$state['total']) {
                if (!$state['failed'] && $state['total']>0 && !empty(pcvt_settings()['unpublish_missing'])) { self::retire_missing($state,$queue); }
                $state['status']='completed'; $state['finished']=time(); unset($state['queue']);
                update_option(self::OPTION,$state,false); delete_option(self::QUEUE_OPTION);
                self::set_status('Import terminé : '.$state['created'].' créations, '.$state['updated'].' mises à jour, '.$state['unchanged'].' inchangées, '.$state['failed'].' erreurs, '.$state['unpublished'].' dépublications.');
            } else { self::schedule(5); }
        } finally { PCVT_Lock::release($lock); }
    }
    private static function import($item, $lang) {
        $code=$item['code'];
        $ids=get_posts(array('post_type'=>'pcvt_offer','post_status'=>array('publish','draft','pending','private','future','trash'),
            'meta_key'=>'_pcvt_code','meta_value'=>$code,'fields'=>'ids','numberposts'=>2,'orderby'=>'ID','order'=>'ASC'));
        if (count($ids)>1) { return new WP_Error('pcvt_duplicate','Codes produits dupliqués dans WordPress; fusion manuelle nécessaire.'); }
        $id=$ids ? (int)$ids[0] : 0;
        if ($id && get_post_status($id)==='trash') { return 'skipped'; }
        $detail=PCVT_API::product($code);
        if (is_wp_error($detail)) { return $detail; }
        if (!$detail || (!isset($detail['name']) && !isset($detail['description']))) { return new WP_Error('pcvt_detail','Fiche produit non conforme.'); }
        $dates=PCVT_API::dates($code);
        if (is_wp_error($dates)) { return $dates; }
        if (!self::is_list($dates)) { return new WP_Error('pcvt_dates','Liste des départs non conforme.'); }
        foreach ($dates as $date) {
            if (!is_array($date) || !isset($date['productPriceDateCode'],$date['dateDepart'],$date['isAvailable'])) { return new WP_Error('pcvt_dates','Départ incomplet; ancienne fiche conservée.'); }
        }
        $safe_dates=self::safe_dates($dates);
        if (count($safe_dates)!==count($dates) || count(array_unique(array_column($safe_dates,'productPriceDateCode')))!==count($safe_dates)) {
            return new WP_Error('pcvt_dates','Dates invalides ou codes de départ dupliqués; ancienne fiche conservée.');
        }
        $images=$id ? get_post_meta($id,'_pcvt_images',true) : array();
        $images=is_array($images) ? $images : array();
        $image_updated=$id ? (int)get_post_meta($id,'_pcvt_images_updated',true) : 0;
        if (!$image_updated || time()-$image_updated>=DAY_IN_SECONDS) {
            $fresh=PCVT_API::images($code);
            if (!is_wp_error($fresh) && self::is_list($fresh)) {
                $images=self::safe_images($fresh ?: ($detail['listImage']??array()));
                if (!$images && !empty($item['pathImage'])) { $images=self::safe_images(array(array('pathImage'=>$item['pathImage']))); }
                $image_updated=time();
            } elseif (!$images) {
                $images=self::safe_images($detail['listImage']??array());
            }
            // A photo outage does not discard valid dates and product information.
        }
        $summary=self::rich_text(self::localized($detail['description']??'', $lang));
        $content=$summary;
        foreach (is_array($detail['listSection']??null) ? $detail['listSection'] : array() as $section) {
            if (!is_array($section)) { continue; }
            $title=self::localized($section['title']??'', $lang); $body=self::localized($section['content']??'', $lang);
            if ($title!=='') { $content.="\n<h3>".esc_html($title).'</h3>'; }
            $content.=self::rich_text($body);
        }
        $price=self::price($item['pricing']['total']??null);
        $currency=self::currency($item['pricing']['currency']??'CAD');
        $meta=array('_pcvt_code'=>$code, '_pcvt_group'=>implode(', ',$item['groups']), '_pcvt_groups'=>$item['groups'],
            '_pcvt_price'=>$price, '_pcvt_currency'=>$currency, '_pcvt_dates'=>$safe_dates,
            '_pcvt_classes'=>is_array($detail['listClass']??null) ? $detail['listClass'] : array(),
            '_pcvt_pickups'=>is_array($detail['listBusPickup']??null) ? $detail['listBusPickup'] : array(),
            '_pcvt_images'=>$images, '_pcvt_image'=>$images ? $images[0] : '');
        $post=array('post_type'=>'pcvt_offer', 'post_title'=>sanitize_text_field(self::localized($detail['name']??($item['name']??''),$lang) ?: $code),
            'post_content'=>$content, 'post_excerpt'=>sanitize_text_field(wp_trim_words(wp_strip_all_tags($summary),45,'')));
        $hash=hash('sha256',wp_json_encode(array($post,$meta)));
        $changed=!$id || $hash!==get_post_meta($id,'_pcvt_hash',true);
        $auto=$id && get_post_meta($id,'_pcvt_auto_unpublished',true);
        if ($changed || $auto) {
            if ($id) { $post['ID']=$id; }
            if (!$id || $auto) { $post['post_status']='publish'; }
            $saved=$id ? wp_update_post(wp_slash($post),true) : wp_insert_post(wp_slash($post),true);
            if (is_wp_error($saved) || !$saved) { return new WP_Error('pcvt_save','Enregistrement WordPress impossible.'); }
            $id=(int)$saved;
            foreach ($meta as $key=>$value) { update_post_meta($id,$key,wp_slash($value)); }
            update_post_meta($id,'_pcvt_hash',$hash);
        }
        update_post_meta($id,'_pcvt_images_updated',$image_updated);
        update_post_meta($id,'_pcvt_updated',gmdate('Y-m-d H:i:s'));
        delete_post_meta($id,'_pcvt_missing_count'); delete_post_meta($id,'_pcvt_auto_unpublished');
        return !$ids ? 'created' : ($changed || $auto ? 'updated' : 'unchanged');
    }
    private static function retire_missing(&$state,$queue) {
        $seen=array(); foreach ($queue as $item) { $seen[$item['code']]=true; }
        $ids=get_posts(array('post_type'=>'pcvt_offer','post_status'=>'publish','meta_key'=>'_pcvt_code','fields'=>'ids','numberposts'=>-1));
        update_meta_cache('post',$ids);
        foreach ($ids as $id) {
            $code=get_post_meta($id,'_pcvt_code',true);
            if (isset($seen[$code])) { continue; }
            $misses=1+(int)get_post_meta($id,'_pcvt_missing_count',true);
            update_post_meta($id,'_pcvt_missing_count',$misses);
            if ($misses<2) { continue; }
            $r=wp_update_post(array('ID'=>$id,'post_status'=>'draft'),true);
            if (!is_wp_error($r) && $r) { update_post_meta($id,'_pcvt_auto_unpublished',1); $state['unpublished']++; }
        }
    }
    public static function price($value) { return is_numeric($value) && is_finite((float)$value) && (float)$value>=0 ? (string)round((float)$value,2) : ''; }
    public static function currency($value) { return is_string($value) && preg_match('/^[A-Z]{3}$/D',strtoupper($value)) ? strtoupper($value) : 'CAD'; }
    public static function safe_dates($dates) {
        $out=array();
        foreach (is_array($dates) ? $dates : array() as $d) {
            if (!is_array($d) || !isset($d['productPriceDateCode']) || !is_scalar($d['productPriceDateCode']) || !ctype_digit((string)$d['productPriceDateCode']) || (int)$d['productPriceDateCode']<=0) { continue; }
            $depart=is_string($d['dateDepart']??null) ? $d['dateDepart'] : '';
            $return=is_string($d['dateReturn']??null) ? $d['dateReturn'] : '';
            if (!self::valid_date($depart) || ($return!=='' && !self::valid_date($return))) { continue; }
            $out[]=array('productPriceDateCode'=>(int)$d['productPriceDateCode'], 'dateDepart'=>$depart, 'dateReturn'=>$return,
                'isAvailable'=>in_array($d['isAvailable']??false,array(true,1,'1'),true),
                'departStatus'=>(int)($d['departStatus']??0), 'total'=>self::price($d['pricing']['total']??null),
                'currency'=>self::currency($d['pricing']['currency']??'CAD'));
        }
        usort($out,function($a,$b) { return strcmp($a['dateDepart'],$b['dateDepart']); });
        return $out;
    }
    private static function valid_date($value) {
        if (!preg_match('/^(\d{4})-(\d{2})-(\d{2})(?:T.*)?$/D',$value,$m)) { return false; }
        return checkdate((int)$m[2],(int)$m[3],(int)$m[1]) && strtotime($value)!==false;
    }
    public static function available_dates($dates) {
        $today=wp_date('Y-m-d');
        return array_values(array_filter(is_array($dates) ? $dates : array(), function($d) use ($today) {
            return is_array($d) && !empty($d['isAvailable']) && !empty($d['productPriceDateCode']) &&
                isset($d['dateDepart']) && substr($d['dateDepart'],0,10)>=$today;
        }));
    }
    private static function safe_images($images) {
        $out=array();
        foreach (is_array($images) ? array_slice($images,0,12) : array() as $image) {
            $url=self::safe_remote_image(is_array($image) ? ($image['pathImage']??'') : '');
            if ($url && !in_array($url,$out,true)) { $out[]=$url; }
        }
        return $out;
    }
    public static function safe_remote_image($url) {
        if (!is_string($url) || !preg_match('#^https://#i',$url)) { return ''; }
        $p=wp_parse_url($url);
        if (empty($p['host']) || !empty($p['user']) || !empty($p['pass']) || isset($p['port']) || isset($p['fragment'])) { return ''; }
        if (strtolower($p['host'])==='localhost' || filter_var($p['host'],FILTER_VALIDATE_IP) && !filter_var($p['host'],FILTER_VALIDATE_IP,FILTER_FLAG_NO_PRIV_RANGE|FILTER_FLAG_NO_RES_RANGE)) { return ''; }
        return esc_url_raw($url,array('https'));
    }
    private static function set_status($result) {
        $s=pcvt_settings(); $s['last_sync']=current_time('mysql'); $s['last_result']=sanitize_text_field($result);
        update_option('pcvt_settings',$s,false);
    }
}
