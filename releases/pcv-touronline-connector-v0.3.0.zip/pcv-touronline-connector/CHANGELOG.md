# Historique

## 0.3.0 — 19 octobre 2026

- Parcours agent : vérification du prix fournisseur, enregistrement des voyageurs, encaissements en espèces et validation d’un acompte avant création fournisseur.
- Acompte configurable : valeur fournisseur, pourcentage, montant fixe ou total; respect du plancher fournisseur. Comptabilité locale en centimes entiers.
- Rôle Agent PCV : traitement opérationnel des demandes, sans réglages de licence ni suppression des dossiers financiers.
- Journal des versements, dédoublonnage, corrections séparées avant transmission, historique des actions et protection contre les encaissements concurrents excessifs.
- Sélection des classes, catégories, arrêts et options documentées; devis fournisseur, inventaire des options et conditions revérifiés.
- Réservation, lecture des emplacements voyageurs, mise à jour des voyageurs, facture avec isPaymentDisabled=true et envoi PDF par étapes WP-Cron.
- Reprises manuelles après résultats de création incertains; rattachement de références existantes et renvoi de facture sans nouvelle création.
- Jetons de réservation chiffrés par AES-256-GCM. PDF téléchargé depuis l’origine autorisée, fichier temporaire privé puis suppression après envoi.
- Soldes WordPress et fournisseur distincts : aucune route d’enregistrement d’espèces n’est fournie dans l’OpenAPI; aucun encaissement cash n’est inventé dans PC Voyages.
- Export étendu aux voyageurs et encaissements. Les données financières sont exclues de la purge automatique et restent effaçables par les outils administratifs explicites.
- Parcours désactivé par défaut; aucun paiement en ligne ni compte client créé automatiquement.


## 0.2.0 — 19 octobre 2026

- Import en arrière-plan, lots réglables, file persistante séparée des checkpoints, reprise et annulation; suppression du blocage sur les 50 premiers produits.
- Verrous atomiques et propriétaire de verrou; nettoyage des verrous expirés.
- Reprises différées bornées pour réseau/429/5xx, respect de Retry-After, conservation des anciennes fiches si les dates sont invalides.
- Vérification des schémas JSON, tailles, dates, codes, prix et images; photos réutilisées 24 h et panne photo non bloquante.
- Mise à jour conditionnelle des fiches, conservation des statuts manuels et appartenances multiples aux groupes.
- Politique optionnelle de dépublication après deux snapshots complets sans le produit.
- Pagination, recherche, filtre, galerie responsive, formulaire accessible et chargement ciblé des ressources.
- Formulaires signés, renouvellement des jetons sur pages mises en cache, validation serveur et dédoublonnage concurrent.
- Accès aux demandes réservé aux administrateurs, suivi interne et résultat de notification avec renvoi.
- Export/effacement WordPress, consentement historisé et conservation configurable; migration sans purge implicite des demandes 0.1.0.
- Désinstallation avec conservation par défaut et suppression uniquement sur option explicite.
- Commandes WP-CLI, diagnostic Santé du site, documentation et suites de validation.
- Écritures fournisseur et preview désactivés explicitement en attente d’un parcours métier vérifié.

## 0.1.0

Pilote initial fourni : catalogue, appels de lecture synchrones et demandes locales sans paiement.
