# Analyse et améliorations — PCV TourOnline Connector 0.2.0

Date : 19 octobre 2026. Sources examinées : le bilan technique fourni et les huit fichiers du ZIP 0.1.0. Le bilan sert de documentation à confronter au code; ses recommandations n’ont pas été traitées comme une autorisation de créer des comptes ou réservations chez le fournisseur.

## Résultat

Une version installable 0.2.0 est livrée avec un connecteur de catalogue et un parcours complet de **demande locale sans paiement** : import, affichage, formulaire, enregistrement privé, notification et suivi administratif, export/effacement et conservation des coordonnées. Les mécanismes fournisseur non validés ne sont pas présentés comme opérationnels.

Le fonctionnement WordPress a été vérifié sur un site jetable réel avec des réponses TourOnline contrôlées. Aucun accès métier TourOnline réel, paiement, réservation, facture ou courriel externe n’a été exécuté. Une confirmation des disponibilités et du prix final par l’équipe reste obligatoire.

## Constats du pilote et corrections

| Priorité | Constat dans 0.1.0 | Changement livré |
|---|---|---|
| Haute | Import synchrone jusqu’à 150 appels de 20 s; risque de timeout de la requête administrateur. | File en arrière-plan, lots courts réglables, progression, reprise, annulation et WP-CLI. |
| Haute | Le plafond de 50 repart du début à chaque cycle; les produits suivants ne sont jamais atteints. | File de codes uniques, parcourue entièrement, jusqu’à 5 000 produits; dépassement refusé explicitement. |
| Haute | Le verrou transitoire est lu puis écrit séparément, autorisant des imports concurrents. | Insertion SQL atomique sans remplacement du propriétaire, expiration et suppression conditionnelle. Huit processus ont été mis en concurrence. |
| Haute | Les droits des demandes héritent largement de ceux des articles WordPress. | Lecture, modification, suppression et liste réservées à `manage_options`; aucune route REST publique. |
| Haute | Absence de dédoublonnage d’une demande et de son avis administratif. | Jeton signé de soumission, empreinte de demande, verrous et dédoublonnage dans des fenêtres définies. |
| Haute | Horodatage anti-robot modifiable et nombres négatifs transformés par `absint`. | Horodatage authentifié par HMAC et validation numérique stricte côté serveur. |
| Haute | Conservation indéfinie, pas d’outils WordPress d’export/effacement. | Export et effacement paginés, durée configurable et consentement historisé. Migration depuis 0.1.0 sans activer une purge implicite. |
| Moyenne | Toute panne photo bloque la mise à jour d’une fiche valide. | Conservation des anciennes photos et repli, sans bloquer le texte et les départs valides. |
| Moyenne | Les images et les fiches inchangées sont systématiquement rechargées/réécrites. | Photos réutilisées 24 h et empreinte des données avant mise à jour des publications. |
| Moyenne | Pas de limite de taille JSON, peu de validation structurelle et pas de reprise ciblée. | Réponses bornées, distinction listes/objets, validation des dates et reprises différées réseau/429/5xx. |
| Moyenne | Dates passées affichables et prix/date issus d’un snapshot peu explicite. | Sélection limitée aux départs futurs disponibles, date d’actualisation et rappel de prix indicatifs. |
| Moyenne | Catalogue limité sans pagination ni recherche; groupes multiples perdus. | Pagination, recherche, filtre et conservation de toutes les appartenances connues. |
| Moyenne | Résultat de `wp_mail` ignoré et aucun suivi interne. | Indicateur d’avis, conservation de la demande si l’envoi échoue, renvoi protégé et statuts internes. |
| Moyenne | Aucune politique de retrait des offres absentes. | Option prudente : brouillon après deux imports complets réussis et non vides; pas de suppression définitive d’offre. |
| Faible | Ressources chargées partout, images peu adaptées au mobile, diagnostics limités. | Ressources ciblées, proportions d’image responsives, champs accessibles et contrôle Santé du site. |

Les contenus et identifiants du pilote sont réutilisés. Les champs 0.1.0 restent lisibles. Une offre mise manuellement en brouillon ou à la corbeille n’est pas publiée/recréée automatiquement. Les textes importés restent gérés par la synchronisation : les modifications manuelles de ces textes peuvent être remplacées au prochain changement fournisseur.

## Performance et limites techniques

Pour N produits, le nombre nominal d’appels est `1 + 3N` à froid et `1 + 2N` quand les photos sont réutilisées, sans reprise ni erreur photo. Pour 57 produits, cela correspond structurellement à 172 puis 115 appels, soit environ 33 % d’appels en moins sur ces cycles. Il ne s’agit pas d’une mesure de latence de l’API réelle.

Le snapshot de catalogue est stocké séparément de la progression : chaque checkpoint n’en réécrit pas l’intégralité. Les fiches inchangées évitent les révisions et mises à jour inutiles, tout en conservant la date de vérification. La page du catalogue ne charge que sa tranche de résultats et profite du cache de métadonnées WordPress.

Le budget de 20 secondes est contrôlé **entre** les produits; un produit peut cumuler trois appels de 10 secondes. Sur un hébergement à timeout court, régler un produit par lot et utiliser un Cron système. La file reprend après interruption. Les reprises sont limitées et différées, avec un `Retry-After` plafonné à une heure.

Les limites de 4 Mio par réponse et de 5 000 produits sont des garde-fous, pas des résultats de tests de charge à cette échelle. Le scénario de catalogue testé comporte 57 produits, dont des produits dans plusieurs groupes; les outils de confidentialité ont été testés sur 51 demandes réparties en deux pages. Une segmentation fournisseur demeure nécessaire au-delà du plafond.

## Vérifications exécutées sur la version livrée

| Suite | Réussis | Échecs | Ce qu’elle vérifie |
|---|---:|---:|---|
| Intégration WordPress/PHP | 74 | 0 | Transport simulé, import de plus de 50 produits, snapshots invalides, reprises, retraits, formulaire, quotas, droits, confidentialité et rétention. |
| Chromium / HTTP réel vers WordPress | 21 | 0 | Recherche, pagination, formulaires invités/connectés, cache, dédoublonnage, mobile 390 px, absence de JavaScript, suivi et refus d’accès éditeur. |
| Concurrence multiprocessus | 2 | 0 | Huit processus WordPress concurrents; un seul propriétaire du verrou, sans erreur de base. |
| WP-CLI | 5 | 0 | Import complet, compteurs, sortie rapide sur Retry-After et maintien d’une reprise planifiée. |
| Désinstallation | 4 | 0 | Conservation par défaut et suppression des contenus, options et Cron uniquement après activation explicite. |
| **Total** | **106** | **0** | Aucun contrôle ignoré dans ces suites. |

Syntaxe PHP et JavaScript vérifiée; scripts Python compilés. Le ZIP est contrôlé pour son intégrité, son dossier racine WordPress et sa correspondance avec les fichiers validés. Les scripts, instructions et résultats JSON sont disponibles dans l’archive de sources; ils ne sont pas inclus comme code exécutable dans le ZIP installable.

Environnement : WordPress 6.8.3, PHP 8.4.24, adaptateur SQLite officiel de WordPress, thème Twenty Twenty-Five, Chromium. Les erreurs de transport, JSON et HTTP ainsi que l’échec de notification sont injectés volontairement. Les tests de refus d’accès distinguent l’interdiction WordPress du code HTTP générique utilisé par son écran d’erreur.

## Ce qui reste à valider avant utilisation publique

1. **Accès TourOnline réel** : licence, nécessité du JWT, catalogue éligible et droits sur les endpoints. La présence de routes dans un document ne prouve pas les droits de votre licence.
2. **Mapping réel** : exemples de réponses, types des codes de départ et des prix, états de disponibilité et URL des images relatives. Les arrêts, classes tarifaires et options ne sont pas intégrés à un devis fournisseur; leurs règles restent à confirmer.
3. **Site cible** : MySQL/MariaDB, version PHP exacte, thème, plugins de cache/sécurité, Cron système, réglages de cache des jetons, configuration SMTP et réception effective des avis.
4. **Métier et données personnelles** : durée de conservation, politique publiée, accès du personnel, traitements manuels et sauvegardes. Les outils ajoutés ne constituent pas une certification juridique.
5. **Réservation PCVWeb réelle** : séquence compte/voyageur/réservation/facture, consentement, idempotence après timeout, annulation et garantie de non-paiement. Aucun de ces flux n’est activé sans contrat fournisseur vérifié.

Aucune donnée de production, licence réelle ni sauvegarde de site n’est incluse dans les archives. L’amélioration logicielle est réalisée; la validation fournisseur et l’essai sur votre hébergement sont les étapes restantes pour la mise en service.
